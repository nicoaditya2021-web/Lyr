package com.lyricsplus.bridge

/** One-tap looks for the lyrics (font + placement + animation + color), inspired by the reference mod. */
object Presets {
    class P(
        val name: String, val desc: String,
        val font: Int, val where: Int, val anim: Int, val color: Int,
        val size: Int, val caps: Boolean, val dot: Int
    )

    val ALL = listOf(
        P("Lavender", "Elegan di langit", 4, 1, 0, 5, 100, false, 0xC4B5FD),
        P("Dreamy", "Kata melayang acak", 5, 3, 1, 3, 110, false, 0xFF8FD8),
        P("Flight", "Naik ke langit", 0, 1, 2, 4, 105, true, 0x67E8F9),
        P("Gems", "Mewah dan tebal", 3, 0, 6, 6, 100, true, 0x86EFAC),
        P("Soul", "Bergelombang hangat", 6, 4, 4, 2, 120, true, 0xFFD27F),
        P("Retro", "Pixel ala Minecraft", 7, 2, 7, 0, 100, true, 0xFFFFFF),
        P("Sunset", "Mengelilingimu", 1, 5, 5, 7, 100, false, 0xFFB36B),
        P("Pop", "Heboh warna album", 2, 3, 3, 1, 110, true, 0x22D3EE)
    )

    fun apply(st: Settings, p: P) {
        st.w3dFont = p.font
        st.w3dWhere = p.where
        st.w3dAnim = p.anim
        st.w3dColor = p.color
        st.w3dShadow = true
        st.w3dSize = p.size
        st.floatCaps = p.caps
        st.floatFont = p.font
        st.floatAccent = (p.color == 1)
    }
}
