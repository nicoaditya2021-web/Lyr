package com.lyricsplus.bridge

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

/** LYR.mcaddon is bundled inside the APK. This copies it out and hands it to Minecraft (or any launcher). */
object AddonInstaller {
    const val ASSET = "LYR.mcaddon"
    const val VERSION = "1.0.0"
    private const val MINECRAFT = "com.mojang.minecraftpe"

    private fun prepare(ctx: Context): File? = try {
        val dir = File(ctx.cacheDir, "addon")
        dir.mkdirs()
        val f = File(dir, ASSET)
        ctx.assets.open(ASSET).use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        f
    } catch (e: Exception) {
        null
    }

    private fun uriOf(ctx: Context, f: File): Uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)

    /** opens LYR.mcaddon with Minecraft so it imports the add-on */
    fun install(ctx: Context) {
        val f = prepare(ctx)
        if (f == null) {
            Toast.makeText(ctx, "File add-on tidak ditemukan di aplikasi", Toast.LENGTH_LONG).show()
            return
        }
        val uri = uriOf(ctx, f)
        val view = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/octet-stream")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        view.clipData = ClipData.newRawUri(ASSET, uri)
        try {
            ctx.startActivity(Intent(view).setPackage(MINECRAFT))
        } catch (_: Exception) {
            try {
                // no vanilla Minecraft (a launcher is used): let the person pick the app
                ctx.startActivity(Intent.createChooser(view, "Buka LYR.mcaddon dengan").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {
                Toast.makeText(ctx, "Tidak ada aplikasi yang bisa membuka add-on. Gunakan Bagikan file.", Toast.LENGTH_LONG).show()
            }
        }
    }

    /** shares the file, for launchers that import add-ons from their own menu */
    fun share(ctx: Context) {
        val f = prepare(ctx)
        if (f == null) {
            Toast.makeText(ctx, "File add-on tidak ditemukan di aplikasi", Toast.LENGTH_LONG).show()
            return
        }
        val uri = uriOf(ctx, f)
        val send = Intent(Intent.ACTION_SEND)
            .setType("application/octet-stream")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        send.clipData = ClipData.newRawUri(ASSET, uri)
        try {
            ctx.startActivity(Intent.createChooser(send, "Bagikan LYR.mcaddon").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            Toast.makeText(ctx, "Tidak bisa membagikan file", Toast.LENGTH_LONG).show()
        }
    }
}
