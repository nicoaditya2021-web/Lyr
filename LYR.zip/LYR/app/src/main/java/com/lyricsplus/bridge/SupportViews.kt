package com.lyricsplus.bridge

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

object Support {
    const val URL = "https://sociabuzz.com/aerion"

    fun open(ctx: Context) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(URL)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            Toast.makeText(ctx, "Buka $URL di browser", Toast.LENGTH_LONG).show()
        }
    }
}

/** Small round "donate" logo (heart) that sits in the top corner after the popup is closed. */
class DonateBadge(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val heartP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * d
        color = 0xFFFF6B8A.toInt()
    }
    private val path = Path()
    private var t = 0f
    private var anim: ValueAnimator? = null

    fun startPulse() {
        if (anim?.isRunning == true) return
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1700
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { t = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    fun stopPulse() { anim?.cancel(); anim = null }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        fill.shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), 0xFFFF4D8D.toInt(), 0xFFFF8A3D.toInt(), Shader.TileMode.CLAMP)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val cx = w / 2f
        val cy = height / 2f
        val r = w * 0.40f
        val rr = r + (w / 2f - r - d) * t
        ring.alpha = ((1f - t) * 150f).toInt()
        c.drawCircle(cx, cy, rr, ring)
        c.drawCircle(cx, cy, r, fill)
        val s = r * 0.55f
        path.reset()
        path.moveTo(cx, cy + s * 0.95f)
        path.cubicTo(cx - s * 1.25f, cy + s * 0.1f, cx - s * 0.75f, cy - s * 0.95f, cx, cy - s * 0.35f)
        path.cubicTo(cx + s * 0.75f, cy - s * 0.95f, cx + s * 1.25f, cy + s * 0.1f, cx, cy + s * 0.95f)
        path.close()
        c.drawPath(path, heartP)
    }

    override fun onDetachedFromWindow() {
        stopPulse()
        super.onDetachedFromWindow()
    }
}

/**
 * Square-ish "ad style" card asking people to support the admin. Shows an animated GIF, a button
 * that opens the Sociabuzz link, and an X. Pressing X shrinks the card into a small donate logo in
 * the top-right corner; tapping the logo opens the card again.
 */
class DonatePopup(private val ctx: Context, private val root: FrameLayout) {
    private val d = ctx.resources.displayMetrics.density
    private fun dp(v: Int) = (v * d).toInt()

    private val scrim = View(ctx)
    private val card = FrameLayout(ctx)
    private val badge = DonateBadge(ctx)
    private val gifView = ImageView(ctx)
    private val ctaWrap = FrameLayout(ctx)
    private var gif: AnimatedImageDrawable? = null
    private var pulse: ObjectAnimator? = null
    private val badgeSize = dp(48)
    private val cardW = minOf(dp(320), (ctx.resources.displayMetrics.widthPixels * 0.86f).toInt())

    var isOpen = false
        private set

    init {
        scrim.setBackgroundColor(0xB8000000.toInt())
        scrim.alpha = 0f
        scrim.visibility = View.GONE
        scrim.setOnClickListener { minimize() }
        root.addView(scrim, FrameLayout.LayoutParams(-1, -1))

        buildCard()
        card.visibility = View.GONE
        card.isClickable = true
        root.addView(card, FrameLayout.LayoutParams(cardW, -2, Gravity.CENTER))

        badge.visibility = View.GONE
        badge.setOnClickListener { expand() }
        root.addView(badge, FrameLayout.LayoutParams(badgeSize, badgeSize, Gravity.TOP or Gravity.END).apply {
            topMargin = dp(10)
            rightMargin = dp(12)
        })
        loadGif()
    }

    private fun buildCard() {
        val bg = GradientDrawable()
        bg.setColor(T.card)
        bg.cornerRadius = dp(26).toFloat()
        bg.setStroke(dp(1), T.line)
        card.background = bg
        card.clipToOutline = true
        card.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(26).toFloat()) }
        }

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL

        gifView.scaleType = ImageView.ScaleType.CENTER_CROP
        col.addView(gifView, LinearLayout.LayoutParams(-1, (cardW * 309f / 553f).toInt()))

        val body = LinearLayout(ctx)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(dp(20), dp(16), dp(20), dp(14))

        val title = TextView(ctx)
        title.text = "Dukung Admin"
        title.textSize = 20f
        title.setTextColor(T.text)
        title.typeface = Fonts.get(ctx, 0)
        body.addView(title, LinearLayout.LayoutParams(-2, -2))

        val desc = TextView(ctx)
        desc.text = "Suka aplikasinya? Bantu admin tetap semangat bikin update lewat donasi. Berapa pun sangat berarti."
        desc.textSize = 13f
        desc.setTextColor(T.sub)
        body.addView(desc, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4); bottomMargin = dp(14) })

        val cta = TextView(ctx)
        cta.text = "\u2665  Dukung di Sociabuzz"
        cta.textSize = 15f
        cta.setTextColor(Color.WHITE)
        cta.gravity = Gravity.CENTER
        cta.setPadding(dp(16), dp(13), dp(16), dp(13))
        val cg = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFFFF4D8D.toInt(), 0xFFFF8A3D.toInt()))
        cg.cornerRadius = dp(26).toFloat()
        cta.background = cg
        cta.setOnClickListener { Support.open(ctx) }
        Ui.press(cta)
        ctaWrap.addView(cta, FrameLayout.LayoutParams(-1, -2))
        body.addView(ctaWrap, LinearLayout.LayoutParams(-1, -2))

        val later = TextView(ctx)
        later.text = "Nanti saja"
        later.textSize = 13f
        later.setTextColor(T.sub)
        later.gravity = Gravity.CENTER
        later.setPadding(dp(8), dp(12), dp(8), dp(4))
        later.setOnClickListener { minimize() }
        body.addView(later, LinearLayout.LayoutParams(-1, -2))
        col.addView(body, LinearLayout.LayoutParams(-1, -2))
        card.addView(col, FrameLayout.LayoutParams(-1, -2))

        val close = TextView(ctx)
        close.text = "\u2715"
        close.textSize = 14f
        close.setTextColor(Color.WHITE)
        close.gravity = Gravity.CENTER
        val xg = GradientDrawable()
        xg.shape = GradientDrawable.OVAL
        xg.setColor(0x99000000.toInt())
        close.background = xg
        close.setOnClickListener { minimize() }
        Ui.press(close)
        card.addView(close, FrameLayout.LayoutParams(dp(34), dp(34), Gravity.TOP or Gravity.END).apply {
            topMargin = dp(10)
            rightMargin = dp(10)
        })
    }

    private fun loadGif() {
        try {
            val src = ImageDecoder.createSource(ctx.resources, R.raw.support_gif)
            val dr = ImageDecoder.decodeDrawable(src)
            gifView.setImageDrawable(dr)
            if (dr is AnimatedImageDrawable) {
                dr.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                gif = dr
            }
        } catch (_: Throwable) {
            gifView.setBackgroundColor(0xFF1E1E2A.toInt())
        }
    }

    private fun startGif() { try { gif?.start() } catch (_: Throwable) {} }
    private fun stopGif() { try { gif?.stop() } catch (_: Throwable) {} }

    private fun startPulse() {
        if (pulse?.isRunning == true) return
        pulse = ObjectAnimator.ofPropertyValuesHolder(
            ctaWrap,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.04f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.04f)
        ).apply {
            duration = 800
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
    }

    private fun stopPulse() {
        pulse?.cancel()
        pulse = null
        ctaWrap.scaleX = 1f
        ctaWrap.scaleY = 1f
    }

    /** dx, dy, scale that bring the centered card onto the corner badge */
    private fun shrinkTarget(): FloatArray {
        val lp = badge.layoutParams as FrameLayout.LayoutParams
        val cx = root.width / 2f
        val cy = root.height / 2f
        val bx = root.width - lp.rightMargin - badgeSize / 2f
        val by = lp.topMargin + badgeSize / 2f
        return floatArrayOf(bx - cx, by - cy, badgeSize.toFloat() / cardW)
    }

    fun setTopInset(px: Int) {
        val lp = badge.layoutParams as FrameLayout.LayoutParams
        lp.topMargin = px + dp(10)
        badge.layoutParams = lp
    }

    /** used after the activity was re-created (theme change): show only the corner logo */
    fun showBadgeOnly() {
        if (isOpen) return
        badge.visibility = View.VISIBLE
        badge.scaleX = 1f
        badge.scaleY = 1f
        badge.alpha = 1f
        badge.startPulse()
    }

    fun show() {
        if (isOpen) return
        isOpen = true
        card.animate().cancel()
        scrim.animate().cancel()
        badge.animate().cancel()
        badge.visibility = View.GONE
        badge.stopPulse()
        scrim.visibility = View.VISIBLE
        scrim.alpha = 0f
        card.visibility = View.VISIBLE
        card.alpha = 0f
        card.scaleX = 0.7f
        card.scaleY = 0.7f
        card.translationX = 0f
        card.translationY = dp(48).toFloat()
        startGif()
        startPulse()
        scrim.animate().alpha(1f).setDuration(300).start()
        card.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
            .setDuration(520).setInterpolator(OvershootInterpolator(1.15f)).start()
    }

    fun minimize() {
        if (!isOpen) return
        isOpen = false
        val t = shrinkTarget()
        card.animate().cancel()
        scrim.animate().cancel()
        badge.animate().cancel()
        card.animate().translationX(t[0]).translationY(t[1]).scaleX(t[2]).scaleY(t[2]).alpha(0f)
            .setDuration(430).setInterpolator(AccelerateDecelerateInterpolator())
            .withEndAction {
                if (!isOpen) {
                    card.visibility = View.GONE
                    card.translationX = 0f; card.translationY = 0f
                    card.scaleX = 1f; card.scaleY = 1f
                    stopGif(); stopPulse()
                }
            }.start()
        scrim.animate().alpha(0f).setDuration(380)
            .withEndAction { if (!isOpen) scrim.visibility = View.GONE }.start()
        badge.visibility = View.VISIBLE
        badge.alpha = 1f
        badge.scaleX = 0f
        badge.scaleY = 0f
        badge.startPulse()
        badge.animate().scaleX(1f).scaleY(1f).setStartDelay(280).setDuration(400)
            .setInterpolator(OvershootInterpolator(2.4f))
            .withEndAction { badge.animate().setStartDelay(0) }.start()
    }

    fun expand() {
        if (isOpen) return
        isOpen = true
        val t = shrinkTarget()
        card.animate().cancel()
        scrim.animate().cancel()
        badge.animate().cancel()
        badge.animate().setStartDelay(0).scaleX(0f).scaleY(0f).setDuration(180)
            .withEndAction { if (isOpen) { badge.visibility = View.GONE; badge.stopPulse() } }.start()
        scrim.visibility = View.VISIBLE
        scrim.animate().alpha(1f).setDuration(300).start()
        card.visibility = View.VISIBLE
        card.translationX = t[0]
        card.translationY = t[1]
        card.scaleX = t[2]
        card.scaleY = t[2]
        card.alpha = 0f
        startGif()
        startPulse()
        card.animate().translationX(0f).translationY(0f).scaleX(1f).scaleY(1f).alpha(1f)
            .setDuration(480).setInterpolator(OvershootInterpolator(1.1f)).start()
    }
}
