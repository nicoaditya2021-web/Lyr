package com.lyricsplus.bridge

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.TextPaint
import android.text.TextUtils
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Spotify-style now-playing widget + synced lyrics, drawn with Canvas (no layout inflation = light on CPU).
 * Animations: slide/fade in-out, cover cross-fade, text swap on track change, play/pause morph,
 * pause dimming, button press, smooth progress, lyric line scroll.
 */
class PanelView(
    ctx: Context,
    private val st: Settings,
    private val onDragBy: (Int, Int) -> Unit,
    private val onDragEnd: () -> Unit,
    private val onHiddenDone: () -> Unit
) : View(ctx) {

    private val density = ctx.resources.displayMetrics.density
    private val k: Float get() = density * st.scale / 100f
    private fun dp(v: Float) = v * k

    // ---- layout constants (dp, before scaling)
    private val widthDp = 300f
    private val pad = 12f
    private val coverDp = 56f
    private val lyricsDp = 84f

    private fun rowDp() = if (st.showCover) coverDp else 40f
    private fun heightDp(): Float {
        var h = pad + rowDp()
        if (st.showProgress) h += 30f
        h += 6f + 44f
        if (st.lyrics) h += 8f + lyricsDp
        return h + pad
    }

    // ---- paints
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val titleP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }
    private val subP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val lyricP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        textAlign = Paint.Align.CENTER
    }
    private val timeP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    }
    private val path = Path()
    private val rect = RectF()
    private val src = Rect()

    // ---- hit rects (px)
    private val btnRects = Array(3) { RectF() }
    private val progRect = RectF()
    private val coverRect = RectF()
    private val lyricsRect = RectF()
    private var barY = 0f
    private var btnCy = 0f

    // ---- animation state
    private var targetShown = false
    private var hiddenNotified = true
    private var showAnim = 0f
    private var pauseAnim = 0f
    private var swap = 1f
    private var coverFade = 1f
    private var lyricAnim = 0f
    private var lyricIdx = -2
    private var lastTrackId = -1
    private var curTitle = ""
    private var curArtist = ""
    private var curAlbum = ""
    private var oldTitle = ""
    private var oldArtist = ""
    private var coverNow: Bitmap? = null
    private var coverPrev: Bitmap? = null
    private val cyan = 0xFF22D3EE.toInt()
    private var accent = cyan
    private var accentTarget = cyan
    private var gradAccent = 0
    private var gradW = 0f
    private val btnScale = floatArrayOf(1f, 1f, 1f)
    private var pressed = -1
    private var hit = -1
    private var dragging = false
    private var seekDrag = false
    private var seekFrac = 0f
    private var downX = 0f
    private var downY = 0f
    private var lastRawX = 0f
    private var lastRawY = 0f
    private var lastNs = 0L

    fun setTargetShown(b: Boolean) {
        targetShown = b
        if (b) hiddenNotified = false
    }

    // ---------------------------------------------------------------- frame loop
    private val frame = object : Runnable {
        override fun run() {
            if (!isAttachedToWindow) return
            val now = System.nanoTime()
            val dt = if (lastNs == 0L) 0.016f else min(0.1f, (now - lastNs) / 1e9f)
            lastNs = now
            val busy = step(dt)
            invalidate()
            when {
                busy -> postOnAnimation(this)
                showAnim > 0f && MediaState.playing -> { lastNs = 0L; postDelayed(this, st.frameMs()) }
                else -> { lastNs = 0L; postDelayed(this, 250) }
            }
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        removeCallbacks(frame)
        post(frame)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(frame)
        super.onDetachedFromWindow()
    }

    private fun approach(v: Float, t: Float, d: Float): Float =
        if (v < t) min(v + d, t) else max(v - d, t)

    private fun step(dt: Float): Boolean {
        val sp = max(0.25f, st.animSpeed / 100f)
        var busy = false
        val tr = MediaState.track

        val id = MediaState.trackId
        if (id != lastTrackId) {
            lastTrackId = id
            lyricIdx = -2
            lyricAnim = 0f
            if (tr != null) {
                oldTitle = curTitle; oldArtist = curArtist
                curTitle = tr.title; curArtist = tr.artist; curAlbum = tr.album
                swap = if (oldTitle.isEmpty()) 1f else 0f
            }
        }
        if (tr != null) curAlbum = tr.album

        val cov = tr?.cover
        if (cov !== coverNow) {
            coverPrev = coverNow
            coverNow = cov
            coverFade = if (coverPrev == null) 1f else 0f
            updateAccent(cov)
        }

        val tgt = if (targetShown) 1f else 0f
        showAnim = approach(showAnim, tgt, dt * 3.2f * sp)
        if (showAnim != tgt) busy = true
        if (!targetShown && showAnim <= 0f && !hiddenNotified) {
            hiddenNotified = true
            post { onHiddenDone() }
        }

        val pt = if (MediaState.playing) 0f else 1f
        pauseAnim = approach(pauseAnim, pt, dt * 4f * sp)
        if (pauseAnim != pt) busy = true

        swap = approach(swap, 1f, dt * 3f * sp)
        if (swap < 1f) busy = true
        coverFade = approach(coverFade, 1f, dt * 3f * sp)
        if (coverFade < 1f) busy = true

        val a = min(1f, dt * 4f * sp)
        accent = lerpColor(accent, accentTarget, a)
        if (accent != accentTarget && abs(Color.red(accent) - Color.red(accentTarget)) > 2) busy = true

        if (st.lyrics) {
            val idx = LyricsRepo.indexAt(MediaState.position())
            if (idx != lyricIdx) {
                lyricAnim = if (lyricIdx >= -1 && idx == lyricIdx + 1) 1f else 0f
                lyricIdx = idx
            }
            lyricAnim = approach(lyricAnim, 0f, dt * 4f * sp)
            if (lyricAnim > 0f) busy = true
        }

        for (i in 0..2) {
            val t = if (pressed == i) 0.86f else 1f
            btnScale[i] += (t - btnScale[i]) * min(1f, dt * 18f * sp)
            if (abs(t - btnScale[i]) > 0.005f) busy = true
        }
        return busy
    }

    private fun updateAccent(b: Bitmap?) {
        if (b == null) { accentTarget = cyan; return }
        try {
            val px = Bitmap.createScaledBitmap(b, 1, 1, true).getPixel(0, 0)
            val hsv = FloatArray(3)
            Color.colorToHSV(px, hsv)
            hsv[1] = hsv[1].coerceIn(0.4f, 1f)
            hsv[2] = max(hsv[2], 0.8f)
            accentTarget = Color.HSVToColor(hsv)
        } catch (_: Exception) {
            accentTarget = cyan
        }
    }

    private fun lerpColor(a: Int, b: Int, t: Float): Int {
        if (a == b) return a
        fun l(x: Int, y: Int) = (x + (y - x) * t).roundToInt().coerceIn(0, 255)
        val r = l(Color.red(a), Color.red(b)); val g = l(Color.green(a), Color.green(b)); val bl = l(Color.blue(a), Color.blue(b))
        val res = Color.rgb(r, g, bl)
        return if (t >= 0.999f || (abs(r - Color.red(b)) < 2 && abs(g - Color.green(b)) < 2 && abs(bl - Color.blue(b)) < 2)) b else res
    }

    // ---------------------------------------------------------------- measure / layout
    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(dp(widthDp).roundToInt(), dp(heightDp()).roundToInt())
    }

    private fun computeLayout() {
        val w = width.toFloat()
        var y = dp(pad)
        coverRect.set(dp(pad), y, dp(pad) + dp(coverDp), y + dp(coverDp))
        y += dp(rowDp())
        if (st.showProgress) {
            y += dp(10f)
            barY = y + dp(2f)
            progRect.set(dp(pad) - dp(4f), barY - dp(14f), w - dp(pad) + dp(4f), barY + dp(14f))
            y += dp(20f)
        } else {
            progRect.setEmpty()
        }
        y += dp(6f)
        btnCy = y + dp(22f)
        val cx = w / 2f
        val half = dp(28f)
        val gap = dp(64f)
        btnRects[0].set(cx - gap - half, btnCy - half, cx - gap + half, btnCy + half)
        btnRects[1].set(cx - half, btnCy - half, cx + half, btnCy + half)
        btnRects[2].set(cx + gap - half, btnCy - half, cx + gap + half, btnCy + half)
        y += dp(44f)
        if (st.lyrics) {
            y += dp(8f)
            lyricsRect.set(dp(pad), y, w - dp(pad), y + dp(lyricsDp))
        } else {
            lyricsRect.setEmpty()
        }
    }

    // ---------------------------------------------------------------- draw
    private fun easeOut(t: Float): Float { val u = 1f - t; return 1f - u * u * u }

    override fun onDraw(c: Canvas) {
        if (showAnim <= 0f) return
        computeLayout()
        val w = width.toFloat()
        val h = height.toFloat()
        val e = easeOut(showAnim)

        val pos = st.position
        val dirX = when (pos) { 0, 3 -> -1f; 2, 5 -> 1f; else -> 0f }
        val dirY = if (dirX == 0f) (if (pos == 4) 1f else -1f) else 0f
        val sc = c.save()
        c.translate((1f - e) * dp(40f) * dirX, (1f - e) * dp(24f) * dirY)
        c.saveLayerAlpha(0f, 0f, w, h, (255 * e).roundToInt())

        drawBackground(c, w, h)
        drawTopRow(c, w)
        if (st.showProgress) drawProgress(c, w)
        drawButtons(c)
        if (st.lyrics) drawLyrics(c)

        c.restoreToCount(sc)
    }

    private fun drawBackground(c: Canvas, w: Float, h: Float) {
        val r = dp(18f)
        rect.set(0f, 0f, w, h)
        bg.color = Color.argb((st.bgOpacity * 2.55f).roundToInt().coerceIn(0, 255), 16, 16, 20)
        c.drawRoundRect(rect, r, r, bg)
        if (gradAccent != accent || gradW != w) {
            gradAccent = accent; gradW = w
            glow.shader = LinearGradient(
                0f, 0f, w, dp(120f),
                Color.argb(70, Color.red(accent), Color.green(accent), Color.blue(accent)),
                Color.TRANSPARENT, Shader.TileMode.CLAMP
            )
        }
        glow.alpha = (255 * (st.bgOpacity / 100f)).roundToInt().coerceIn(0, 255)
        c.drawRoundRect(rect, r, r, glow)
        stroke.strokeWidth = dp(1f)
        stroke.color = Color.argb(34, 255, 255, 255)
        c.drawRoundRect(rect, r, r, stroke)
    }

    private fun fit(t: String, p: TextPaint, w: Float): String {
        if (w <= 0f) return ""
        if (p.measureText(t) <= w) return t
        return TextUtils.ellipsize(t, p, w, TextUtils.TruncateAt.END).toString()
    }

    private fun drawTopRow(c: Canvas, w: Float) {
        val tr = MediaState.track
        var x0 = dp(pad)
        if (st.showCover) {
            drawCover(c)
            x0 = coverRect.right + dp(12f)
        }
        val tw = w - x0 - dp(pad)
        val rowTop = dp(pad)
        val base1 = rowTop + if (st.showCover) dp(24f) else dp(16f)
        val base2 = base1 + dp(20f)

        titleP.textSize = dp(15f)
        subP.textSize = dp(12f)
        val dim = 1f - 0.25f * pauseAnim

        // old text sliding out, new sliding in
        if (swap < 1f) {
            titleP.color = Color.WHITE; titleP.alpha = ((1f - swap) * 255 * dim).roundToInt()
            c.drawText(fit(oldTitle, titleP, tw), x0 - dp(14f) * swap, base1, titleP)
            subP.color = Color.WHITE; subP.alpha = ((1f - swap) * 160 * dim).roundToInt()
            c.drawText(fit(oldArtist, subP, tw), x0 - dp(14f) * swap, base2, subP)
        }
        val inOff = dp(14f) * (1f - swap)
        titleP.color = Color.WHITE; titleP.alpha = (swap * 255 * dim).roundToInt()
        c.drawText(fit(curTitle, titleP, tw), x0 + inOff, base1, titleP)
        val sub = if (curAlbum.isNotBlank() && curAlbum != curTitle) "$curArtist • $curAlbum" else curArtist
        subP.color = Color.WHITE; subP.alpha = (swap * 160 * dim).roundToInt()
        c.drawText(fit(sub, subP, tw), x0 + inOff, base2, subP)
        if (tr == null) return
    }

    private fun drawCover(c: Canvas) {
        val r = dp(10f)
        val s = 1f - 0.06f * pauseAnim
        val cx = coverRect.centerX(); val cy = coverRect.centerY()
        c.save()
        c.scale(s, s, cx, cy)
        path.reset()
        path.addRoundRect(coverRect, r, r, Path.Direction.CW)
        c.clipPath(path)
        val now = coverNow
        val prev = coverPrev
        if (prev != null && coverFade < 1f) {
            bmpPaint.alpha = 255
            drawBmp(c, prev)
        } else if (now == null) {
            fill.shader = LinearGradient(
                coverRect.left, coverRect.top, coverRect.right, coverRect.bottom,
                accent, Color.rgb(24, 24, 30), Shader.TileMode.CLAMP
            )
            c.drawRect(coverRect, fill)
            fill.shader = null
            lyricP.textSize = dp(24f)
            lyricP.color = Color.argb(200, 255, 255, 255)
            lyricP.alpha = 200
            c.drawText("♪", cx, cy + dp(8f), lyricP)
        }
        if (now != null) {
            bmpPaint.alpha = (255 * (if (prev != null) coverFade else 1f)).roundToInt()
            drawBmp(c, now)
        }
        if (pauseAnim > 0f) {
            fill.color = Color.argb((110 * pauseAnim).roundToInt(), 0, 0, 0)
            c.drawRect(coverRect, fill)
        }
        c.restore()
    }

    private fun drawBmp(c: Canvas, b: Bitmap) {
        val bw = b.width; val bh = b.height
        val side = min(bw, bh)
        src.set((bw - side) / 2, (bh - side) / 2, (bw + side) / 2, (bh + side) / 2)
        c.drawBitmap(b, src, coverRect, bmpPaint)
    }

    private fun fmt(ms: Long): String {
        val s = max(0L, ms) / 1000
        return "${s / 60}:${(s % 60).toString().padStart(2, '0')}"
    }

    private fun drawProgress(c: Canvas, w: Float) {
        val tr = MediaState.track
        val dur = tr?.durationMs ?: 0L
        val pos = if (seekDrag) (seekFrac * dur).toLong() else MediaState.position()
        val frac = if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f
        val l = dp(pad); val r = w - dp(pad)
        val th = dp(4f)
        rect.set(l, barY - th / 2, r, barY + th / 2)
        fill.color = Color.argb(60, 255, 255, 255)
        c.drawRoundRect(rect, th, th, fill)
        rect.set(l, barY - th / 2, l + (r - l) * frac, barY + th / 2)
        fill.color = accent
        c.drawRoundRect(rect, th, th, fill)
        fill.color = Color.WHITE
        c.drawCircle(l + (r - l) * frac, barY, dp(if (seekDrag) 6.5f else 4.5f), fill)

        timeP.textSize = dp(10f)
        timeP.color = Color.argb(150, 255, 255, 255)
        timeP.textAlign = Paint.Align.LEFT
        c.drawText(fmt(pos), l, barY + dp(16f), timeP)
        timeP.textAlign = Paint.Align.RIGHT
        c.drawText(fmt(dur), r, barY + dp(16f), timeP)
    }

    private fun drawButtons(c: Canvas) {
        val dark = Color.rgb(16, 16, 20)
        for (i in 0..2) {
            val rc = btnRects[i]
            val cx = rc.centerX(); val cy = rc.centerY()
            c.save()
            c.scale(btnScale[i], btnScale[i], cx, cy)
            if (pressed == i) {
                fill.color = Color.argb(40, 255, 255, 255)
                c.drawCircle(cx, cy, dp(26f), fill)
            }
            when (i) {
                0, 2 -> {
                    fill.color = Color.WHITE
                    val s = dp(20f)
                    val mirror = i == 0
                    fun mx(x: Float) = if (mirror) 2f * cx - x else x
                    path.reset()
                    path.moveTo(mx(cx - s * 0.45f), cy - s * 0.5f)
                    path.lineTo(mx(cx + s * 0.35f), cy)
                    path.lineTo(mx(cx - s * 0.45f), cy + s * 0.5f)
                    path.close()
                    c.drawPath(path, fill)
                    val bx = mx(cx + s * 0.5f)
                    rect.set(bx - dp(1.8f), cy - s * 0.5f, bx + dp(1.8f), cy + s * 0.5f)
                    c.drawRoundRect(rect, dp(1.5f), dp(1.5f), fill)
                }
                else -> {
                    fill.color = Color.WHITE
                    c.drawCircle(cx, cy, dp(22f), fill)
                    val s = dp(18f)
                    // pause icon (visible while playing)
                    val pa = 1f - pauseAnim
                    if (pa > 0f) {
                        c.save()
                        val ps = 0.6f + 0.4f * pa
                        c.scale(ps, ps, cx, cy)
                        fill.color = dark; fill.alpha = (255 * pa).roundToInt()
                        rect.set(cx - s * 0.38f, cy - s * 0.5f, cx - s * 0.08f, cy + s * 0.5f)
                        c.drawRoundRect(rect, dp(1.5f), dp(1.5f), fill)
                        rect.set(cx + s * 0.08f, cy - s * 0.5f, cx + s * 0.38f, cy + s * 0.5f)
                        c.drawRoundRect(rect, dp(1.5f), dp(1.5f), fill)
                        c.restore()
                    }
                    // play icon (visible while paused)
                    if (pauseAnim > 0f) {
                        c.save()
                        val ps = 0.6f + 0.4f * pauseAnim
                        c.scale(ps, ps, cx, cy)
                        fill.color = dark; fill.alpha = (255 * pauseAnim).roundToInt()
                        path.reset()
                        path.moveTo(cx - s * 0.32f, cy - s * 0.52f)
                        path.lineTo(cx + s * 0.55f, cy)
                        path.lineTo(cx - s * 0.32f, cy + s * 0.52f)
                        path.close()
                        c.drawPath(path, fill)
                        c.restore()
                    }
                    fill.alpha = 255
                }
            }
            c.restore()
        }
    }

    private fun drawLyrics(c: Canvas) {
        val lr = lyricsRect
        c.save()
        c.clipRect(lr)
        val lines = LyricsRepo.lines
        val cx = lr.centerX()
        val cy = lr.centerY()
        val lineH = dp(26f)
        val maxW = lr.width()
        if (lines.isEmpty()) {
            lyricP.textSize = dp(12f)
            lyricP.color = Color.WHITE
            lyricP.alpha = 120
            c.drawText(fit(LyricsRepo.status.ifBlank { "♪" }, lyricP, maxW), cx, cy + dp(4f), lyricP)
            c.restore()
            return
        }
        for (kk in -2..2) {
            val li = lyricIdx + kk
            if (li < 0 || li >= lines.size) continue
            val off = kk + lyricAnim
            val d = abs(off)
            val alpha = if (d <= 1f) 1f - 0.6f * d else 0.4f - 0.3f * (d - 1f)
            if (alpha <= 0.02f) continue
            val y = cy + off * lineH + dp(5f)
            lyricP.textSize = dp(15f - 3f * min(d, 1f))
            lyricP.isFakeBoldText = d < 0.5f
            val wgt = (1f - min(d, 1f))
            lyricP.color = lerpColor(Color.WHITE, accent, wgt * 0.55f)
            lyricP.alpha = (255 * alpha * (1f - 0.2f * pauseAnim)).roundToInt().coerceIn(0, 255)
            val txt = lines[li].text.ifBlank { "♪" }
            c.drawText(fit(txt, lyricP, maxW), cx, y, lyricP)
        }
        lyricP.isFakeBoldText = false
        c.restore()
    }

    // ---------------------------------------------------------------- touch
    private fun fracAt(x: Float): Float {
        val l = dp(pad); val r = width - dp(pad)
        return ((x - l) / (r - l)).coerceIn(0f, 1f)
    }

    private fun hitTest(x: Float, y: Float): Int {
        for (i in 0..2) if (btnRects[i].contains(x, y)) return i
        val dur = MediaState.track?.durationMs ?: 0L
        if (st.showProgress && dur > 0 && progRect.contains(x, y)) return 3
        return -1
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y
                lastRawX = e.rawX; lastRawY = e.rawY
                dragging = false
                hit = hitTest(e.x, e.y)
                pressed = if (hit in 0..2) hit else -1
                if (hit == 3) { seekDrag = true; seekFrac = fracAt(e.x) }
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (hit == 3) {
                    seekFrac = fracAt(e.x)
                } else if (!dragging && hypot(e.x - downX, e.y - downY) > dp(10f)) {
                    dragging = true
                    pressed = -1
                }
                if (dragging) {
                    onDragBy((e.rawX - lastRawX).roundToInt(), (e.rawY - lastRawY).roundToInt())
                    lastRawX = e.rawX; lastRawY = e.rawY
                }
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (hit == 3) {
                    val dur = MediaState.track?.durationMs ?: 0L
                    if (dur > 0) MediaState.seekTo((seekFrac * dur).toLong())
                } else if (!dragging && hit in 0..2 && pressed == hit) {
                    when (hit) {
                        0 -> MediaState.prev()
                        1 -> MediaState.toggle()
                        2 -> MediaState.next()
                    }
                }
                if (dragging) onDragEnd()
                pressed = -1; hit = -1; dragging = false; seekDrag = false
                invalidate()
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                pressed = -1; hit = -1; dragging = false; seekDrag = false
                invalidate()
                return true
            }
        }
        return super.onTouchEvent(e)
    }
}
