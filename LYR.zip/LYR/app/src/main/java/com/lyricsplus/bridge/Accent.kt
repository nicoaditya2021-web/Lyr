package com.lyricsplus.bridge

import android.graphics.Bitmap
import android.graphics.Color

/** Dominant-ish accent color from album art (cached by bitmap identity). */
object Accent {
    val DEFAULT: Int = 0xFF22D3EE.toInt()
    private var lastBmp: Bitmap? = null
    private var lastColor: Int = DEFAULT

    fun of(b: Bitmap?): Int {
        if (b == null) return DEFAULT
        if (b === lastBmp) return lastColor
        lastBmp = b
        lastColor = try {
            val px = Bitmap.createScaledBitmap(b, 1, 1, true).getPixel(0, 0)
            val hsv = FloatArray(3)
            Color.colorToHSV(px, hsv)
            hsv[1] = hsv[1].coerceIn(0.4f, 1f)
            hsv[2] = maxOf(hsv[2], 0.8f)
            Color.HSVToColor(hsv)
        } catch (_: Exception) {
            DEFAULT
        }
        return lastColor
    }
}
