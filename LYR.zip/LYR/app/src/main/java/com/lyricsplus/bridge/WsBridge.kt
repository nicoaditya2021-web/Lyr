package com.lyricsplus.bridge

import android.util.Base64
import org.json.JSONObject
import java.io.InputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.MessageDigest
import java.util.UUID
import kotlin.concurrent.thread

/**
 * Minimal WebSocket SERVER (RFC 6455, text frames only) on 127.0.0.1:8765.
 * Minecraft Bedrock connects to it with:   /wsserver ws://127.0.0.1:8765
 * We then send "commandRequest" messages, e.g.  scriptevent lyr:l ...
 * which the LYR add-on receives via system.afterEvents.scriptEventReceive.
 */
class WsBridge {
    companion object {
        const val PORT = 8765
        private const val GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"

        /** last few events, shown in the app (3D tab) to diagnose connection problems */
        @Volatile var lastLog: String = ""
        private val logBuf = ArrayList<String>()

        fun log(msg: String) {
            val t = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
            synchronized(logBuf) {
                logBuf.add("[$t] $msg")
                while (logBuf.size > 8) logBuf.removeAt(0)
                lastLog = logBuf.joinToString("\n")
            }
        }
    }

    @Volatile private var running = false
    private var ss: ServerSocket? = null
    @Volatile private var client: Socket? = null
    private val lock = Any()
    // Network writes must NOT happen on the main thread (Android throws NetworkOnMainThreadException).
    private val sender = java.util.concurrent.Executors.newSingleThreadExecutor()

    val connected: Boolean
        get() = client?.let { !it.isClosed } ?: false

    fun start() {
        if (running) return
        running = true
        thread(isDaemon = true, name = "lp-ws") {
            try {
                ss = ServerSocket(PORT, 4, InetAddress.getByName("127.0.0.1"))
                log("server listening on 127.0.0.1:$PORT")
                while (running) {
                    val s = ss!!.accept()
                    thread(isDaemon = true) { serve(s) }
                }
            } catch (e: Exception) {
                log("server error: $e")
            }
        }
    }

    fun stop() {
        running = false
        try { sender.shutdownNow() } catch (_: Exception) {}
        try { ss?.close() } catch (_: Exception) {}
        synchronized(lock) { try { client?.close() } catch (_: Exception) {}; client = null }
    }

    /** Sends a Minecraft command (without leading slash). Returns false if nobody is connected. */
    fun sendCommand(cmd: String): Boolean {
        val body = JSONObject()
            .put("version", 1)
            .put("commandLine", cmd)
            .put("origin", JSONObject().put("type", "player"))
        val msg = JSONObject()
            .put("header", JSONObject()
                .put("version", 1)
                .put("requestId", UUID.randomUUID().toString())
                .put("messageType", "commandRequest")
                .put("messagePurpose", "commandRequest"))
            .put("body", body)
        if (!connected) return false
        val bytes = msg.toString().replace("\\/", "/").toByteArray(Charsets.UTF_8)
        return try {
            sender.execute {
                val ok = sendFrame(0x1, bytes)
                log("TX " + cmd.take(70) + if (ok) " (ok)" else " (FAILED)")
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    // ------------------------------------------------------------------ internals
    private fun serve(s: Socket) {
        try {
            s.tcpNoDelay = true
            val inp = s.getInputStream()
            val head = readHeaders(inp)
            if (head == null) { log("no HTTP headers received"); return }
            val key = Regex("Sec-WebSocket-Key:\\s*(.+)", RegexOption.IGNORE_CASE)
                .find(head)?.groupValues?.get(1)?.trim()
            if (key == null) { log("not a websocket request"); return }
            val acc = Base64.encodeToString(
                MessageDigest.getInstance("SHA-1").digest((key + GUID).toByteArray()), Base64.NO_WRAP
            )
            val resp = "HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\n" +
                    "Connection: Upgrade\r\nSec-WebSocket-Accept: $acc\r\n\r\n"
            synchronized(lock) {
                try { client?.close() } catch (_: Exception) {}
                client = s
                val o = s.getOutputStream()
                o.write(resp.toByteArray())
                o.flush()
            }
            log("handshake OK")
            readFrames(s, inp)
        } catch (e: Exception) {
            log("connection error: $e")
        } finally {
            log("socket closed")
            synchronized(lock) { if (client === s) client = null }
            try { s.close() } catch (_: Exception) {}
        }
    }

    private fun readHeaders(inp: InputStream): String? {
        val sb = StringBuilder()
        while (sb.length < 8192) {
            val b = inp.read()
            if (b < 0) return null
            sb.append(b.toChar())
            if (sb.endsWith("\r\n\r\n")) return sb.toString()
        }
        return null
    }

    private fun readFully(inp: InputStream, buf: ByteArray): Boolean {
        var off = 0
        while (off < buf.size) {
            val n = inp.read(buf, off, buf.size - off)
            if (n < 0) return false
            off += n
        }
        return true
    }

    private fun readFrames(s: Socket, inp: InputStream) {
        while (running && !s.isClosed) {
            val b0 = inp.read(); if (b0 < 0) return
            val b1 = inp.read(); if (b1 < 0) return
            val op = b0 and 0x0F
            val masked = (b1 and 0x80) != 0
            var len = (b1 and 0x7F).toLong()
            if (len == 126L) {
                len = ((inp.read() shl 8) or inp.read()).toLong()
            } else if (len == 127L) {
                len = 0
                repeat(8) { len = (len shl 8) or inp.read().toLong() }
            }
            if (len < 0 || len > 1_000_000L) { log("bad frame length $len"); return }
            val mask = ByteArray(4)
            if (masked && !readFully(inp, mask)) return
            val payload = ByteArray(len.toInt())
            if (!readFully(inp, payload)) return
            if (masked) for (i in payload.indices) payload[i] = (payload[i].toInt() xor mask[i % 4].toInt()).toByte()
            if (op == 0x1) log("RX " + String(payload, Charsets.UTF_8).take(160))
            when (op) {
                0x8 -> {                            // close
                    val code = if (payload.size >= 2)
                        ((payload[0].toInt() and 0xFF) shl 8) or (payload[1].toInt() and 0xFF) else -1
                    log("RX close frame, code=$code")
                    return
                }
                0x9 -> sendFrame(0xA, payload)      // ping -> pong
                else -> {}                          // Minecraft's own events/responses: ignored
            }
        }
    }

    private fun sendFrame(op: Int, data: ByteArray): Boolean {
        var result = false
        synchronized(lock) {
            val c = client
            if (c != null) {
                try {
                    val o = c.getOutputStream()
                    val n = data.size
                    o.write(0x80 or op)
                    if (n < 126) {
                        o.write(n)
                    } else if (n < 65536) {
                        o.write(126); o.write(n shr 8); o.write(n and 0xFF)
                    } else {
                        o.write(127)
                        for (i in 7 downTo 0) o.write(((n.toLong() shr (8 * i)) and 0xFF).toInt())
                    }
                    o.write(data)
                    o.flush()
                    result = true
                } catch (e: Exception) {
                    log("write error: $e")
                    if (e is java.io.IOException) {
                        try { c.close() } catch (_: Exception) {}
                        client = null
                    }
                }
            }
        }
        return result
    }
}
