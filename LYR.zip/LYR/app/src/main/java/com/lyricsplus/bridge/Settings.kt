package com.lyricsplus.bridge

import android.content.Context

/** All user settings (persisted in SharedPreferences). */
class Settings(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("lp_settings", Context.MODE_PRIVATE)

    companion object {
        /** 0 TL, 1 TC, 2 TR, 3 BL, 4 BC, 5 BR, 6 custom (dragged) */
        val POSITION_NAMES = listOf(
            "Top Left", "Top Center", "Top Right",
            "Bottom Left", "Bottom Center", "Bottom Right", "Custom (dragged)"
        )
        val FONT_NAMES: List<String> get() = Fonts.NAMES
        val WHERE_NAMES = listOf("Arc (eye level)", "Sky", "Land", "Scatter", "Wave", "Ring")
        val ANIM_NAMES = listOf("Fade", "Pop", "Rise", "Drop", "Slide", "Spin", "Zoom", "Typewriter", "Wave", "Mix")
        val COLOR_NAMES = listOf("White", "Album", "Gold", "Pink", "Cyan", "Lavender", "Mint", "Sunset")
        val COLOR_HEX = listOf(0xFFFFFF, 0x22D3EE, 0xFFD27F, 0xFF8FD8, 0x67E8F9, 0xC4B5FD, 0x86EFAC, 0xFFB36B)
        val PERF_NAMES = listOf("Normal", "Hemat", "Super hemat")
        val LOCK_NAMES = listOf("Ikuti pemain (natural)", "Tetap di satu arah")
        val RENDER_NAMES = listOf("Particle font (no box)", "Nametag (classic)")
        val SHADOW_NAMES = listOf("Off", "Soft", "Strong")
        val THEME_NAMES = listOf("Sistem", "Terang", "Gelap")
        val EXIT_NAMES = listOf("Fade", "Naik", "Turun", "Mengecil")
        val IDLE_NAMES = listOf("Diam", "Wave", "Bounce", "Float", "Sway", "Pulse")
        val CMODE_NAMES = listOf("Satu warna", "Pelangi per baris", "Pelangi mengalir", "Gradasi")
        val FLOOR_ROT_NAMES = listOf("0\u00B0", "90\u00B0", "180\u00B0", "270\u00B0")
    }

    var musicUi: Boolean
        get() = sp.getBoolean("musicUi", true)
        set(v) { sp.edit().putBoolean("musicUi", v).apply() }

    var lyrics: Boolean
        get() = sp.getBoolean("lyrics", true)
        set(v) { sp.edit().putBoolean("lyrics", v).apply() }

    var showCover: Boolean
        get() = sp.getBoolean("showCover", true)
        set(v) { sp.edit().putBoolean("showCover", v).apply() }

    var showProgress: Boolean
        get() = sp.getBoolean("showProgress", true)
        set(v) { sp.edit().putBoolean("showProgress", v).apply() }

    /** percent, 50..200 */
    var scale: Int
        get() = sp.getInt("scale", 100)
        set(v) { sp.edit().putInt("scale", v).apply() }

    /** percent, 25..200 */
    var animSpeed: Int
        get() = sp.getInt("animSpeed", 100)
        set(v) { sp.edit().putInt("animSpeed", v).apply() }

    /** percent, 0..100 */
    var bgOpacity: Int
        get() = sp.getInt("bgOpacity", 78)
        set(v) { sp.edit().putInt("bgOpacity", v).apply() }

    var position: Int
        get() = sp.getInt("position", 0)
        set(v) { sp.edit().putInt("position", v).apply() }

    var customX: Int
        get() = sp.getInt("customX", 24)
        set(v) { sp.edit().putInt("customX", v).apply() }

    var customY: Int
        get() = sp.getInt("customY", 24)
        set(v) { sp.edit().putInt("customY", v).apply() }

    // ---- floating lyrics + top pill
    var floatLyrics: Boolean
        get() = sp.getBoolean("floatLyrics", true)
        set(v) { sp.edit().putBoolean("floatLyrics", v).apply() }

    var topPill: Boolean
        get() = sp.getBoolean("topPill", true)
        set(v) { sp.edit().putBoolean("topPill", v).apply() }

    var floatCaps: Boolean
        get() = sp.getBoolean("floatCaps", true)
        set(v) { sp.edit().putBoolean("floatCaps", v).apply() }

    var floatAccent: Boolean
        get() = sp.getBoolean("floatAccent", false)
        set(v) { sp.edit().putBoolean("floatAccent", v).apply() }

    /** percent 50..200 */
    var floatSize: Int
        get() = sp.getInt("floatSize", 100)
        set(v) { sp.edit().putInt("floatSize", v).apply() }

    var floatFont: Int
        get() = sp.getInt("floatFont", 1)
        set(v) { sp.edit().putInt("floatFont", v).apply() }

    var floatShadow: Int
        get() = sp.getInt("floatShadow", 1)
        set(v) { sp.edit().putInt("floatShadow", v).apply() }

    // ---- 3D lyrics (LYR add-on via /wsserver)
    var w3dOn: Boolean
        get() = sp.getBoolean("w3dOn", true)
        set(v) { sp.edit().putBoolean("w3dOn", v).apply() }

    /** percent 50..250 */
    var w3dSize: Int
        get() = sp.getInt("w3dSize", 100)
        set(v) { sp.edit().putInt("w3dSize", v).apply() }

    /** blocks in front of the player, 3..14 */
    var w3dDist: Int
        get() = sp.getInt("w3dDist", 6)
        set(v) { sp.edit().putInt("w3dDist", v).apply() }

    var w3dFollow: Boolean
        get() = sp.getBoolean("w3dFollow", true)
        set(v) { sp.edit().putBoolean("w3dFollow", v).apply() }

    // ---- 3D look (add-on)
    var w3dFont: Int
        get() = sp.getInt("w3dFont", 0)
        set(v) { sp.edit().putInt("w3dFont", v).apply() }

    var w3dWhere: Int
        get() = sp.getInt("w3dWhere", 0)
        set(v) { sp.edit().putInt("w3dWhere", v).apply() }

    var w3dAnim: Int
        get() = sp.getInt("w3dAnim", 1)
        set(v) { sp.edit().putInt("w3dAnim", v).apply() }

    var w3dColor: Int
        get() = sp.getInt("w3dColor", 0)
        set(v) { sp.edit().putInt("w3dColor", v).apply() }

    var w3dShadow: Boolean
        get() = sp.getBoolean("w3dShadow", true)
        set(v) { sp.edit().putBoolean("w3dShadow", v).apply() }

    var w3dMode: Int
        get() = sp.getInt("w3dMode", 0)
        set(v) { sp.edit().putInt("w3dMode", v).apply() }

    var w3dMaxGlyphs: Int
        get() = sp.getInt("w3dMaxGlyphs", 60)
        set(v) { sp.edit().putInt("w3dMaxGlyphs", v).apply() }

    /** spacing of letters / words / rows in the 3D text, percent */
    var w3dSpacing: Int
        get() = sp.getInt("w3dSpacing", 110)
        set(v) { sp.edit().putInt("w3dSpacing", v).apply() }

    /** lyric timing offset in ms (-1500..1500) */
    var syncOffset: Int
        get() = sp.getInt("syncOffset", 0)
        set(v) { sp.edit().putInt("syncOffset", v).apply() }

    /** 0 normal, 1 battery saver, 2 max saver */
    var perf: Int
        get() = sp.getInt("perf", 0)
        set(v) { sp.edit().putInt("perf", v).apply() }

    fun frameMs(): Long = when (perf) { 0 -> 33L; 1 -> 50L; else -> 83L }


    /** glyph size of the 3D letters (percent of the nominal size); spacing stays the same */
    var w3dGlyphScale: Int
        get() = sp.getInt("w3dGlyphScale", 50)
        set(v) { sp.edit().putInt("w3dGlyphScale", v).apply() }

    /** 0 = lyrics follow the player, 1 = locked in one direction */
    var w3dLock: Int
        get() = sp.getInt("w3dLock", 0)
        set(v) { sp.edit().putInt("w3dLock", v).apply() }

    /** "Land" placement hugs the terrain */
    var w3dStick: Boolean
        get() = sp.getBoolean("w3dStick", true)
        set(v) { sp.edit().putBoolean("w3dStick", v).apply() }

    /** app theme: 0 follow system, 1 light, 2 dark */
    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) { sp.edit().putInt("theme", v).apply() }

    /** ids of developer messages already opened */
    var seenMessages: Set<String>
        get() = sp.getStringSet("seenMessages", emptySet()) ?: emptySet()
        set(v) { sp.edit().putStringSet("seenMessages", HashSet(v)).apply() }

    /** last remote developer messages (raw JSON) */
    var messagesCache: String
        get() = sp.getString("messagesCache", "") ?: ""
        set(v) { sp.edit().putString("messagesCache", v).apply() }

    // ---- LYR 1.0 placement and motion
    /** how far lines spread to the left and right of the player (0..100) */
    var w3dSpread: Int
        get() = sp.getInt("w3dSpread", 60)
        set(v) { sp.edit().putInt("w3dSpread", v).apply() }

    /** how much the text follows where the player looks (0 = stays, 100 = fully follows) */
    var w3dTurn: Int
        get() = sp.getInt("w3dTurn", 40)
        set(v) { sp.edit().putInt("w3dTurn", v).apply() }

    /** how far ahead the text leads while the player moves (0..100) */
    var w3dLead: Int
        get() = sp.getInt("w3dLead", 30)
        set(v) { sp.edit().putInt("w3dLead", v).apply() }

    /** text that reaches the ground lies flat */
    var w3dLay: Boolean
        get() = sp.getBoolean("w3dLay", true)
        set(v) { sp.edit().putBoolean("w3dLay", v).apply() }

    /** keep text out of blocks, the ground and ceilings */
    var w3dClip: Boolean
        get() = sp.getBoolean("w3dClip", true)
        set(v) { sp.edit().putBoolean("w3dClip", v).apply() }

    /** floor text rotation offset, in steps of 90 degrees (calibration) */
    var w3dFloorRot: Int
        get() = sp.getInt("w3dFloorRot", 0)
        set(v) { sp.edit().putInt("w3dFloorRot", v).apply() }

    /** reverse the floor text rotation direction (calibration) */
    var w3dFloorFlip: Boolean
        get() = sp.getBoolean("w3dFloorFlip", false)
        set(v) { sp.edit().putBoolean("w3dFloorFlip", v).apply() }

    var w3dExit: Int
        get() = sp.getInt("w3dExit", 0)
        set(v) { sp.edit().putInt("w3dExit", v).apply() }

    var w3dIdle: Int
        get() = sp.getInt("w3dIdle", 0)
        set(v) { sp.edit().putInt("w3dIdle", v).apply() }

    /** 0 solid, 1 rainbow per line, 2 flowing rainbow, 3 gradient to the second colour */
    var w3dColorMode: Int
        get() = sp.getInt("w3dColorMode", 0)
        set(v) { sp.edit().putInt("w3dColorMode", v).apply() }

    var w3dColor2: Int
        get() = sp.getInt("w3dColor2", 4)
        set(v) { sp.edit().putInt("w3dColor2", v).apply() }
}
