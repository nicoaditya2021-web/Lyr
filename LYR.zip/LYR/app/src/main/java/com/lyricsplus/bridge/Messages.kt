package com.lyricsplus.bridge

import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Developer messages (announcements, info from the author).
 * Built-in messages always work offline. To publish new ones without a new APK, host a JSON file and put its
 * raw URL in REMOTE_URL, for example a messages.json in your GitHub repo:
 * {"messages":[{"id":"2026-12-01","title":"Judul","body":"Isi pesan","date":"2026-12-01","tag":"Pengumuman","link":"https://..."}]}
 */
object Messages {
    const val REMOTE_URL = ""

    class Msg(val id: String, val title: String, val body: String, val date: String, val tag: String, val link: String)

    private fun builtin(): List<Msg> = listOf(
        Msg(
            "lyr-1-0-0", "Selamat datang di LYR 1.0.0",
            "Aplikasi dan add-on kini bernama LYR. Lirik 3D mengikuti gerakan pemain, tidak menembus blok, berbaring di tanah, dan tersebar ke kiri dan kanan. Semua fitur lama tetap ada.",
            "2026-11-21", "Pengumuman", ""
        ),
        Msg(
            "tips-3d", "Tips lirik 3D",
            "Di Minecraft (cheats ON) ketik sekali per sesi: /wsserver ws://127.0.0.1:8765. Lalu buka tab 3D untuk mengatur font, warna, dan animasi.",
            "2026-11-21", "Tips", ""
        ),
        Msg(
            "support", "Dukung admin",
            "Aplikasi ini gratis. Kalau terbantu, kamu bisa mendukung admin lewat Sociabuzz. Terima kasih banyak!",
            "2026-11-21", "Info", Support.URL
        )
    )

    private fun parse(json: String): List<Msg>? {
        return try {
            val arr = JSONObject(json).getJSONArray("messages")
            val out = ArrayList<Msg>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Msg(
                        o.optString("id", "r$i"), o.optString("title"), o.optString("body"),
                        o.optString("date"), o.optString("tag", "Info"), o.optString("link")
                    )
                )
            }
            if (out.isEmpty()) null else out
        } catch (_: Exception) {
            null
        }
    }

    /** remote messages (cached) first, then the built-in ones */
    fun load(st: Settings): List<Msg> {
        val remote = if (st.messagesCache.isNotEmpty()) parse(st.messagesCache) else null
        val ids = HashSet<String>()
        val out = ArrayList<Msg>()
        for (m in (remote ?: emptyList()) + builtin()) if (ids.add(m.id)) out.add(m)
        return out
    }

    fun unseen(st: Settings): Int {
        val seen = st.seenMessages
        return load(st).count { !seen.contains(it.id) }
    }

    fun markAllSeen(st: Settings) {
        st.seenMessages = load(st).map { it.id }.toSet()
    }

    /** callback gets null on success, or a short error text */
    fun fetch(st: Settings, done: (String?) -> Unit) {
        val main = Handler(Looper.getMainLooper())
        if (REMOTE_URL.isEmpty()) {
            main.post { done("Server pesan belum diatur. Menampilkan pesan bawaan.") }
            return
        }
        Thread {
            var err: String? = null
            try {
                val c = URL(REMOTE_URL).openConnection() as HttpURLConnection
                c.connectTimeout = 8000
                c.readTimeout = 8000
                val text = c.inputStream.bufferedReader().use { it.readText() }
                if (text.length > 200_000 || parse(text) == null) err = "Format pesan dari server tidak valid."
                else st.messagesCache = text
            } catch (_: Exception) {
                err = "Gagal mengambil pesan. Periksa koneksi internet."
            }
            main.post { done(err) }
        }.start()
    }
}
