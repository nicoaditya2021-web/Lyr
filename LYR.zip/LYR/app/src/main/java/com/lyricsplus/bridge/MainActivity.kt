package com.lyricsplus.bridge

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings as AndroidSettings
import android.text.Spannable
import android.text.SpannableString
import android.text.TextUtils
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import java.util.Calendar

@Suppress("DEPRECATION")
class MainActivity : Activity() {

    companion object {
        /** set right before recreate() (theme change) so the splash and popup are not replayed */
        private var skipIntro = false
        private const val PAGES = 6
        private const val ABOUT = 5
    }

    private lateinit var st: Settings
    private lateinit var kit: Kit
    private lateinit var root: FrameLayout
    private lateinit var pagesHost: FrameLayout
    private lateinit var nav: TabBar
    private lateinit var donate: DonatePopup
    private val pages = ArrayList<ViewGroup>()
    private var cur = 0
    private var prevPage = 0
    private var topInset = 0
    private var botInset = 0

    // Home
    private lateinit var hApp: TextView
    private lateinit var hMc: TextView
    private lateinit var hMusic: TextView
    private lateinit var hMorph: MorphCover
    private lateinit var hTitle: TextView
    private lateinit var hArtist: TextView
    private lateinit var hSource: TextView
    private lateinit var hProg: ProgressBarView
    private lateinit var hT0: TextView
    private lateinit var hT1: TextView
    private lateinit var hPlay: TransportBtn
    private lateinit var hNotif: TextView
    private lateinit var hOverlay: TextView
    private lateinit var btnService: TextView

    // Music
    private lateinit var mCover: ImageView
    private lateinit var mTitle: TextView
    private lateinit var mArtist: TextView
    private lateinit var mAlbum: TextView
    private lateinit var mNotif: TextView
    private lateinit var mSource: TextView
    private lateinit var mState: TextView
    private lateinit var mDur: TextView
    private lateinit var mLyr: TextView
    private lateinit var livePrev: TextView
    private lateinit var liveCur: TextView
    private lateinit var liveNext: TextView

    // 3D
    private lateinit var preview: LyricPreview
    private lateinit var stWs: TextView
    private lateinit var stWsLog: TextView

    // Settings
    private lateinit var sNotif: TextView
    private lateinit var sOverlay: TextView
    private lateinit var sMc: TextView

    private val ui = Handler(Looper.getMainLooper())
    private val refresh = object : Runnable {
        override fun run() {
            refreshStatus()
            ui.postDelayed(this, if (st.perf == 0) 400L else 700L)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dpf(v: Float) = v * resources.displayMetrics.density

    // ================================================================= lifecycle
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        st = Settings(this)
        T.resolve(this, st.theme)
        LyricsRepo.init(this)
        kit = Kit(this, st) { reload() }

        window.setBackgroundDrawable(ColorDrawable(T.bg))
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        root = FrameLayout(this)
        root.setBackgroundColor(T.bg)
        var flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        if (!T.dark) {
            flags = flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            if (Build.VERSION.SDK_INT >= 26) flags = flags or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        root.systemUiVisibility = flags

        // soft blue wash at the top
        val glow = View(this)
        val gd = GradientDrawable()
        gd.gradientType = GradientDrawable.RADIAL_GRADIENT
        gd.gradientRadius = dpf(420f)
        gd.setGradientCenter(0.15f, 0f)
        val rgb = T.accent and 0x00FFFFFF
        gd.colors = intArrayOf(rgb or (if (T.dark) 0x44000000 else 0x30000000), rgb)
        glow.background = gd
        root.addView(glow, FrameLayout.LayoutParams(-1, -1))

        pagesHost = FrameLayout(this)
        root.addView(pagesHost, FrameLayout.LayoutParams(-1, -1))
        for (i in 0 until PAGES) {
            val p = buildPage(i)
            p.visibility = if (i == 0) View.VISIBLE else View.GONE
            pages.add(p)
            pagesHost.addView(p, FrameLayout.LayoutParams(-1, -1))
        }

        nav = TabBar(this, listOf("Beranda", "3D", "Musik", "Pesan", "Setelan")) { show(it) }
        root.addView(nav, FrameLayout.LayoutParams(-1, dp(64)).apply {
            gravity = Gravity.BOTTOM
            leftMargin = dp(14); rightMargin = dp(14)
        })
        updateBadge()

        donate = DonatePopup(this, root)
        if (skipIntro) {
            skipIntro = false
            donate.showBadgeOnly()
        } else {
            val splash = SplashView(this) {
                ui.postDelayed({ if (!isFinishing) donate.show() }, 300)
            }
            root.addView(splash, FrameLayout.LayoutParams(-1, -1))
        }

        root.setOnApplyWindowInsetsListener { _, ins ->
            topInset = ins.systemWindowInsetTop
            botInset = ins.systemWindowInsetBottom
            applyInsets()
            ins
        }
        applyInsets()
        setContentView(root)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (st.theme == 0 && T.systemDark(this) != T.dark) {
            skipIntro = true
            recreate()
        }
    }

    override fun onResume() {
        super.onResume()
        ui.post(refresh)
    }

    override fun onPause() {
        ui.removeCallbacks(refresh)
        super.onPause()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            donate.isOpen -> donate.minimize()
            cur == ABOUT -> show(prevPage)
            else -> super.onBackPressed()
        }
    }

    private fun applyInsets() {
        (nav.layoutParams as FrameLayout.LayoutParams).bottomMargin = dp(10) + botInset
        nav.requestLayout()
        donate.setTopInset(topInset)
        for (p in pages) {
            p.setPadding(0, topInset, 0, 0)
            p.getChildAt(0).setPadding(dp(18), dp(18), dp(18), dp(64) + dp(10) + botInset + dp(32))
        }
    }

    private fun applyThemeChange() {
        skipIntro = true
        recreate()
    }

    // ================================================================= navigation
    private fun buildPage(i: Int): ScrollView = when (i) {
        0 -> buildHome()
        1 -> build3d()
        2 -> buildMusic()
        3 -> buildMessages()
        4 -> buildSettings()
        else -> buildAbout()
    }

    private fun replacePage(i: Int) {
        val old = pages[i]
        val idx = pagesHost.indexOfChild(old)
        val nw = buildPage(i)
        nw.visibility = old.visibility
        nw.alpha = old.alpha
        nw.translationY = old.translationY
        pagesHost.removeView(old)
        pagesHost.addView(nw, idx, FrameLayout.LayoutParams(-1, -1))
        pages[i] = nw
        applyInsets()
    }

    private fun rebuildLookPages() {
        replacePage(1)
        replacePage(2)
    }

    private fun show(i: Int) {
        if (i == cur) return
        val oldIdx = cur
        val old = pages[oldIdx]
        val nw = pages[i]
        cur = i
        old.animate().cancel()
        nw.animate().cancel()
        old.animate().alpha(0f).setDuration(120).withEndAction { if (cur != oldIdx) old.visibility = View.GONE }.start()
        nw.visibility = View.VISIBLE
        nw.alpha = 0f
        nw.translationY = dp(14).toFloat()
        nw.animate().alpha(1f).translationY(0f).setDuration(260).setInterpolator(DecelerateInterpolator()).start()
        if (i < ABOUT) nav.select(i)
        if (i == 3) {
            Messages.markAllSeen(st)
            updateBadge()
        }
    }

    private fun openAbout() {
        if (cur == ABOUT) return
        prevPage = cur
        show(ABOUT)
    }

    private fun updateBadge() {
        nav.badgeAt = if (Messages.unseen(st) > 0 && cur != 3) 3 else -1
        nav.invalidate()
    }

    private fun reload() {
        if (OverlayService.running) {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_RELOAD))
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            toast(url)
        }
    }

    private fun copyWs() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("cmd", "/wsserver ws://127.0.0.1:8765"))
        toast("Perintah disalin")
    }

    private fun testMc() {
        val svc = OverlayService.instance
        if (svc == null) toast("Mulai panel dulu") else svc.sendTest()
    }

    private fun openNotifSettings() = startActivity(Intent(AndroidSettings.ACTION_NOTIFICATION_LISTENER_SETTINGS))

    private fun openOverlaySettings() =
        startActivity(Intent(AndroidSettings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))

    private fun toggleService() {
        if (OverlayService.running) {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
        } else {
            ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
        }
        ui.postDelayed({ refreshStatus() }, 400)
    }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return "%d:%02d".format(s / 60, s % 60)
    }

    private fun sourceName(pkg: String): String = when {
        pkg.contains("spotify") -> "Spotify"
        pkg.contains("youtube") -> "YouTube Music"
        pkg.contains("deezer") -> "Deezer"
        pkg.contains("soundcloud") -> "SoundCloud"
        pkg.isEmpty() -> "-"
        else -> pkg.substringAfterLast('.').replaceFirstChar { it.uppercase() }
    }

    private fun setCover(iv: ImageView, b: Bitmap?) {
        if (b != null) iv.setImageBitmap(b)
        else iv.setImageDrawable(GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF7CC8FF.toInt(), 0xFF0A84FF.toInt())))
    }

    private fun fadeSwap(v: TextView, s: String) {
        if (v.text.toString() == s) return
        v.animate().cancel()
        v.animate().alpha(0f).setDuration(110).withEndAction {
            v.text = s
            v.animate().alpha(1f).setDuration(180).start()
        }.start()
    }

    private fun card(col: LinearLayout, pad: Int = 16, radius: Float = 18f): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
        c.background = T.rr(T.card, dpf(radius))
        if (!T.dark) c.elevation = dpf(1f)
        col.addView(c, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
        return c
    }

    // ================================================================= HOME
    private fun buildHome(): ScrollView {
        val (sv, col) = kit.page()
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val greet = when { h < 11 -> "Selamat pagi"; h < 15 -> "Selamat siang"; h < 18 -> "Selamat sore"; else -> "Selamat malam" }
        val stack = FrameLayout(this)
        for ((i, p) in Credits.ALL.withIndex()) {
            stack.addView(kit.avatar(p.res, 30, T.bg), FrameLayout.LayoutParams(dp(34), dp(34)).apply { leftMargin = dp(i * 22) })
        }
        stack.setOnClickListener { openAbout() }
        kit.pressDim(stack)
        kit.title(col, greet, "LYR", stack)

        val gs = kit.section(col, "Status")
        hApp = kit.rowStatus(gs, "Aplikasi", null)
        hMc = kit.rowStatus(gs, "Minecraft", null)
        hMusic = kit.rowStatus(gs, "Musik terdeteksi", null)

        val hero = card(col, 16, 24f)
        hMorph = MorphCover(this)
        hMorph.animated = st.perf < 2
        hero.addView(hMorph, LinearLayout.LayoutParams(-1, dp(190)))
        hTitle = kit.tv("Belum ada lagu", 22f, T.text, true)
        hTitle.gravity = Gravity.CENTER
        hTitle.maxLines = 2
        hTitle.ellipsize = TextUtils.TruncateAt.END
        hero.addView(hTitle, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        hArtist = kit.tv("Putar lagu di Spotify atau YouTube Music", 14f, T.sub)
        hArtist.gravity = Gravity.CENTER
        hArtist.maxLines = 2
        hero.addView(hArtist, kit.lp(-1, -2, 8))
        hSource = kit.tv("Menunggu musik", 11.5f, T.accent, true)
        hSource.setPadding(dp(12), dp(4), dp(12), dp(4))
        hSource.background = T.rr(T.accentSoft, dpf(12f))
        hero.addView(hSource, LinearLayout.LayoutParams(-2, -2).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(10) })
        hProg = ProgressBarView(this)
        hProg.onSeek = { f ->
            val t = MediaState.track
            if (t != null && t.durationMs > 0) MediaState.seekTo((f * t.durationMs).toLong())
        }
        hero.addView(hProg, LinearLayout.LayoutParams(-1, dp(24)))
        val times = LinearLayout(this)
        times.orientation = LinearLayout.HORIZONTAL
        hT0 = kit.tv("0:00", 12f, T.sub)
        hT1 = kit.tv("0:00", 12f, T.sub)
        times.addView(hT0, LinearLayout.LayoutParams(0, -2, 1f))
        times.addView(hT1)
        hero.addView(times, kit.lp(-1, -2, 10))
        val ctl = LinearLayout(this)
        ctl.orientation = LinearLayout.HORIZONTAL
        ctl.gravity = Gravity.CENTER
        val prev = TransportBtn(this, TransportBtn.PREV)
        prev.setOnClickListener { MediaState.prev() }
        hPlay = TransportBtn(this, TransportBtn.PLAY)
        hPlay.setOnClickListener { MediaState.toggle() }
        val next = TransportBtn(this, TransportBtn.NEXT)
        next.setOnClickListener { MediaState.next() }
        ctl.addView(prev, LinearLayout.LayoutParams(dp(52), dp(52)))
        ctl.addView(hPlay, LinearLayout.LayoutParams(dp(64), dp(64)).apply { leftMargin = dp(22); rightMargin = dp(22) })
        ctl.addView(next, LinearLayout.LayoutParams(dp(52), dp(52)))
        hero.addView(ctl, LinearLayout.LayoutParams(-1, -2))

        val gm = kit.section(col, "Mulai")
        hNotif = kit.rowStatus(gm, "Akses notifikasi (baca musik)") { openNotifSettings() }
        hOverlay = kit.rowStatus(gm, "Tampil di atas aplikasi lain") { openOverlaySettings() }
        btnService = kit.rowButton(gm, "Mulai panel") { toggleService() }
        kit.pillRow(gm, listOf(kit.pill("Tes di Minecraft") { testMc() }, kit.pill("Salin /wsserver") { copyWs() }))

        presetRow(col)
        return sv
    }

    private fun presetRow(col: LinearLayout) {
        val l = kit.tv("Tampilan cepat", 13f, T.sub)
        l.setPadding(dp(16), 0, 0, dp(8))
        col.addView(l, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(20) })
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val rowL = LinearLayout(this)
        rowL.orientation = LinearLayout.HORIZONTAL
        for (p in Presets.ALL) {
            val c = LinearLayout(this)
            c.orientation = LinearLayout.VERTICAL
            c.setPadding(dp(14), dp(12), dp(14), dp(12))
            c.background = T.rr(T.card, dpf(18f))
            if (!T.dark) c.elevation = dpf(1f)
            val name = kit.tv("\u25CF  ${p.name}", 17f, T.text, false)
            name.typeface = Fonts.get(this, p.font)
            val sp = SpannableString("\u25CF  ${p.name}")
            sp.setSpan(ForegroundColorSpan(p.dot or (0xFF shl 24)), 0, 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            name.text = sp
            c.addView(name)
            c.addView(kit.tv(p.desc, 11.5f, T.sub))
            kit.pressDim(c)
            c.setOnClickListener {
                Presets.apply(st, p)
                reload()
                rebuildLookPages()
                toast("Tampilan ${p.name} diterapkan")
            }
            rowL.addView(c, LinearLayout.LayoutParams(dp(150), -2).apply { rightMargin = dp(10) })
        }
        hs.addView(rowL)
        col.addView(hs, LinearLayout.LayoutParams(-1, -2))
    }

    // ================================================================= 3D LYRICS
    private fun build3d(): ScrollView {
        val (sv, col) = kit.page()
        kit.title(col, "Lirik 3D", "Preview langsung, font, warna, animasi")

        val gp = kit.section(col, "Preview (ketuk untuk ulang)")
        preview = LyricPreview(this, st)
        kit.round(preview, 16f)
        kit.custom(gp, preview, dp(190))
        kit.pillRow(gp, listOf(
            kit.pill("Putar ulang") { preview.restart() },
            kit.pill("Tes di Minecraft") { testMc() },
            kit.pill("Kunci arah di sini") {
                val svc = OverlayService.instance
                if (svc == null) toast("Mulai panel dulu") else svc.sendAnchor()
            }
        ))

        val look = kit.section(col, "Tampilan")
        kit.rowChoice(look, "Font", Fonts.NAMES, { st.w3dFont }, { st.w3dFont = it }, { Fonts.get(this, it) })
        kit.rowChoice(look, "Tempat muncul", Settings.WHERE_NAMES, { st.w3dWhere }, { st.w3dWhere = it })
        kit.rowChoice(look, "Animasi muncul", Settings.ANIM_NAMES, { st.w3dAnim }, { st.w3dAnim = it })
        kit.rowChoice(look, "Warna", Settings.COLOR_NAMES, { st.w3dColor }, { st.w3dColor = it }, null, Settings.COLOR_HEX)
        kit.rowChoice(look, "Mode warna", Settings.CMODE_NAMES, { st.w3dColorMode }, { st.w3dColorMode = it })
        kit.rowChoice(look, "Warna kedua (gradasi)", Settings.COLOR_NAMES, { st.w3dColor2 }, { st.w3dColor2 = it }, null, Settings.COLOR_HEX)
        kit.rowChoice(look, "Animasi keluar", Settings.EXIT_NAMES, { st.w3dExit }, { st.w3dExit = it })
        kit.rowChoice(look, "Gerak saat tampil", Settings.IDLE_NAMES, { st.w3dIdle }, { st.w3dIdle = it })
        kit.rowSwitch(look, "Bayangan lembut", null, { st.w3dShadow }) { st.w3dShadow = it }
        kit.rowSwitch(look, "ALL CAPS", null, { st.floatCaps }) { st.floatCaps = it }

        val mv = kit.section(col, "Gerak dan penempatan")
        kit.rowChoice(mv, "Arah lirik", Settings.LOCK_NAMES, { st.w3dLock }, { st.w3dLock = it })
        kit.rowSlider(mv, "Sebaran kiri dan kanan (%)", 0, 100, { st.w3dSpread }) { st.w3dSpread = it }
        kit.rowSlider(mv, "Ikuti arah pandang (%)", 0, 100, { st.w3dTurn }) { st.w3dTurn = it }
        kit.rowSlider(mv, "Dorongan saat bergerak (%)", 0, 100, { st.w3dLead }) { st.w3dLead = it }
        kit.rowSwitch(mv, "Anti tembus blok dan tanah", "Teks menjauh dari dinding dan langit-langit", { st.w3dClip }) { st.w3dClip = it }
        kit.rowSwitch(mv, "Berbaring di tanah", "Teks yang sampai ke tanah dibaringkan", { st.w3dLay }) { st.w3dLay = it }
        kit.rowSwitch(mv, "Tempel ke tanah", "Untuk tempat Land", { st.w3dStick }) { st.w3dStick = it }
        kit.rowChoice(mv, "Putaran teks lantai", Settings.FLOOR_ROT_NAMES, { st.w3dFloorRot }, { st.w3dFloorRot = it })
        kit.rowSwitch(mv, "Balik arah putaran lantai", null, { st.w3dFloorFlip }) { st.w3dFloorFlip = it }
        kit.pillRow(mv, listOf(kit.pill("Tes teks lantai") {
            val svc = OverlayService.instance
            if (svc == null) toast("Mulai panel dulu") else svc.sendFloorTest()
        }))
        kit.footnote(col, "Tes teks lantai: kalau tulisan di tanah terbalik atau miring, ubah Putaran lantai (90 derajat per langkah) atau Balik arah, lalu tes lagi. Cukup sekali.")

        val opt = kit.section(col, "Ukuran dan performa")
        kit.rowSlider(opt, "Skala huruf (%)", 20, 150, { st.w3dGlyphScale }) { st.w3dGlyphScale = it }
        kit.rowSlider(opt, "Jarak huruf dan baris (%)", 100, 260, { st.w3dSpacing }) { st.w3dSpacing = it }
        kit.rowSlider(opt, "3D Text Size (%)", 50, 250, { st.w3dSize }) { st.w3dSize = it }
        kit.rowSlider(opt, "3D Distance (blocks)", 3, 14, { st.w3dDist }) { st.w3dDist = it }
        kit.rowSlider(opt, "Batas huruf per baris", 20, 120, { st.w3dMaxGlyphs }) { st.w3dMaxGlyphs = it }
        kit.rowChoice(opt, "Renderer", Settings.RENDER_NAMES, { st.w3dMode }, { st.w3dMode = it })
        kit.rowSwitch(opt, "Kirim lirik ke add-on", null, { st.w3dOn }) { st.w3dOn = it }
        kit.rowSwitch(opt, "Teks mengikuti kamera", "Mode Nametag", { st.w3dFollow }) { st.w3dFollow = it }
        kit.footnote(col, "Jarak huruf menyesuaikan ukuran otomatis, jadi huruf tidak menyatu. Kata yang bertabrakan dipindah ke tempat kosong.")

        val gc = kit.section(col, "Koneksi Minecraft")
        stWs = kit.rowStatus(gc, "Status", null)
        kit.rowInfo(gc, "Perintah", "/wsserver ws://127.0.0.1:8765")
        stWsLog = kit.tv("(belum ada aktivitas)", 11f, T.sub)
        stWsLog.typeface = Typeface.MONOSPACE
        kit.custom(gc, stWsLog)
        kit.rowButton(gc, "Salin perintah") { copyWs() }
        kit.footnote(col, "Di Minecraft (cheats ON), ketik perintah di atas sekali per sesi.")
        return sv
    }

    // ================================================================= MUSIC
    private fun buildMusic(): ScrollView {
        val (sv, col) = kit.page()
        kit.title(col, "Musik", "Informasi lagu dan status deteksi")

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        mCover = ImageView(this)
        mCover.scaleType = ImageView.ScaleType.CENTER_CROP
        kit.round(mCover, 18f)
        setCover(mCover, MediaState.track?.cover)
        top.addView(mCover, LinearLayout.LayoutParams(dp(78), dp(78)))
        val tx = LinearLayout(this)
        tx.orientation = LinearLayout.VERTICAL
        mTitle = kit.tv("Belum ada lagu", 18f, T.text, true)
        mTitle.maxLines = 2
        mArtist = kit.tv("-", 14f, T.sub)
        mAlbum = kit.tv("", 12.5f, T.sub)
        tx.addView(mTitle)
        tx.addView(mArtist)
        tx.addView(mAlbum)
        top.addView(tx, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(14) })
        val c = card(col, 14, 22f)
        c.addView(top)

        val gd = kit.section(col, "Deteksi musik")
        mNotif = kit.rowStatus(gd, "Akses notifikasi") { openNotifSettings() }
        mSource = kit.rowInfo(gd, "Sumber", "-")
        mState = kit.rowInfo(gd, "Status", "-")
        mDur = kit.rowInfo(gd, "Durasi", "-")
        mLyr = kit.rowInfo(gd, "Lirik", "-")

        val gl = kit.section(col, "Lirik sekarang")
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        livePrev = kit.tv("", 14f, T.sub)
        livePrev.maxLines = 1
        livePrev.ellipsize = TextUtils.TruncateAt.END
        liveCur = kit.tv("\u266A  menunggu lirik", 20f, T.text, true)
        liveCur.maxLines = 2
        liveNext = kit.tv("", 14f, T.sub)
        liveNext.maxLines = 1
        liveNext.ellipsize = TextUtils.TruncateAt.END
        box.addView(livePrev, kit.lp(-1, -2, 4))
        box.addView(liveCur, kit.lp(-1, -2, 4))
        box.addView(liveNext)
        kit.custom(gl, box)

        val go = kit.section(col, "Lirik di layar")
        kit.rowSwitch(go, "Enable Lyrics", null, { st.lyrics }) { st.lyrics = it }
        kit.rowSwitch(go, "Floating lyrics", "Lirik melengkung di layar", { st.floatLyrics }) { st.floatLyrics = it }
        kit.rowSwitch(go, "Top karaoke pill", null, { st.topPill }) { st.topPill = it }
        kit.rowSlider(go, "Sync offset (ms)", -1500, 1500, { st.syncOffset }) { st.syncOffset = it }

        val gs = kit.section(col, "Gaya lirik")
        kit.rowSwitch(gs, "ALL CAPS", null, { st.floatCaps }) { st.floatCaps = it }
        kit.rowSwitch(gs, "Warna huruf = warna album", null, { st.floatAccent }) { st.floatAccent = it }
        kit.rowSlider(gs, "Lyric Size (%)", 50, 200, { st.floatSize }) { st.floatSize = it }
        kit.rowChoice(gs, "Font", Settings.FONT_NAMES, { st.floatFont }, { st.floatFont = it }, { Fonts.get(this, it) })
        kit.rowChoice(gs, "Shadow", Settings.SHADOW_NAMES, { st.floatShadow }, { st.floatShadow = it })
        return sv
    }

    // ================================================================= MESSAGES
    private fun buildMessages(): ScrollView {
        val (sv, col) = kit.page()
        kit.title(col, "Pesan", "Pengumuman dan info dari developer")
        val seen = st.seenMessages
        val list = Messages.load(st)
        for (m in list) messageCard(col, m, !seen.contains(m.id))
        val g = kit.section(col, null)
        kit.rowButton(g, "Segarkan pesan") {
            Messages.fetch(st) { err ->
                replacePage(3)
                toast(err ?: "Pesan diperbarui")
            }
        }
        return sv
    }

    private fun messageCard(col: LinearLayout, m: Messages.Msg, unseen: Boolean) {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        c.background = T.rr(T.card, dpf(18f))
        if (!T.dark) c.elevation = dpf(1f)
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        if (unseen) {
            val dot = View(this)
            val dg = GradientDrawable()
            dg.shape = GradientDrawable.OVAL
            dg.setColor(T.red)
            dot.background = dg
            top.addView(dot, LinearLayout.LayoutParams(dp(8), dp(8)).apply { rightMargin = dp(8) })
        }
        val chip = kit.tv(m.tag, 11.5f, T.accent, true)
        chip.setPadding(dp(10), dp(3), dp(10), dp(3))
        chip.background = T.rr(T.accentSoft, dpf(10f))
        top.addView(chip)
        top.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        top.addView(kit.tv(m.date, 12f, T.sub))
        c.addView(top)
        c.addView(kit.tv(m.title, 17f, T.text, true), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        val body = kit.tv(m.body, 14f, T.sub)
        body.setLineSpacing(0f, 1.15f)
        c.addView(body, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        if (m.link.isNotEmpty()) {
            c.addView(kit.pill("Buka tautan") { openUrl(m.link) }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(12) })
        }
        col.addView(c, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
    }

    // ================================================================= SETTINGS
    private fun buildSettings(): ScrollView {
        val (sv, col) = kit.page()
        kit.title(col, "Setelan", "Aplikasi, musik, Minecraft, tampilan")

        val gt = kit.section(col, "Tampilan aplikasi")
        kit.rowChoice(gt, "Tema", Settings.THEME_NAMES, { st.theme }, { st.theme = it; applyThemeChange() })

        val gp = kit.section(col, "Panel musik di game")
        kit.rowSwitch(gp, "Enable Music UI", null, { st.musicUi }) { st.musicUi = it }
        kit.rowSwitch(gp, "Show Album Cover", null, { st.showCover }) { st.showCover = it }
        kit.rowSwitch(gp, "Show Progress Bar", null, { st.showProgress }) { st.showProgress = it }
        kit.rowSlider(gp, "UI Scale (%)", 50, 200, { st.scale }) { st.scale = it }
        kit.rowSlider(gp, "Animation Speed (%)", 25, 200, { st.animSpeed }) { st.animSpeed = it }
        kit.rowSlider(gp, "Background Opacity (%)", 0, 100, { st.bgOpacity }) { st.bgOpacity = it }
        kit.rowChoice(gp, "Panel Position", Settings.POSITION_NAMES, { st.position }, { st.position = it })

        val gf = kit.section(col, "Performa (anti panas dan lag)")
        kit.rowChoice(gf, "Mode", Settings.PERF_NAMES, { st.perf }, { st.perf = it; hMorph.animated = it < 2 })
        kit.footnote(col, "Hemat menurunkan frame overlay dan animasi. Super hemat mematikan animasi latar.")

        val gm = kit.section(col, "Minecraft")
        sMc = kit.rowStatus(gm, "Koneksi", null)
        kit.rowButton(gm, "Salin perintah /wsserver") { copyWs() }
        kit.rowButton(gm, "Tes di Minecraft") { testMc() }

        val gi = kit.section(col, "Izin")
        sNotif = kit.rowStatus(gi, "Akses notifikasi") { openNotifSettings() }
        sOverlay = kit.rowStatus(gi, "Tampil di atas aplikasi lain") { openOverlaySettings() }

        val gs = kit.section(col, "Dukungan")
        kit.rowNav(gs, "Dukung admin", "Buka Sociabuzz") { Support.open(this) }
        kit.rowNav(gs, "Tampilkan popup dukungan", null) { donate.expand() }

        val ga = kit.section(col, "Lainnya")
        kit.rowNav(ga, "Tentang dan tim developer", null) { openAbout() }
        return sv
    }

    // ================================================================= ABOUT
    private fun buildAbout(): ScrollView {
        val (sv, col) = kit.page()
        val back = kit.pill("\u2039  Kembali") { show(prevPage) }
        col.addView(back, LinearLayout.LayoutParams(-2, -2).apply { bottomMargin = dp(8) })

        val logo = ImageView(this)
        logo.setImageDrawable(getDrawable(R.drawable.ic_launcher))
        logo.scaleType = ImageView.ScaleType.CENTER_CROP
        kit.round(logo, 22f)
        col.addView(logo, LinearLayout.LayoutParams(dp(88), dp(88)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(8) })
        val name = kit.tv("LYR", 26f, T.text, false)
        name.setTypeface(Fonts.get(this, 0), Typeface.BOLD)
        name.gravity = Gravity.CENTER
        col.addView(name, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (_: Exception) { "" }
        val vt = kit.tv("Versi $ver", 13f, T.sub)
        vt.gravity = Gravity.CENTER
        col.addView(vt, LinearLayout.LayoutParams(-1, -2))
        val tag = kit.tv("Lirik Minecraft, sinkron dengan musik dari Spotify, YouTube Music, dan pemutar lain.", 14f, T.sub)
        tag.gravity = Gravity.CENTER
        tag.setPadding(dp(24), dp(8), dp(24), 0)
        col.addView(tag, LinearLayout.LayoutParams(-1, -2))

        val gt = kit.section(col, "Tim developer")
        for (p in Credits.ALL) {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(dp(16), dp(10), dp(16), dp(10))
            r.addView(kit.avatar(p.res, 46, T.card))
            val tx = LinearLayout(this)
            tx.orientation = LinearLayout.VERTICAL
            tx.addView(kit.tv(p.name, 16f, T.text, true))
            tx.addView(kit.tv(p.role, 13f, T.sub))
            r.addView(tx, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(12) })
            kit.add(gt, r)
        }

        val gs = kit.section(col, "Dukungan")
        kit.rowNav(gs, "Dukung admin", "sociabuzz.com/aerion") { Support.open(this) }
        kit.rowNav(gs, "Tampilkan popup dukungan", null) { donate.expand() }

        val gi = kit.section(col, "Info")
        kit.rowInfo(gi, "Sumber musik", "Spotify, YouTube Music, dll.")
        kit.rowInfo(gi, "Lirik", "LRCLIB")
        kit.footnote(col, "Font: Outfit, Bricolage Grotesque, Erica One, Gloock, Lora, Nothing You Could Do, Big Shoulders, Pixelify Sans (SIL OFL).")
        return sv
    }

    // ================================================================= live refresh
    private fun refreshStatus() {
        val notif = NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
        val overlay = AndroidSettings.canDrawOverlays(this)
        val t = MediaState.track
        val playing = MediaState.playing
        val running = OverlayService.running
        val ws = OverlayService.wsConnected

        kit.setStatus(hApp, if (running) "Panel aktif" else "Panel mati", if (running) T.green else T.orange)
        kit.setStatus(hMc, if (ws) "Terhubung" else "Menunggu", if (ws) T.green else T.orange)
        kit.setStatus(hMusic, if (t != null) sourceName(t.pkg) else "Belum ada", if (t != null) T.green else T.orange)
        kit.setStatus(hNotif, if (notif) "Aktif" else "Atur", if (notif) T.green else T.red)
        kit.setStatus(hOverlay, if (overlay) "Aktif" else "Atur", if (overlay) T.green else T.red)
        kit.setStatus(mNotif, if (notif) "Aktif" else "Atur", if (notif) T.green else T.red)
        kit.setStatus(sNotif, if (notif) "Aktif" else "Atur", if (notif) T.green else T.red)
        kit.setStatus(sOverlay, if (overlay) "Aktif" else "Atur", if (overlay) T.green else T.red)
        kit.setStatus(sMc, if (ws) "Terhubung" else "Belum terhubung", if (ws) T.green else T.orange)
        kit.setStatus(stWs, if (ws) "Terhubung (lirik 3D aktif)" else "Belum terhubung", if (ws) T.green else T.orange)
        val btn = if (running) "Hentikan panel" else "Mulai panel"
        if (btnService.text.toString() != btn) btnService.text = btn
        btnService.setTextColor(if (running) T.red else T.accent)
        val log = if (WsBridge.lastLog.isEmpty()) "(belum ada aktivitas)" else WsBridge.lastLog
        if (stWsLog.text.toString() != log) stWsLog.text = log

        // home hero
        val title = t?.title ?: "Belum ada lagu"
        if (hTitle.text.toString() != title) hTitle.text = title
        val artist = t?.artist ?: "Putar lagu di Spotify atau YouTube Music"
        if (hArtist.text.toString() != artist) hArtist.text = artist
        val src = if (t == null) "Menunggu musik" else sourceName(t.pkg) + "  \u00B7  " + (if (playing) "Playing" else "Paused")
        if (hSource.text.toString() != src) hSource.text = src
        hMorph.bmp = t?.cover
        hPlay.playing = playing
        val pos = MediaState.position()
        val dur = t?.durationMs ?: 0L
        hProg.setProgress(if (dur > 0) pos.toFloat() / dur else 0f)
        hT0.text = fmt(pos)
        hT1.text = if (dur > 0) fmt(dur) else "0:00"

        // music page
        if (mTitle.text.toString() != title) mTitle.text = title
        mArtist.text = t?.artist ?: "-"
        mAlbum.text = t?.album ?: ""
        setCover(mCover, t?.cover)
        mSource.text = if (t != null) sourceName(t.pkg) else "-"
        mState.text = if (t == null) "Tidak ada musik" else if (playing) "Playing" else "Paused"
        mDur.text = if (dur > 0) fmt(dur) else "-"
        val lines = LyricsRepo.lines
        mLyr.text = if (lines.isNotEmpty()) "${lines.size} baris" else LyricsRepo.status

        if (cur == 2) {
            val i = LyricsRepo.indexAt(pos)
            val line = if (lines.isEmpty()) "" else (lines.getOrNull(i)?.text ?: "")
            livePrev.text = if (i > 0) (lines.getOrNull(i - 1)?.text ?: "") else ""
            liveNext.text = lines.getOrNull(i + 1)?.text ?: ""
            val shown = if (lines.isEmpty()) "\u266A  " + (if (t == null) "putar lagu untuk melihat lirik" else LyricsRepo.status.ifBlank { "tidak ada lirik" })
            else if (line.isBlank()) "\u266A" else line
            fadeSwap(liveCur, shown)
        }
    }
}
