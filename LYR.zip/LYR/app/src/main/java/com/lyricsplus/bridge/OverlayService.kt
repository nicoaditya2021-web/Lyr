package com.lyricsplus.bridge

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings as AndroidSettings
import android.view.Gravity
import android.view.WindowManager

/** Foreground service: draws the panel over Minecraft and runs the local bridge server. */
class OverlayService : Service() {

    companion object {
        const val ACTION_RELOAD = "com.lyricsplus.bridge.RELOAD"
        const val ACTION_STOP = "com.lyricsplus.bridge.STOP"
        @Volatile var running = false
        @Volatile var wsConnected = false
        @Volatile var instance: OverlayService? = null
        private const val CH = "lp_bridge"
        private const val NID = 1
    }

    private lateinit var wm: WindowManager
    private lateinit var st: Settings
    private var panel: PanelView? = null
    private var lp: WindowManager.LayoutParams? = null
    private var attached = false
    private var floatView: FloatView? = null
    private var floatAttached = false
    private var server: LocalServer? = null
    private var ws: WsBridge? = null
    private var wasConn = false
    private var lastCfg = ""
    private var lastKey = ""
    private var lastPlaying: Boolean? = null
    private var connAt = 0L
    private val handler = Handler(Looper.getMainLooper())

    private val poll = object : Runnable {
        override fun run() {
            tick()
            handler.postDelayed(this, 300)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        st = Settings(this)
        LyricsRepo.init(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startAsForeground()
        server = LocalServer().also { it.start() }
        ws = WsBridge().also { it.start() }
        running = true
        instance = this
        buildPanel()
        handler.post(poll)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_RELOAD -> buildPanel()
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(poll)
        removePanel()
        server?.stop()
        ws?.stop()
        running = false
        instance = null
        wsConnected = false
        super.onDestroy()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH, "LYR", NotificationManager.IMPORTANCE_LOW)
        )
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CH)
            .setContentTitle("LYR")
            .setContentText("Music panel active")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .setContentIntent(pi)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NID, n)
        }
    }

    private fun makeParams(): WindowManager.LayoutParams {
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        val m = (12 * resources.displayMetrics.density).toInt()
        when (st.position) {
            0 -> { p.gravity = Gravity.TOP or Gravity.START; p.x = m; p.y = m }
            1 -> { p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; p.y = m }
            2 -> { p.gravity = Gravity.TOP or Gravity.END; p.x = m; p.y = m }
            3 -> { p.gravity = Gravity.BOTTOM or Gravity.START; p.x = m; p.y = m }
            4 -> { p.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; p.y = m }
            5 -> { p.gravity = Gravity.BOTTOM or Gravity.END; p.x = m; p.y = m }
            else -> { p.gravity = Gravity.TOP or Gravity.START; p.x = st.customX; p.y = st.customY }
        }
        return p
    }

    private fun buildPanel() {
        removePanel()
        lastCfg = ""
        lp = makeParams()
        panel = PanelView(this, st, ::onDragBy, ::onDragEnd, ::onHidden)
        floatView = FloatView(this, st)
    }

    private fun makeFloatParams(): WindowManager.LayoutParams = WindowManager.LayoutParams(
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    )

    private fun removePanel() {
        val pv = panel
        if (pv != null && attached) {
            try { wm.removeView(pv) } catch (_: Exception) {}
        }
        attached = false
        panel = null
        val fv = floatView
        if (fv != null && floatAttached) {
            try { wm.removeView(fv) } catch (_: Exception) {}
        }
        floatAttached = false
        floatView = null
    }

    private fun onHidden() {
        val pv = panel ?: return
        if (attached) {
            try { wm.removeView(pv) } catch (_: Exception) {}
            attached = false
        }
    }

    private fun onDragBy(dx: Int, dy: Int) {
        val p = lp ?: return
        val pv = panel ?: return
        if (st.position != 6) {
            val loc = IntArray(2)
            pv.getLocationOnScreen(loc)
            p.gravity = Gravity.TOP or Gravity.START
            p.x = loc[0]
            p.y = loc[1]
            st.position = 6
        }
        val dm = resources.displayMetrics
        p.x = (p.x + dx).coerceIn(0, maxOf(0, dm.widthPixels - pv.width))
        p.y = (p.y + dy).coerceIn(0, maxOf(0, dm.heightPixels - pv.height))
        try { wm.updateViewLayout(pv, p) } catch (_: Exception) {}
    }

    private fun onDragEnd() {
        val p = lp ?: return
        st.customX = p.x
        st.customY = p.y
    }

    private fun trunc(s: String, maxBytes: Int): String {
        val b = s.toByteArray(Charsets.UTF_8)
        if (b.size <= maxBytes) return s
        var n = maxBytes
        while (n > 0 && (b[n].toInt() and 0xC0) == 0x80) n--
        return String(b, 0, n, Charsets.UTF_8)
    }

    private fun colorHex(): String {
        val c = if (st.w3dColor == 1) (Accent.of(MediaState.track?.cover) and 0xFFFFFF)
        else Settings.COLOR_HEX[st.w3dColor.coerceIn(0, Settings.COLOR_HEX.size - 1)]
        return String.format("%06X", c)
    }

    private fun color2Hex(): String =
        String.format("%06X", Settings.COLOR_HEX[st.w3dColor2.coerceIn(0, Settings.COLOR_HEX.size - 1)])

    private fun cfgString() = "on=${if (st.w3dOn) 1 else 0};mode=${st.w3dMode};style=${st.w3dStyle};skystyle=${st.w3dSkyStyle};track=${if (st.w3dTrack) 1 else 0};wmode=${if (st.w3dWordMode == 0) 1 else 0};hold=${st.w3dHold};bubble=${if (st.w3dBubble) 1 else 0};rs=${if (st.w3dRollFlip) -1 else 1};font=${st.w3dFont};" +
            "anim=${st.w3dAnim};where=${st.w3dWhere};col=${colorHex()};col2=${color2Hex()};cm=${st.w3dColorMode};" +
            "shadow=${if (st.w3dShadow) 1 else 0};size=${st.w3dSize};dist=${st.w3dDist};caps=${if (st.floatCaps) 1 else 0};" +
            "follow=${if (st.w3dFollow) 1 else 0};maxg=${st.w3dMaxGlyphs};spd=${st.animSpeed};sp=${st.w3dSpacing};" +
            "gs=${st.w3dGlyphScale};lock=${st.w3dLock};stick=${if (st.w3dStick) 1 else 0};" +
            "spread=${st.w3dSpread};turn=${st.w3dTurn};lead=${st.w3dLead};lay=${if (st.w3dLay) 1 else 0};" +
            "clip=${if (st.w3dClip) 1 else 0};fo=${st.w3dFloorRot * 90};fs=${if (st.w3dFloorFlip) -1 else 1};" +
            "exit=${st.w3dExit};idle=${st.w3dIdle};rate=${when (st.perf) { 0 -> 100; 1 -> 150; else -> 250 }}"

    /** locks the lyric direction to where the player is facing right now */
    fun sendAnchor() {
        ws?.sendCommand("scriptevent lyr:cfg ${cfgString()}")
        ws?.sendCommand("scriptevent lyr:anchor")
    }

    /** the add-on setting string cut into short commands (each one stays well under chat command limits) */
    private fun sendCfg(w: WsBridge) {
        val parts = cfgString().split(";")
        val sb = StringBuilder()
        for (kv in parts) {
            if (sb.isNotEmpty() && sb.length + kv.length + 1 > 170) {
                w.sendCommand("scriptevent lyr:cfg $sb")
                sb.setLength(0)
            }
            if (sb.isNotEmpty()) sb.append(';')
            sb.append(kv)
        }
        if (sb.isNotEmpty()) w.sendCommand("scriptevent lyr:cfg $sb")
    }

    /** asks the add-on to show a demo line using the current look */
    fun sendTest() {
        ws?.let { sendCfg(it) }
        ws?.sendCommand("scriptevent lyr:test")
    }

    /** asks the add-on to lay a demo line flat on the floor (use it to calibrate the floor rotation) */
    fun sendFloorTest() {
        ws?.let { sendCfg(it) }
        ws?.sendCommand("scriptevent lyr:floor")
    }

    /** Sends lyric events to the Minecraft add-on (only while Minecraft is connected via /wsserver). */
    private fun pushToMinecraft() {
        val w = ws ?: return
        val conn = w.connected
        wsConnected = conn
        if (!conn) { wasConn = false; return }
        if (!wasConn) {
            wasConn = true; lastCfg = ""; lastKey = ""; lastPlaying = null
            connAt = System.currentTimeMillis()
        }
        if (System.currentTimeMillis() - connAt < 1500) return

        val cfg = cfgString()
        if (cfg != lastCfg) { lastCfg = cfg; sendCfg(w) }

        val playing = MediaState.playing
        if (playing != lastPlaying) {
            lastPlaying = playing
            w.sendCommand("scriptevent lyr:p ${if (playing) 1 else 0}")
            if (playing) lastKey = ""                      // show the current line again after resuming
        }
        val lines = LyricsRepo.lines
        if (!st.w3dOn || !playing || MediaState.track == null || lines.isEmpty()) return
        val pos = MediaState.position()
        val idx = LyricsRepo.indexAt(pos)
        val key = "${MediaState.trackId}:$idx"
        if (key == lastKey) return
        lastKey = key
        if (idx < 0) return
        val line = lines[idx]
        val next = lines.getOrNull(idx + 1)?.t ?: (line.t + 4000)
        val dur = (next - line.t).coerceIn(1200L, 8000L)
        val elapsed = (pos + LyricsRepo.offsetMs - line.t).coerceIn(0L, dur)
        val text = trunc(line.text.replace(Regex("[\\r\\n]+"), " ").trim(), 300)
        if (text.isEmpty()) return
        w.sendCommand("scriptevent lyr:l $elapsed|$dur|$text")
    }

    private fun tick() {
        LyricsRepo.offsetMs = st.syncOffset.toLong()
        pushToMinecraft()
        val tr = MediaState.track
        if (st.lyrics && tr != null) LyricsRepo.ensure(tr, MediaState.trackId)

        val wantFloat = (st.floatLyrics || st.topPill) && st.lyrics && tr != null &&
                AndroidSettings.canDrawOverlays(this)
        val fv = floatView
        if (fv != null) {
            if (wantFloat && !floatAttached) {
                try { wm.addView(fv, makeFloatParams()); floatAttached = true } catch (_: Exception) {}
            } else if (!wantFloat && floatAttached) {
                try { wm.removeView(fv) } catch (_: Exception) {}
                floatAttached = false
            }
        }

        val want = st.musicUi && tr != null
        val pv = panel ?: return
        if (want && !attached && AndroidSettings.canDrawOverlays(this)) {
            try {
                wm.addView(pv, lp)
                attached = true
            } catch (_: Exception) {
            }
        }
        pv.setTargetShown(want)
    }
}
