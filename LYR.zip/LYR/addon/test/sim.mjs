import fs from "fs";
import path from "path";
import { fileURLToPath, pathToFileURL } from "url";
import * as mock from "./mock.mjs";

const here = path.dirname(fileURLToPath(import.meta.url));
const bp = path.join(here, "..", "LYR_BP", "scripts");
// copy the script next to the mock so its import resolves
const tmp = path.join(here, ".run"); fs.mkdirSync(tmp, { recursive: true });
fs.copyFileSync(path.join(bp, "fonts.js"), path.join(tmp, "fonts.js"));
fs.copyFileSync(path.join(bp, "ink.js"), path.join(tmp, "ink.js"));
fs.writeFileSync(path.join(tmp, "main.js"), fs.readFileSync(path.join(bp, "main.js"), "utf8").replace('"@minecraft/server"', '"../mock.mjs"'));
globalThis.__LYR_TEST__ = { emits: [], bubbles: [], tags: [] };
mock.world.dim = mock.makeDim();
const P = mock.makePlayer(mock.world.dim);
mock.world.players.push(P);
await import(pathToFileURL(path.join(tmp, "main.js")).href);

const T = globalThis.__LYR_TEST__;
const GROUND = 64;
const D2R = Math.PI / 180;
const wrapA = (a) => { while (a > Math.PI) a -= 2 * Math.PI; while (a < -Math.PI) a += 2 * Math.PI; return a; };                       // blocks with y < 64 are solid
const fails = [];
const check = (ok, msg) => { if (!ok) fails.push(msg); console.log((ok ? "PASS " : "FAIL ") + msg); };

function reset(solid) {
    mock.state.solid = solid;
    mock.state.particles.length = 0; T.emits.length = 0; T.bubbles.length = 0; T.tags.length = 0; mock.state.entities.length = 0;
    Object.assign(P, { x: 0, y: GROUND, z: 0, vx: 0, vy: 0, vz: 0, yaw: 0, pitch: 0 });
    mock.send("lyr:clear", "", P);
    for (let i = 0; i < 30; i++) mock.advance();
    mock.state.particles.length = 0; T.emits.length = 0;
}
const CFG = "on=1;mode=0;style=1;track=1;wmode=0;bubble=0;font=0;anim=1;where=0;col=FFFFFF;shadow=1;size=100;dist=6;caps=1;maxg=48;spd=100;sp=110;gs=50;lock=0;stick=1;spread=60;turn=40;lead=30;lay=1;clip=1;exit=0;idle=0;rate=100";
const LINES = ["Under a midnight blue sky", "Your voice echoes through the blocks", "Every line a step closer", "And may this song never end", "We keep on walking toward the light tonight"];

// movement script: stand 20t, walk 60t, sprint 60t, jump 30t, turn while walking 60t, teleport
function run(solid, linesToSend, ticksPerLine, move) {
    reset(solid);
    mock.send("lyr:cfg", CFG, P);
    let li = 0;
    const total = linesToSend.length * ticksPerLine;
    for (let t = 0; t < total; t++) {
        if (t % ticksPerLine === 0) mock.send("lyr:l", `0|${ticksPerLine * 50}|${linesToSend[li++ % linesToSend.length]}`, P);
        move(t);
        mock.advance();
    }
}
function step(speed, yawRate = 0) {      // player moves along its facing
    P.yaw += yawRate;
    const fx = -Math.sin(P.yaw), fz = Math.cos(P.yaw);
    P.vx = fx * speed; P.vz = fz * speed;
    P.x += P.vx; P.z += P.vz;
}
const solidGround = (x, y, z) => y < GROUND;

// ---- 1. walking / running / jumping on open ground
run(solidGround, LINES, 80, (t) => {
    if (t < 60) step(0);
    else if (t < 140) step(0.215);          // walk 4.3 b/s
    else if (t < 220) step(0.28);           // sprint 5.6 b/s
    else if (t < 260) { step(0.1); const k = t - 220; P.y = GROUND + Math.max(0, 1.25 * Math.sin((k / 12) * Math.PI)); }
    else if (t < 320) step(0.2, 0.02);      // walking while turning
    else step(0);
});
const main = T.emits.filter((e) => !e.exit);
check(main.length > 300, `emits particles (${main.length})`);
check(main.every((e) => e.y >= GROUND + 0.03 - 1e-6), "no glyph is ever below the ground");
check(main.every((e) => !mock.state.solid(Math.floor(e.x), Math.floor(e.y), Math.floor(e.z))), "no glyph inside a block");
const dists = main.map((e) => Math.hypot(e.x - e.hx, e.z - e.hz));
check(Math.min(...dists) > 1.2 && Math.max(...dists) < 11, `glyph distance from player stays sane (${Math.min(...dists).toFixed(1)}..${Math.max(...dists).toFixed(1)})`);

// glyph velocity matches the player: while sprinting the particles carry ~5.6 b/s
const sprint = mock.state.particles.filter((p) => p.tick > 150 && p.tick < 210 && p.vars.vx !== undefined);
const sp = sprint.map((p) => Math.hypot(p.vars.vx, p.vars.vz));
check(sp.length > 0 && Math.max(...sp) > 5 && Math.max(...sp) < 6, `particles carry the player's velocity (max ${Math.max(...sp).toFixed(2)} b/s)`);
// follow: horizontal distance ahead of the player at spawn stays similar standing vs. sprinting
const meanAhead = (a, b) => { const s = main.filter((e) => e.now >= a && e.now < b); return s.reduce((m, e) => m + Math.hypot(e.x - e.hx, e.z - e.hz), 0) / s.length; };
const dStand = meanAhead(35, 60), dSprint = meanAhead(160, 215);
check(Math.abs(dStand - dSprint) < 2.0, `text keeps its distance while sprinting (${dStand.toFixed(2)} vs ${dSprint.toFixed(2)})`);
// jumping: glyph height must not follow the jump (stays stable)
const jump = main.filter((e) => e.now >= 222 && e.now < 262);
const ys = jump.map((e) => e.y);
check(ys.length > 0 && (Math.max(...ys) - Math.min(...ys)) < 4.5, `height stays stable while jumping (spread ${(Math.max(...ys) - Math.min(...ys)).toFixed(2)} incl. line layout)`);
// left/right spread
const side = main.map((e) => { const dx = e.x - e.hx; const dz = e.z - e.hz; return dx; });
// facing +z the player's right hand points to -x
const leftN = main.filter((e) => (e.x - e.hx) > 0.8).length, rightN = main.filter((e) => (e.x - e.hx) < -0.8).length;
check(leftN > 10 && rightN > 10, `lyrics spread to the left (${leftN}) and right (${rightN}) of the player`);
const centerN = main.filter((e) => Math.abs(e.x - e.hx) <= 0.8).length;
check(centerN < main.length * 0.5, `not everything piles up in front (${centerN} central glyphs)`);

// ---- 2. no overlap between words of overlapping lines
function wordsOverlap() {
    // group emits by (line, word), take the last emission of each word per tick window and test glyph distances across words
    const byTick = new Map();
    for (const e of main) { if (!byTick.has(e.now)) byTick.set(e.now, []); byTick.get(e.now).push(e); }
    let worst = 0, bad = 0, tested = 0;
    const win = main.filter((e) => e.now >= 70 && e.now < 130 || e.now >= 150 && e.now < 210);
    for (let i = 0; i < win.length; i += 3) {
        const a = win[i];
        for (let j = i + 1; j < win.length; j += 3) {
            const b = win[j];
            if (Math.abs(a.now - b.now) > 3) continue;
            if (a.line === b.line && a.word === b.word) continue;
            tested++;
            const dh = Math.hypot(a.x - b.x, a.z - b.z), dv = Math.abs(a.y - b.y);
            const limH = (a.qx + b.qx) * 0.9, limV = (a.q + b.q) * 0.6;       // cropped quads: real horizontal extent
            if (dh < limH && dv < limV) { bad++; worst = Math.max(worst, limH - dh); }
        }
    }
    return { bad, tested, worst };
}
const ov = wordsOverlap();
check(ov.bad === 0, `no glyphs of different words overlap (${ov.bad} of ${ov.tested} pairs)`);

// ---- 3. wall: a wall 3 blocks in front of the player must hold the text back
const wallSolid = (x, y, z) => y < GROUND || (z >= 3 && z <= 4 && y >= GROUND && y < GROUND + 6);
run(wallSolid, LINES.slice(0, 3), 60, () => step(0));
const wall = T.emits.filter((e) => !e.exit);
check(wall.length > 50 && wall.every((e) => !(e.z >= 3 && e.z <= 4.05 && e.y >= GROUND && e.y < GROUND + 6)), `glyphs never end up inside the wall (${wall.length} emits)`);
check(wall.every((e) => !(e.z > 4 && Math.abs(e.x) < 30)), "glyphs are not placed behind the wall");

// ---- 4. ground / lying text (Land) and floor test
reset(solidGround);
mock.send("lyr:cfg", CFG.replace("where=0", "where=2"), P);
mock.send("lyr:l", "0|4000|Lying on the ground now", P);
for (let t = 0; t < 70; t++) mock.advance();
const land = T.emits.filter((e) => !e.exit);
check(land.length > 20 && land.every((e) => e.flat), "Land mode lays every glyph flat");
check(land.every((e) => Math.abs(e.y - (GROUND + 0.03)) < 1e-6), "flat glyphs sit just above the block surface");
const flatP = mock.state.particles.filter((p) => p.id.startsWith("lyr:flat_"));
check(flatP.length > 0 && flatP.every((p) => typeof p.vars.tilt === "number" && !Number.isNaN(p.vars.tilt)), "flat particles carry a rotation");
// text in front of the player when facing +z
check(land.every((e) => e.z - e.hz > 0.5), "flat text lies in front of the player");

// ---- 5. low ceiling
const ceilSolid = (x, y, z) => y < GROUND || y >= GROUND + 3;
run(ceilSolid, LINES.slice(0, 3), 60, () => step(0));
const ce = T.emits.filter((e) => !e.exit);
check(ce.every((e) => e.y < GROUND + 3), "glyphs stay below a low ceiling");

// ---- 6. teleport: no stale text left behind and no crash
reset(solidGround);
mock.send("lyr:cfg", CFG, P);
mock.send("lyr:l", "0|4000|Before the teleport happens", P);
for (let t = 0; t < 20; t++) mock.advance();
P.x = 500; P.z = 500;
const tTp = mock.state.tick;
for (let t = 0; t < 10; t++) mock.advance();
const after = T.emits.filter((e) => e.now > tTp + 1);
check(after.length === 0 || after.every((e) => Math.hypot(e.x - 500, e.z - 500) < 20), "after a teleport nothing is emitted at the old place");

// ---- 6b. one long line while walking: text must keep gliding along with the player
reset(solidGround);
mock.send("lyr:cfg", CFG, P);
mock.send("lyr:l", "0|8000|Walking along with the lyrics around me", P);
const t6 = mock.state.tick;
for (let t = 0; t < 150; t++) { step(0.215); mock.advance(); }
const walk = T.emits.filter((e) => !e.exit);
const early = walk.filter((e) => e.now < t6 + 30), late = walk.filter((e) => e.now > t6 + 110 && e.now < t6 + 145);
const mean = (a) => a.reduce((m, e) => m + Math.hypot(e.x - e.hx, e.z - e.hz), 0) / a.length;
check(late.length > 20, `text is still emitted late in a long line (${late.length})`);
check(Math.abs(mean(early) - mean(late)) < 1.0, `distance stays the same after walking ${(150 * 0.215).toFixed(0)} blocks (${mean(early).toFixed(2)} -> ${mean(late).toFixed(2)})`);

// ---- 7. emission budget
reset(solidGround);
mock.send("lyr:cfg", CFG, P);
mock.send("lyr:l", "0|5000|Every word of this rather long lyric line stays readable while you run", P);
for (let t = 0; t < 100; t++) { step(0.28); mock.advance(); }
const perSec = mock.state.particles.length / (100 / 20);
console.log(`particle spawns per second while sprinting: ${perSec.toFixed(0)}`);
check(perSec < 700, `particle load is bounded (${perSec.toFixed(0)}/s incl. shadows)`);

// ---- 9. WORLD style (stays): words keep their place while the player walks away
{
    const C = CFG.replace("track=1", "track=0").replace("where=0", "where=3");
    reset(solidGround);
    mock.send("lyr:cfg", C, P);
    mock.send("lyr:l", "0|4000|Words stay right where they appeared", P);
    const t0 = mock.state.tick, hx0 = P.x, hz0 = P.z;
    for (let t = 0; t < 90; t++) { step(0.25); mock.advance(); }
    const em = T.emits.filter((e) => e.line === T.emits[0].line);
    const per = new Map();
    for (const e of em) { const k = e.word + ":" + e.gi; per.set(k, (per.get(k) || 0) + 1); }
    check(em.length > 20 && [...per.values()].every((v) => v === 1), `stay: every letter is emitted exactly once (${per.size} letters)`);
    check(em.every((e) => e.mode === "stay"), "stay: particles are long-life, not refreshed");
    const stayP = mock.state.particles.filter((p) => p.id.startsWith("lyr:glyph") && p.vars.a0 === 1);
    check(stayP.length > 0 && stayP.every((p) => p.vars.vx === 0 && p.vars.vz === 0), "stay: particles carry no player velocity");
    check(em.every((e) => Math.hypot(e.x - hx0, e.z - hz0) < 12), "stay: all letters appear around where the player stood");
    check(em.every((e) => e.life * 20 + 1 >= Math.max(1, (t0 + 80 - e.now)) ), "stay: lifetime covers the whole line");
    const spread = em.map((e) => Math.atan2(-(e.x - hx0), e.z - hz0));
    check(Math.max(...spread) - Math.min(...spread) > 1.2, `stay: words are scattered around the player (${((Math.max(...spread) - Math.min(...spread)) / D2R).toFixed(0)} deg)`);
    check(em.every((e) => !mock.state.solid(Math.floor(e.x), Math.floor(e.y), Math.floor(e.z)) && e.y >= GROUND), "stay: nothing inside blocks or ground");
}
// ---- 10. SKY style: in the skybox, never above the player, fixed direction like a real sky
{
    reset(solidGround);
    mock.send("lyr:cfg", CFG.replace("style=1", "style=0").replace("track=1", "track=0"), P);
    const rec = [];
    const yaw0 = P.yaw;
    for (let li = 0; li < 6; li++) {
        mock.send("lyr:l", `0|2500|${LINES[li % LINES.length]}`, P);
        for (let t = 0; t < 50; t++) { step(0.2, li >= 3 ? 0.02 : 0); mock.advance(); }
    }
    const em = T.emits.filter((e) => !e.exit);
    check(em.length > 200, `sky: emits (${em.length})`);
    const hd = (e) => Math.hypot(e.x - e.hx, e.z - e.hz);
    const el = (e) => Math.atan2(e.y - e.hy, hd(e)) / D2R;
    check(em.every((e) => hd(e) > 25), `sky: far away in the skybox (min ${Math.min(...em.map(hd)).toFixed(0)} blocks)`);
    check(em.every((e) => el(e) > 5 && el(e) < 62), `sky: above the horizon but never overhead (${Math.min(...em.map(el)).toFixed(0)}..${Math.max(...em.map(el)).toFixed(0)} deg)`);
    const roll = em.map((e) => Math.abs(e.roll));
    check(Math.max(...roll) > 5, `sky: words are tilted (max ${Math.max(...roll).toFixed(0)} deg)`);
    // direction stays fixed while walking and turning: same glyph, two refreshes -> same offset from the player
    const g0 = em.filter((e) => e.line === em[0].line && e.word === 0 && e.gi === 0);
    const dOff = Math.max(...g0.map((e) => Math.hypot((e.x - e.hx) - (g0[0].x - g0[0].hx), (e.z - e.hz) - (g0[0].z - g0[0].hz))));
    check(g0.length > 3 && dOff < 1.5, `sky: keeps its direction while you walk (${g0.length} refreshes, drift ${dOff.toFixed(2)} blocks)`);
}
// ---- 11. CHAT style: bubble above the head, follows the player, older lines are pushed up
{
    reset(solidGround);
    mock.send("lyr:cfg", CFG.replace("style=1", "style=2").replace("bubble=0", "bubble=1"), P);
    mock.send("lyr:l", "0|3000|Hello from the chat bubble", P);
    for (let t = 0; t < 30; t++) { step(0.2); mock.advance(); }
    const em = T.emits.filter((e) => !e.exit);
    const bub = T.bubbles.filter((b) => b.line === em[0].line);
    check(em.length > 10 && bub.length >= 10, `chat: text (${em.length}) and bubble pieces (${bub.length}) are emitted`);
    check(em.every((e) => e.y - e.hy > 0.4 && e.y - e.hy < 2.5 && Math.hypot(e.x - e.hx, e.z - e.hz) < 3.5), "chat: glyphs sit above the head and close to it");
    check(bub.every((b) => b.y - b.hy > 0.3 && Math.hypot(b.x - b.hx, b.z - b.hz) < 3.5), "chat: bubble sits above the head");
    check(bub.some((b) => b.cell[0] === 3 && b.cell[1] === 0) && bub.filter((b) => b.cell[0] < 3).length >= 9, "chat: bubble has all nine pieces and a tail");
    const first = em.filter((e) => e.gi === 0 && e.word === 0);
    const yA = first[first.length - 1].y - first[first.length - 1].hy;
    mock.send("lyr:l", "0|3000|And a second line follows", P);
    for (let t = 0; t < 14; t++) { step(0.2); mock.advance(); }
    const old = T.emits.filter((e) => e.line === em[0].line && e.gi === 0 && e.word === 0);
    const yB = old[old.length - 1].y - old[old.length - 1].hy;
    check(yB > yA + 0.3, `chat: older bubble is pushed up (${yA.toFixed(2)} -> ${yB.toFixed(2)})`);
    check(Math.hypot(first[first.length - 1].x - first[first.length - 1].hx, first[first.length - 1].z - first[first.length - 1].hz) < 3.5, "chat: follows the player while walking");
}

// ---- 12. WORLD word by word: each word appears in front of the CAMERA when it is sung, even while the player turns around
{
    const C = CFG.replace("track=1", "track=0").replace("wmode=0", "wmode=1").replace("where=0", "where=3");
    reset(solidGround);
    mock.send("lyr:cfg", C + ";hold=10", P);
    mock.send("lyr:l", "0|4000|Words appear one by one in front of me tonight", P);
    const t0 = mock.state.tick;
    const yawAt = new Map(), pitchAt = new Map();
    for (let t = 0; t < 120; t++) {
        P.yaw += 0.03;                                    // the player keeps turning: 3.6 rad in total
        P.pitch = t > 60 ? -0.3 : 0;                      // later it looks up (in the mock a negative pitch looks up)
        if (t > 40) step(0.2, 0);
        yawAt.set(mock.state.tick + 1, P.yaw); pitchAt.set(mock.state.tick + 1, P.pitch);
        mock.advance();
    }
    const em = T.emits.filter((e) => e.line === T.emits[0].line);
    const words = [...new Set(em.map((e) => e.word))];
    const firstOf = (w) => em.filter((e) => e.word === w).reduce((m, e) => (e.now < m.now ? e : m));
    const firstTick = words.map((w) => firstOf(w).now);
    check(words.length >= 6 && firstTick.every((v, i) => i === 0 || v >= firstTick[i - 1]), `per word: words appear one after another (${words.length} words)`);
    check(new Set(firstTick).size >= words.length - 1, "per word: each word has its own moment");
    const lifeMax = Math.max(...em.map((e) => e.life));
    check(lifeMax < 2.2, `per word: a word only stays briefly (max life ${lifeMax.toFixed(2)} s)`);
    let maxVis = 0, sumVis = 0;
    for (let tk = t0; tk < t0 + 110; tk++) {
        const vis = new Set(em.filter((e) => tk >= e.now && tk < e.now + (e.life - 0.4) * 20).map((e) => e.word));   // fully visible, not counting the fade-out
        maxVis = Math.max(maxVis, vis.size); sumVis += vis.size;
    }
    check(maxVis <= 5 && sumVis / 110 <= 2.5, `per word: only a few words visible at once (max ${maxVis}, average ${(sumVis / 110).toFixed(1)})`);
    // every word is inside a cone around the camera at the moment it appears (the camera turned about 200 degrees meanwhile)
    let worstAz = 0, worstEl = 0;
    for (const w of words) {
        const e = firstOf(w);
        const yaw = yawAt.get(e.now), pit = pitchAt.get(e.now);
        const camA = -yaw;                                 // direction the camera looks at (mock: x = -sin(yaw), z = cos(yaw))
        const az = Math.abs(wrapA(Math.atan2(e.x - e.hx, e.z - e.hz) - camA)) / D2R;
        const dh = Math.hypot(e.x - e.hx, e.z - e.hz);
        const el = Math.atan2(e.y - e.hy, dh) / D2R - (-pit) / D2R;
        worstAz = Math.max(worstAz, az); worstEl = Math.max(worstEl, Math.abs(el));
    }
    check(worstAz < 52, `per word: every word appears in front of the camera (worst ${worstAz.toFixed(0)} deg from the view direction)`);
    check(worstEl < 32, `per word: and follows where the camera looks up or down (worst ${worstEl.toFixed(0)} deg)`);
    let bad = 0;
    for (let i = 0; i < em.length; i += 2) for (let j = i + 1; j < em.length; j += 2) {
        const a = em[i], b = em[j];
        if (a.word === b.word) continue;
        if (a.now + a.life * 20 <= b.now || b.now + b.life * 20 <= a.now) continue;
        const dh = Math.hypot(a.x - b.x, a.z - b.z), dv = Math.abs(a.y - b.y);
        if (dh < (a.qx + b.qx) * 0.9 && dv < (a.q + b.q) * 0.6) bad++;
    }
    check(bad === 0, `per word: words visible together never overlap (${bad})`);
    // a line that starts in the middle does not replay the words that were already sung
    reset(solidGround);
    mock.send("lyr:cfg", C + ";hold=10", P);
    mock.send("lyr:l", "3000|4000|One two three four five six seven eight", P);
    for (let t = 0; t < 40; t++) mock.advance();
    const em2 = T.emits.filter((e) => e.line === T.emits[0].line);
    const w2 = new Set(em2.map((e) => e.text));
    check(w2.size > 0 && !w2.has("ONE") && !w2.has("TWO") && !w2.has("THREE") && !w2.has("FOUR") && !w2.has("FIVE"), `per word: words that were already sung are skipped (shown: ${[...w2].join(" ")})`);
}
// ---- 13. glyph quads are cropped to their ink: neighbours in a word do not cover each other
{
    const C = CFG.replace("track=1", "track=0").replace("where=0", "where=3");
    reset(solidGround);
    mock.send("lyr:cfg", C, P);
    mock.send("lyr:l", "0|4000|SUICIDE WILLOW MINIMUM", P);
    for (let t = 0; t < 70; t++) mock.advance();
    const em = T.emits.filter((e) => e.line === T.emits[0].line);
    let worst = 0, pairs = 0;
    const by = new Map();
    for (const e of em) { const k = e.word; if (!by.has(k)) by.set(k, []); by.get(k).push(e); }
    for (const [, gs] of by) {
        gs.sort((a, b) => a.gi - b.gi);
        for (let i = 0; i + 1 < gs.length; i++) {
            const a = gs[i], b = gs[i + 1];
            const d = Math.hypot(b.x - a.x, b.z - a.z) * Math.cos(0);
            const over = (a.qx + b.qx) - d;                    // positive = the quads overlap along the word
            worst = Math.max(worst, over / (a.qx + b.qx));
            pairs++;
        }
    }
    check(pairs > 10 && worst < 0.35, `ink crop: neighbouring letters overlap at most ${(worst * 100).toFixed(0)}% (${pairs} pairs)`);
    check(mock.state.particles.every((p) => p.vars.uw >= 2 && p.vars.uw <= 66), "ink crop: every particle has a sane uv width");
}
// ---- 14. CHAT (default, nametag): above the head, text grows word by word, older line is pushed up
{
    reset(solidGround);
    mock.send("lyr:cfg", CFG.replace("style=1", "style=2"), P);
    mock.send("lyr:l", "0|3200|Hello from the floating chat line", P);
    for (let t = 0; t < 45; t++) { step(0.2); mock.advance(); }
    const tags = T.tags.filter((g) => g.row === 0);
    check(tags.length > 20 && mock.state.entities.length >= 1, `chat tag: entity above the head (${mock.state.entities.length} entities)`);
    check(tags.every((g) => g.y - g.hy > 0.3 && g.y - g.hy < 1.2 && Math.hypot(g.x - g.hx, g.z - g.hz) < 2.5), "chat tag: sits right above the head and follows the player");
    const lens = [...new Set(tags.map((g) => g.text.length))];
    check(lens.length >= 4 && tags[tags.length - 1].text.length > tags[0].text.length, `chat tag: text grows word by word (${lens.length} steps)`);
    const yA = tags[tags.length - 1].y - tags[tags.length - 1].hy;
    mock.send("lyr:l", "0|3000|Another line arrives now", P);
    for (let t = 0; t < 20; t++) { step(0.2); mock.advance(); }
    const old = T.tags.filter((g) => g.line === tags[0].line && g.row === 0);
    const yB = old[old.length - 1].y - old[old.length - 1].hy;
    check(yB > yA + 0.2, `chat tag: older line is pushed up (${yA.toFixed(2)} -> ${yB.toFixed(2)})`);
    mock.send("lyr:clear", "", P);
    for (let t = 0; t < 30; t++) mock.advance();
    check(mock.state.entities.every((e) => e.removed), "chat tag: entities are removed afterwards");
}

// ---- 8. sweep of every setting combination: nothing may throw, go NaN, sink into the ground or enter a block
{
    let bad = 0, runs = 0;
    const wallish = (x, y, z) => y < GROUND || (x >= 6 && x <= 7 && y < GROUND + 5) || (x <= -7 && x >= -8 && y < GROUND + 5);
    const mulberry = (a) => () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
    for (let it = 0; it < 90; it++) {
        Math.random = mulberry(1000 + it);
        const pick = (n) => Math.floor(Math.random() * n);
        const style = it % 3, track = pick(2), wmode = pick(2), bubble = pick(2), where = it % 6, anim = pick(10), idle = pick(6), cm = pick(4), exit = pick(4), lock = pick(2), font = pick(8);
        const c = CFG.replace("style=1", "style=" + style).replace("track=1", "track=" + track).replace("wmode=0", "wmode=" + wmode).replace("bubble=0", "bubble=" + bubble).replace("where=0", "where=" + where).replace("anim=1", "anim=" + anim).replace("idle=0", "idle=" + idle)
            .replace("font=0", "font=" + font).replace("lock=0", "lock=" + lock).replace("exit=0", "exit=" + exit) + ";cm=" + cm + ";col2=3AA0FF;spread=" + pick(101);
        reset(wallish);
        mock.send("lyr:cfg", c, P);
        for (let t = 0; t < 140; t++) {
            if (t % 50 === 0) mock.send("lyr:l", `0|2500|${LINES[(t / 50 + it) % LINES.length | 0]}`, P);
            step(t < 100 ? 0.1 : 0, t > 40 && t < 90 ? 0.015 : 0);
            if (t === 70) P.y = GROUND + 1;
            if (t === 80) P.y = GROUND;
            mock.advance();
        }
        runs++;
        const em = T.emits;
        const nan = mock.state.particles.some((p) => Object.values(p.vars).some((v) => typeof v === "number" && !Number.isFinite(v)));
        const sunk = style === 1 && em.some((e) => !mock.state.solid(Math.floor(e.hx), Math.floor(e.hy), Math.floor(e.hz)) && (e.y < GROUND + 0.02 || mock.state.solid(Math.floor(e.x), Math.floor(e.y), Math.floor(e.z))));
        if (em.length + T.tags.length === 0 || nan || sunk) {
            bad++;
            const o = em.find((e) => !mock.state.solid(Math.floor(e.hx), Math.floor(e.hy), Math.floor(e.hz)) && (e.y < GROUND + 0.02 || mock.state.solid(Math.floor(e.x), Math.floor(e.y), Math.floor(e.z))));
            if (o) {
                const dx = o.x - o.hx, dy = o.y - o.hy, dz = o.z - o.hz, len = Math.hypot(dx, dy, dz);
                const hit = mock.world.dim.getBlockFromRay({ x: o.hx, y: o.hy, z: o.hz }, { x: dx / len, y: dy / len, z: dz / len }, { maxDistance: len });
                console.log("  it=" + it, "len", len.toFixed(2), "hit", JSON.stringify(hit && hit.block.location), "glyph block", Math.floor(o.x), Math.floor(o.y), Math.floor(o.z), "q", o.q.toFixed(2), JSON.stringify(o));
            }
        }
    }
    check(bad === 0, `settings sweep: ${runs} random combinations, ${bad} problems`);
}

console.log(fails.length ? `\n${fails.length} FAILED` : "\nALL PASSED");
process.exit(fails.length ? 1 : 0);
