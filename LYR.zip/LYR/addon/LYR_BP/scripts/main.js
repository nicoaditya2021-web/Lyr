// LYR 1.0.0 - floating 3D lyrics for Minecraft Bedrock, fed by the LYR app.
// Connect once per session:  /wsserver ws://127.0.0.1:8765
// Messages from the app:  /scriptevent lyr:<cmd> <message>
//   cfg   key=value;key=value;...   (see parseCfg)
//   p     1|0                         (playing / paused)
//   l     <elapsedMs>|<durMs>|<text>  (current lyric line)
//   test | floor | anchor | clear
//
// How it works
//  * A particle can't be moved after it is spawned, so every glyph is re-emitted every few ticks as a very
//    short-lived particle that also carries the player's velocity. The text therefore glides with the player
//    instead of staying where it spawned (walk, run, sprint, jump, teleport).
//  * Every word is placed on a stage around the player: lines alternate left/right (side spread), long lines
//    are split over both sides, and a collision pass keeps words from stacking on each other.
//  * Words are kept out of blocks (ray from the head, ground and ceiling clamps). Words that end up on the
//    ground are laid flat, like they are lying down.
import { world, system, MolangVariableMap } from "@minecraft/server";
import { FONTS, CHARMAP } from "./fonts.js";

const TEST = globalThis.__LYR_TEST__;      // only set by the offline test harness
const NS = "lyr:";
const ENT = "lyr:word";
const TICK_MS = 50;
const EXIT_TICKS = 8;
const HALF_K = 64 / 44 / 2;          // glyph quad half extent per em

const cfg = {
    on: true, mode: 0, font: 0, anim: 1, where: 0, col: [1, 1, 1], col2: [0.3, 0.7, 1], cm: 0, shadow: true,
    size: 100, dist: 6, caps: true, follow: true, maxg: 48, spd: 100, sp: 110, gs: 50,
    lock: 0, stick: 1, spread: 60, turn: 40, lead: 30, lay: 1, clip: 1, fo: 0, fs: 1,
    exit: 0, idle: 0, rate: 100,
};

const lines = [];       // active lines (the current one + the ones that are fading out)
let boxes = [];         // occupied areas, used to keep words apart
let target = null;
let greeted = false;
let lineId = 0;
let lineSeq = 0;
let lastText = "", lastTick = -999;

// ------------------------------------------------------------------ helpers
const rnd = (a, b) => a + Math.random() * (b - a);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;
function wrap(a) {
    while (a > Math.PI) a -= 2 * Math.PI;
    while (a < -Math.PI) a += 2 * Math.PI;
    return a;
}
function hsv(h, s, v) {
    const c = v * s, x = c * (1 - Math.abs(((h / 60) % 2) - 1)), m = v - c;
    const i = Math.floor((((h % 360) + 360) % 360) / 60);
    const t = [[c, x, 0], [x, c, 0], [0, c, x], [0, x, c], [x, 0, c], [c, 0, x]][i % 6];
    return [t[0] + m, t[1] + m, t[2] + m];
}
function hexCol(v) {
    return [parseInt(v.slice(0, 2), 16) / 255, parseInt(v.slice(2, 4), 16) / 255, parseInt(v.slice(4, 6), 16) / 255];
}

// ------------------------------------------------------------------ config
function parseCfg(msg) {
    for (const kv of msg.split(";")) {
        const i = kv.indexOf("=");
        if (i < 0) continue;
        const k = kv.slice(0, i), v = kv.slice(i + 1);
        const n = Number(v);
        if (k === "on") cfg.on = n === 1;
        else if (k === "mode") cfg.mode = n | 0;
        else if (k === "font") cfg.font = clamp(n | 0, 0, FONTS.length - 1);
        else if (k === "anim") cfg.anim = n | 0;
        else if (k === "where") cfg.where = n | 0;
        else if (k === "col" && /^[0-9a-fA-F]{6}$/.test(v)) cfg.col = hexCol(v);
        else if (k === "col2" && /^[0-9a-fA-F]{6}$/.test(v)) cfg.col2 = hexCol(v);
        else if (k === "cm") cfg.cm = n | 0;
        else if (k === "shadow") cfg.shadow = n === 1;
        else if (k === "size" && n > 0) cfg.size = n;
        else if (k === "dist" && n > 0) cfg.dist = n;
        else if (k === "caps") cfg.caps = n === 1;
        else if (k === "follow") cfg.follow = n === 1;
        else if (k === "maxg" && n > 0) cfg.maxg = n | 0;
        else if (k === "spd" && n > 0) cfg.spd = n;
        else if (k === "sp" && n > 0) cfg.sp = n;
        else if (k === "gs" && n > 0) cfg.gs = n;
        else if (k === "lock") cfg.lock = n | 0;
        else if (k === "stick") cfg.stick = n | 0;
        else if (k === "spread") cfg.spread = clamp(n, 0, 100);
        else if (k === "turn") cfg.turn = clamp(n, 0, 100);
        else if (k === "lead") cfg.lead = clamp(n, 0, 100);
        else if (k === "lay") cfg.lay = n | 0;
        else if (k === "clip") cfg.clip = n | 0;
        else if (k === "fo") cfg.fo = n;
        else if (k === "fs") cfg.fs = n < 0 ? -1 : 1;
        else if (k === "exit") cfg.exit = n | 0;
        else if (k === "idle") cfg.idle = n | 0;
        else if (k === "rate" && n > 0) cfg.rate = clamp(n, 50, 400);
    }
    if (!cfg.on) dropAll();
}

function pickPlayer(ev) {
    const s = ev.sourceEntity;
    if (s && s.typeId === "minecraft:player") return s;
    const i = ev.initiator;
    if (i && i.typeId === "minecraft:player") return i;
    return world.getAllPlayers()[0];
}

// ------------------------------------------------------------------ player tracking
const S = { init: false, p: null, dim: "", x: 0, y: 0, z: 0, hy: 0, vx: 0, vz: 0, ang: 0, lockAng: null };

function trackPlayer(p) {
    let h, v, vel, dim;
    try {
        if (p.isValid === false) return false;
        h = p.getHeadLocation();
        v = p.getViewDirection();
        vel = p.getVelocity();
        dim = p.dimension.id;
    } catch (e) { return false; }
    const hz = Math.hypot(v.x, v.z);
    const a = hz > 0.05 ? Math.atan2(v.x, v.z) : S.ang;       // fwd = (sin a, cos a)
    const far = S.init && (Math.hypot(h.x - S.x, h.z - S.z) > 20 || Math.abs(h.y - S.hy) > 20 || dim !== S.dim);
    if (!S.init || far || S.p !== p) {
        if (S.init && far) dropAll();                           // teleport / other dimension
        S.init = true; S.p = p; S.dim = dim;
        S.x = h.x; S.z = h.z; S.hy = h.y; S.y = h.y; S.vx = 0; S.vz = 0; S.ang = a;
    } else {
        S.vx += (vel.x - S.vx) * 0.5;
        S.vz += (vel.z - S.vz) * 0.5;
        S.x = h.x; S.z = h.z; S.hy = h.y;
        // height follows slowly, so jumping and stairs do not make the text bounce
        S.y += (h.y - S.y) * (Math.abs(h.y - S.y) > 2.5 ? 0.6 : 0.12);
        if (hz > 0.05) S.ang += wrap(a - S.ang) * 0.18;
    }
    return true;
}

function frameOf(L) {
    let a;
    if (cfg.lock === 1) {
        if (S.lockAng === null) S.lockAng = S.ang;
        a = S.lockAng;
    } else {
        a = L.ang0 + wrap(S.ang - L.ang0) * (cfg.turn / 100);
    }
    const lead = cfg.lead * 0.1;                                // ticks of travel to lead by
    return {
        a, fx: Math.sin(a), fz: Math.cos(a), rx: -Math.cos(a), rz: Math.sin(a),
        ox: S.x + S.vx * lead, oy: S.y, oz: S.z + S.vz * lead, hx: S.x, hy: S.hy, hz: S.z,
    };
}

// ------------------------------------------------------------------ world queries
function rayDist(dim, ox, oy, oz, dx, dy, dz, len) {
    const l = Math.hypot(dx, dy, dz);
    if (l < 1e-4) return null;
    const nx = dx / l, ny = dy / l, nz = dz / l;
    try {
        const hit = dim.getBlockFromRay({ x: ox, y: oy, z: oz }, { x: nx, y: ny, z: nz },
            { maxDistance: len, includeLiquidBlocks: false, includePassableBlocks: false });
        if (!hit || !hit.block) return null;
        // exact distance to the face that was hit (ray against the block's cube)
        const b = hit.block.location;
        let t0 = 0;
        const slab = (o, n, lo) => {
            if (Math.abs(n) < 1e-9) return;
            const a = (lo - o) / n, c = (lo + 1 - o) / n;
            t0 = Math.max(t0, Math.min(a, c));
        };
        slab(ox, nx, b.x); slab(oy, ny, b.y); slab(oz, nz, b.z);
        return Math.max(0.2, t0);
    } catch (e) { return null; }
}

function solidAt(dim, x, y, z) {
    try {
        const b = dim.getBlock({ x, y, z });
        if (!b) return false;
        if (typeof b.isSolid === "boolean") return b.isSolid;
        return !b.isAir && !b.isLiquid;
    } catch (e) { return false; }
}

// top face of the block under (x, z), searched downward from just above y
function groundY(dim, x, z, y) {
    try {
        const hit = dim.getBlockFromRay({ x, y: y + 0.6, z }, { x: 0, y: -1, z: 0 },
            { maxDistance: 18, includeLiquidBlocks: false, includePassableBlocks: false });
        if (hit && hit.block) return hit.block.location.y + 1;
    } catch (e) {}
    return null;
}

function ceilingY(dim, x, y, z) {
    try {
        const hit = dim.getBlockFromRay({ x, y, z }, { x: 0, y: 1, z: 0 },
            { maxDistance: 8, includeLiquidBlocks: false, includePassableBlocks: false });
        if (hit && hit.block) return hit.block.location.y;
    } catch (e) {}
    return null;
}

// ------------------------------------------------------------------ text helpers
function cleanText(text) {
    let out = "";
    for (const ch of text) {
        const c = ch.charCodeAt(0);
        if (c >= 32 && c <= 126) out += ch;
        else if (CHARMAP[ch] !== undefined) out += CHARMAP[ch];
    }
    out = out.replace(/\s+/g, " ").trim();
    return cfg.caps ? out.toUpperCase() : out;
}

// ------------------------------------------------------------------ layout
// Words get polar coordinates around the player: phi (to the right of the stage direction), y (above eye level)
// and d (distance). Glyphs sit on the word's tangent, du = offset from the word centre.
function packRows(words, maxW, gapW) {
    const rows = [[]];
    let rowW = 0;
    for (const w of words) {
        const cur = rows[rows.length - 1];
        const add = cur.length ? gapW + w.width * w.sc : w.width * w.sc;
        if (cur.length && rowW + add > maxW) { rows.push([w]); rowW = w.width * w.sc; }
        else { cur.push(w); rowW += add; }
    }
    return rows;
}

function layoutLine(L, text, dur, whereOverride) {
    const F = FONTS[cfg.font];
    const W = whereOverride === undefined ? cfg.where : whereOverride;
    const D = cfg.dist, sz = cfg.size / 100, gk = cfg.gs / 50;
    let Dp = D, emK = 0.06;
    if (W === 1) { Dp = D * 1.6; emK = 0.066; }
    if (W === 2) Dp = D * 1.1;
    const em = emK * Dp * sz * gk;
    const S2 = cfg.sp / 100;
    const track = 0.07 * em * S2;
    const advOf = (ch) => F.adv[ch.charCodeAt(0) - 32] * em + track;
    const gapW = (F.adv[0] + 0.12) * em * S2 + track;
    const rowH = em * (1.05 + 0.25 * S2);
    L.em = em; L.rowH = rowH; L.hx = em * HALF_K;

    // tokens (respecting the glyph budget)
    let budget = cfg.maxg;
    const words = [];
    for (const tok of text.split(" ").filter(Boolean)) {
        if (budget <= 0) break;
        const t = tok.length > budget ? tok.slice(0, budget) : tok;
        budget -= t.length;
        const w = { text: t, glyphs: [], width: 0, sc: 1, phi: 0, y: 0, d: Dp, landing: false, k: 1, off: 0, flat: false };
        let x = 0;
        for (const ch of t) {
            const a = advOf(ch) - track;
            w.glyphs.push({ idx: ch.charCodeAt(0) - 32, du: x + a / 2, dy: 0, last: -1e9, atTick: 0, ph: 0 });
            x += advOf(ch);
        }
        w.width = x - track;
        for (const g of w.glyphs) g.du -= w.width / 2;
        words.push(w);
    }
    if (!words.length) return [];

    // reveal times follow the singing: longer words take longer
    const weights = words.map((w) => w.text.length + 1);
    const wsum = weights.reduce((a, b) => a + b, 0) || 1;
    let acc = 0;
    words.forEach((w, i) => { w.at = (acc / wsum) * dur * 0.8; acc += weights[i]; });

    const seq = lineSeq++;
    const side = seq % 2 === 0 ? -1 : 1;
    const spreadK = cfg.spread / 100;
    const mag = spreadK * (52 * Math.PI / 180) * rnd(0.6, 1);
    const blocks = [];
    const mkBlock = (ws, landing) => blocks.push({ words: ws, landing });

    if (W === 3) {                                   // scatter: every word gets its own spot around the player
        const A = [[-55, 0.30], [0, 0.36], [55, 0.28], [-30, 0.04], [30, 0.00], [-62, -0.22], [0, -0.20], [62, -0.24]];
        const B = [[-48, 0.16], [4, 0.22], [50, 0.14], [-26, -0.10], [28, -0.14], [-58, -0.34], [0, -0.32], [58, -0.34]];
        const slots = seq % 2 ? B : A;
        const order = slots.map((_, i) => i).sort(() => Math.random() - 0.5);
        const wide = 0.4 + 0.9 * spreadK;
        words.forEach((w, i) => {
            const s = slots[order[i % slots.length]];
            w.phi = clamp((s[0] * Math.PI / 180) * wide, -1.3, 1.3);
            w.y = s[1] * Dp;
            w.d = Dp * rnd(0.95, 1.15);
            w.sc = Math.min(rnd(0.9, 1.25), (Dp * 0.55) / Math.max(w.width, 0.01));
            mkBlock([w], false);
        });
        return finishBlocks(L, blocks, rowH, em);
    }
    if (W === 5) {                                   // ring around the player
        const n = words.length;
        words.forEach((w, i) => {
            w.phi = ((n === 1 ? 0 : -110 + (220 * i) / (n - 1)) * Math.PI) / 180;
            w.y = (seq % 2 ? -0.05 : 0.18) * Dp;
            w.d = Dp;
            mkBlock([w], false);
        });
        return finishBlocks(L, blocks, rowH, em);
    }

    // rows (arc / sky / land / wave). Long lines are split over the left and right side.
    const split = spreadK >= 0.35 && words.length >= 6;
    const groups = split
        ? [words.slice(0, Math.ceil(words.length / 2)), words.slice(Math.ceil(words.length / 2))]
        : [words];
    const phis = split ? [-mag * 0.85, mag * 0.85] : [side * mag];
    const maxW = (split ? 0.62 : 1.0) * Dp;
    groups.forEach((gws, gi) => {
        const rows = packRows(gws, maxW, gapW);
        const phiC = phis[gi];
        const yTop = (W === 1 ? 0.62 * D : 0.18 * Dp) + rnd(-0.04, 0.04) * Dp;
        rows.forEach((row, r) => {
            const total = row.reduce((a, w, i) => a + w.width * w.sc + (i ? gapW : 0), 0);
            let x = -total / 2;
            for (const w of row) {
                const u = x + (w.width * w.sc) / 2;
                w.landing = W === 2;
                if (w.landing) {
                    w.d = Dp + (rows.length - 1 - r) * rowH;          // first row sits farthest, like a page lying on the ground
                    w.y = -1.7;
                } else {
                    w.d = Dp;
                    w.y = yTop - r * rowH;
                }
                w.phi = phiC + u / w.d;
                if (W === 4) for (const g of w.glyphs) g.dy = em * 0.55 * Math.sin((u + g.du) / (em * 2.2));
                x += w.width * w.sc + gapW;
            }
        });
        mkBlock(gws, W === 2);
    });
    return finishBlocks(L, blocks, rowH, em);
}

function boxOf(blk, em, rowH) {
    let a0 = Infinity, a1 = -Infinity, b0 = Infinity, b1 = -Infinity;
    for (const w of blk.words) {
        const hw = (w.width * w.sc / 2 + em * 0.25) / w.d;
        a0 = Math.min(a0, w.phi - hw); a1 = Math.max(a1, w.phi + hw);
        if (blk.landing) { b0 = Math.min(b0, w.d - rowH * 0.6); b1 = Math.max(b1, w.d + rowH * 0.6); }
        else { b0 = Math.min(b0, w.y - rowH * 0.55 * w.sc); b1 = Math.max(b1, w.y + rowH * 0.55 * w.sc); }
    }
    return { kind: blk.landing ? 1 : 0, a0, a1, b0, b1 };
}

function overlapArea(L, box) {
    const now = system.currentTick;
    let tot = 0;
    for (const B of boxes) {
        if (B.kind !== box.kind || B.expire <= now) continue;
        const sh = B.L === L ? 0 : wrap(L.ang0 - B.L.ang0);        // convert the other line's frame to ours
        const w = Math.min(box.a1, B.a1 + sh) - Math.max(box.a0, B.a0 + sh);
        const h = Math.min(box.b1, B.b1) - Math.max(box.b0, B.b0);
        if (w > 0 && h > 0) tot += w * h;
    }
    return tot;
}

// moves each block as a unit to a free spot so words never stack or merge
function finishBlocks(L, blocks, rowH, em) {
    const cand = [];
    for (const rr of [0, 1, -1, 2, -2, 3, -3]) for (const cc of [0, 1, -1, 2, -2]) cand.push([rr, cc, Math.abs(rr) + Math.abs(cc) * 1.3]);
    cand.sort((a, b) => a[2] - b[2]);
    for (const blk of blocks) {
        const base = boxOf(blk, em, rowH);
        const bh = base.b1 - base.b0 + rowH * 0.15, bw = base.a1 - base.a0 + 0.06;
        let best = [0, 0], bestOv = Infinity;
        for (const [rr, cc] of cand) {
            const da = cc * bw, db = rr * bh;
            const nb = { kind: base.kind, a0: base.a0 + da, a1: base.a1 + da, b0: base.b0 + db, b1: base.b1 + db };
            if (Math.abs(nb.a0) > 1.45 || Math.abs(nb.a1) > 1.45) continue;      // keep it around the player
            if (base.kind === 1 ? nb.b0 < 1.2 : (nb.b1 > cfg.dist * 1.3 || nb.b0 < -cfg.dist)) continue;
            const ov = overlapArea(L, nb);
            if (ov === 0) { best = [da, db]; bestOv = 0; break; }
            if (ov < bestOv) { bestOv = ov; best = [da, db]; }
        }
        for (const w of blk.words) {
            w.phi += best[0];
            if (blk.landing) w.d += best[1]; else w.y += best[1];
        }
        const fin = boxOf(blk, em, rowH);
        fin.L = L; fin.expire = Infinity;
        boxes.push(fin);
        L.boxes.push(fin);
    }
    return blocks.flatMap((b) => b.words);
}

// ------------------------------------------------------------------ placement of a word in the world (every emission)
function placeWord(L, w, F, now, upright) {
    if (w._t === now && w._u === !!upright) return w._pl;
    const dim = L.dim;
    const sinp = Math.sin(w.phi), cosp = Math.cos(w.phi);
    const dirx = F.fx * cosp + F.rx * sinp, dirz = F.fz * cosp + F.rz * sinp;
    const tx = F.rx * cosp - F.fx * sinp, tz = F.rz * cosp - F.fz * sinp;
    let cx = F.ox + dirx * w.d, cz = F.oz + dirz * w.d, cy = F.oy + w.y;
    const half = L.hx * w.sc;
    const wantLay = !upright && (cfg.lay || L.forceLay);
    let gy = null;
    if (cfg.clip || w.landing || wantLay) gy = groundY(dim, cx, cz, cy);

    if (cfg.clip) {                                   // 1) keep the whole word (centre and both ends) out of walls
        const ty = gy !== null ? Math.max(cy, gy + 0.6) : cy;
        const hw = (w.width * w.sc) / 2;
        let k = 1;
        for (const off of [0, -hw, hw]) {
            const px = cx + tx * off, pz = cz + tz * off;
            const vx = px - F.hx, vy = ty - F.hy, vz = pz - F.hz;
            const len = Math.hypot(vx, vy, vz);
            if (len < 0.6) continue;
            const hd = rayDist(dim, F.hx, F.hy, F.hz, vx, vy, vz, len);
            if (hd !== null) k = Math.min(k, clamp((hd - 0.6 - half) / len, 0.3, 1));
        }
        w.k = k < w.k ? k : w.k + (k - w.k) * 0.2;                      // closer = instantly, farther = eased
        if (w.k < 0.999) {
            cx = F.hx + (cx - F.hx) * w.k; cz = F.hz + (cz - F.hz) * w.k; cy = F.hy + (cy - F.hy) * w.k;
            if (gy !== null) gy = groundY(dim, cx, cz, cy);
        }
    }
    let ratio = Math.max(0.35, w.k);

    // 2) ground: lie flat when the word reaches the floor, otherwise stay above it
    let flat = false;
    if (gy !== null) {
        const hs = half * ratio;
        const lim = w.flat ? 0.7 : 0.35;                                 // hysteresis against flicker on bumpy ground
        if (wantLay && (w.landing || cy - hs < gy + lim)) {
            flat = true; cy = gy + 0.03;
        } else if (cfg.clip || (w.landing && cfg.stick)) {
            const want = Math.max(cy, gy + hs + 0.08);
            const off = want - cy;
            w.off = off > w.off ? off : w.off + (off - w.off) * 0.25;   // up = instantly, down = eased (stairs)
            cy += w.off;
        }
    }
    w.flat = flat;
    // 3) ceiling
    if (cfg.clip && !flat) {
        const c = ceilingY(dim, F.hx, F.hy, F.hz);
        if (c !== null) cy = Math.min(cy, c - half * ratio - 0.05);
    }
    // 4) last safety net: if the word (centre or either end) still sits inside a block, pull it toward the player
    if (cfg.clip && !flat) {
        for (let i = 0; i < 5; i++) {
            const e = (w.width * w.sc * ratio) / 2;
            if (!solidAt(dim, cx, cy, cz) && !solidAt(dim, cx + tx * e, cy, cz + tz * e) && !solidAt(dim, cx - tx * e, cy, cz - tz * e)) break;
            cx = F.hx + (cx - F.hx) * 0.85; cz = F.hz + (cz - F.hz) * 0.85; cy = F.hy + (cy - F.hy) * 0.85;
            w.k = Math.max(0.3, w.k * 0.85);
            ratio = Math.max(0.35, w.k);
        }
    }
    let tilt = 0;
    if (flat) {
        const yawOut = Math.atan2(-dirx, dirz) * 180 / Math.PI;
        tilt = cfg.fs * (yawOut - 180) + cfg.fo;
    }
    const pl = { cx, cy, cz, tx, tz, dirx, dirz, ratio, flat, tilt };
    w._t = now; w._u = !!upright; w._pl = pl;
    return pl;
}

// ------------------------------------------------------------------ animation parameters
function animParams(a, q, F) {
    const k = 100 / Math.max(25, cfg.spd);
    const P = { dur: 0.45, s0: 1, ox: 0, oy: 0, oz: 0, rot0: 0 };
    switch (a) {
        case 0: P.dur = 0.45; break;                                           // fade
        case 1: P.dur = 0.35; P.s0 = 0; break;                                 // pop
        case 2: P.dur = 0.5; P.oy = -q * 1.3; break;                           // rise
        case 3: P.dur = 0.5; P.oy = q * 1.3; break;                            // drop
        case 4: P.dur = 0.5; P.ox = -F.rx * q * 3; P.oz = -F.rz * q * 3; break; // slide
        case 5: P.dur = 0.55; P.s0 = 0.2; P.rot0 = 270; break;                 // spin
        case 6: P.dur = 0.5; P.s0 = 2.6; break;                                // zoom
        case 7: P.dur = 0.12; break;                                           // typewriter
        case 8: P.dur = 0.4; P.s0 = 0; break;                                  // wave (letters pop in one by one)
        default: break;
    }
    P.dur = Math.max(0.05, P.dur * k);
    return P;
}

function idleParams(q, F) {
    const I = { ix: 0, iy: 0, iz: 0, ib: 0, isp: 0, pa: 0 };
    switch (cfg.idle) {
        case 1: I.iy = q * 0.18; I.isp = 200; break;                            // wave
        case 2: I.iy = q * 0.22; I.ib = 1; I.isp = 280; break;                  // bounce
        case 3: I.iy = q * 0.14; I.isp = 110; break;                            // float
        case 4: I.ix = F.rx * q * 0.3; I.iz = F.rz * q * 0.3; I.isp = 140; break; // sway
        case 5: I.pa = 0.08; I.isp = 240; break;                                // pulse
        default: break;
    }
    return I;
}

function colorFor(L, g, now) {
    switch (cfg.cm) {
        case 1: return hsv((L.id * 53) % 360, 0.55, 1);
        case 2: return hsv((now * 3.2 + g.lt * 180 + L.id * 20) % 360, 0.6, 1);
        case 3: return [lerp(cfg.col[0], cfg.col2[0], g.lt), lerp(cfg.col[1], cfg.col2[1], g.lt), lerp(cfg.col[2], cfg.col2[2], g.lt)];
        default: return cfg.col;
    }
}

// ------------------------------------------------------------------ emitting
function glyphMap(v) {
    const m = new MolangVariableMap();
    for (const k in v) m.setFloat(k, v[k]);
    return m;
}

function emitGlyph(L, w, g, pl, F, now, life, exit) {
    const sc = pl.ratio * w.sc;
    const q = L.hx * sc;
    const x = pl.cx + pl.tx * g.du * sc;
    const z = pl.cz + pl.tz * g.du * sc;
    const y = pl.flat ? pl.cy : pl.cy + g.dy * sc;
    const ao = Math.max(0, ((now - g.atTick) * TICK_MS) / 1000);
    const AP = g.ap;
    const done = ao >= AP.dur + 0.05;
    const I = idleParams(q, F);
    const col = colorFor(L, g, now);
    const dyK = cfg.exit === 1 ? 1.2 : cfg.exit === 2 ? -1.2 : 0;
    const base = {
        u: (g.idx % 16) * 64, v: Math.floor(g.idx / 16) * 64, q, life, ao,
        dur: done ? 0.05 : AP.dur, s0: done ? 1 : AP.s0,
        ox: done ? 0 : AP.ox, oy: done ? 0 : AP.oy, oz: done ? 0 : AP.oz, rot0: done ? 0 : AP.rot0,
        tilt: pl.flat ? pl.tilt : 0, vx: S.vx * 20, vz: S.vz * 20,
        ix: I.ix, iy: I.iy, iz: I.iz, ib: I.ib, isp: I.isp, pa: I.pa, phase: g.ph,
        dy: exit ? dyK * q : 0, e1: exit && cfg.exit === 3 ? 0.2 : 1, fo: exit ? life : 0.12,
    };
    const id = (pl.flat ? "lyr:flat_" : "lyr:glyph_") + cfg.font;
    if (TEST) TEST.emits.push({ line: L.id, word: L.words.indexOf(w), gi: w.glyphs.indexOf(g), x, y, z, q, now, exit, flat: pl.flat, tilt: pl.tilt, hx: F.hx, hy: F.hy, hz: F.hz });
    try {
        if (cfg.shadow) {
            let sx = x, sy = y, sz = z;
            if (pl.flat) {
                sx += pl.tx * q * 0.06 - pl.dirx * q * 0.07; sz += pl.tz * q * 0.06 - pl.dirz * q * 0.07; sy -= 0.012;
            } else {
                const dx = x - F.hx, dy = y - F.hy, dz = z - F.hz, l = Math.hypot(dx, dy, dz) || 1;
                sx += (dx / l) * 0.03 + pl.tx * q * 0.05; sz += (dz / l) * 0.03 + pl.tz * q * 0.05; sy += (dy / l) * 0.03 - q * 0.07;
            }
            L.dim.spawnParticle(id, { x: sx, y: sy, z: sz }, glyphMap({ ...base, r: 0, g: 0, b: 0, a0: 0.45 }));
        }
        L.dim.spawnParticle(id, { x, y, z }, glyphMap({ ...base, r: col[0], g: col[1], b: col[2], a0: 1 }));
    } catch (e) {}
}

function beginExit(L) {
    if (L.exiting) return;
    L.exiting = true;
    L.exitDone = false;
    if (L.nt) removeNametags(L);
}

function removeNametags(L) {
    for (const w of L.words) { if (w.ent) { try { w.ent.remove(); } catch (e) {} w.ent = null; } }
}

function releaseBoxes(L, when) {
    for (const b of L.boxes) b.expire = when;
}

function doExit(L, now) {
    L.exitDone = true;
    L.die = now + EXIT_TICKS + 3;
    releaseBoxes(L, L.die);
    if (L.nt) { L.die = now; return; }
    const F = frameOf(L);
    const life = (EXIT_TICKS * TICK_MS) / 1000;
    for (const w of L.words) {
        let pl = null;
        for (const g of w.glyphs) {
            if (g.last < 0) continue;
            if (!pl) pl = placeWord(L, w, F, now, false);
            emitGlyph(L, w, g, pl, F, now, life, true);
        }
    }
}

function dropAll() {
    for (const L of lines) { if (L.nt) removeNametags(L); }
    lines.length = 0;
    boxes = [];
}

// ------------------------------------------------------------------ lines
function startLine(p, elapsed, dur, text, opts) {
    if (!cfg.on && !(opts && opts.force)) return;
    const t = cleanText(text);
    if (!t) return;
    if (!trackPlayer(p)) return;
    const now = system.currentTick;
    for (const L of lines) beginExit(L);
    const L = {
        id: ++lineId, born: now, ang0: S.ang, dim: p.dimension, exiting: false, exitDone: false, die: 0,
        boxes: [], words: [], nt: cfg.mode === 1, forceLay: !!(opts && opts.floor),
        endTick: now + Math.max(6, Math.round((dur - elapsed) / TICK_MS)),
    };
    L.words = layoutLine(L, t, dur, opts && opts.floor ? 2 : undefined);
    if (!L.words.length) return;
    const F = frameOf(L);
    const total = L.words.reduce((a, w) => a + w.glyphs.length, 0);
    const spdK = 100 / Math.max(25, cfg.spd);
    let n = 0;
    L.words.forEach((w, wi) => {
        w.atTick = now + Math.round(Math.max(0, w.at - elapsed) / TICK_MS);
        const an = cfg.anim === 9 ? [1, 2, 3, 4, 5, 6][(wi * 5 + ((Math.random() * 6) | 0)) % 6] : cfg.anim;
        w.glyphs.forEach((g, gi) => {
            let delay = 0;
            if (an === 7) delay = Math.round((gi * 45 * spdK) / TICK_MS);
            if (an === 8) delay = gi * 2;
            g.atTick = w.atTick + delay;
            g.ap = animParams(an, L.hx * w.sc, F);
            g.ph = (gi * 40 + wi * 90) % 360;
            g.lt = total > 1 ? n / (total - 1) : 0;
            n++;
        });
    });
    lines.push(L);
}

function tickLines() {
    if (!lines.length && !boxes.length) return;
    const now = system.currentTick;
    if (!target || !trackPlayer(target)) return;
    const moving = Math.hypot(S.vx, S.vz) > 0.02;
    const R = Math.max(2, Math.round((moving ? 4 : 6) * cfg.rate / 100));
    const life = ((R + 2) * TICK_MS) / 1000;
    boxes = boxes.filter((b) => b.expire > now);
    for (let i = lines.length - 1; i >= 0; i--) {
        const L = lines[i];
        if (!cfg.on) { if (L.nt) removeNametags(L); lines.splice(i, 1); continue; }
        if (!L.exiting && now >= L.endTick - EXIT_TICKS) beginExit(L);
        if (L.exiting) {
            if (!L.exitDone) doExit(L, now);
            if (now >= L.die) { releaseBoxes(L, 0); lines.splice(i, 1); }
            continue;
        }
        const F = frameOf(L);
        if (L.nt) { tickNametags(L, F, now); continue; }
        for (const w of L.words) {
            if (now < w.atTick) continue;
            let pl = null;
            for (const g of w.glyphs) {
                if (now < g.atTick || now - g.last < R) continue;
                if (!pl) pl = placeWord(L, w, F, now, false);
                emitGlyph(L, w, g, pl, F, now, life, false);
                g.last = now;
            }
        }
    }
}

// ------------------------------------------------------------------ nametag renderer (classic, Minecraft font + dark box)
function tickNametags(L, F, now) {
    for (const w of L.words) {
        if (now < w.atTick) continue;
        if (w.ent && now % 2 !== 0) continue;
        const pl = placeWord(L, w, F, now, true);
        try {
            if (!w.ent) {
                w.ent = L.dim.spawnEntity(ENT, { x: pl.cx, y: pl.cy, z: pl.cz });
                w.ent.nameTag = w.text;
            } else {
                w.ent.teleport({ x: pl.cx, y: pl.cy, z: pl.cz });
            }
        } catch (e) {}
    }
}

// ------------------------------------------------------------------ dispatch
function showLine(p, elapsed, dur, text) {
    if (!cfg.on) return;
    if (text === lastText && system.currentTick - lastTick < 20) return;      // same line twice would stack
    lastText = text; lastTick = system.currentTick;
    target = p;
    startLine(p, elapsed, dur, text);
}

system.afterEvents.scriptEventReceive.subscribe((ev) => {
    if (!ev.id.startsWith(NS)) return;
    const cmd = ev.id.slice(NS.length);
    const msg = ev.message || "";
    const p = pickPlayer(ev);
    if (p) target = p;

    if (cmd === "cfg") {
        parseCfg(msg);
        if (p && !greeted) { greeted = true; p.sendMessage("\u00a7a[LYR] connected to the app"); }
    } else if (cmd === "p") {
        if (msg.trim() !== "1") for (const L of lines) beginExit(L);
    } else if (cmd === "anchor" && p) {
        trackPlayer(p);
        S.lockAng = S.ang;
        p.sendMessage("\u00a7a[LYR] direction locked here");
    } else if (cmd === "clear") {
        for (const L of lines) beginExit(L);
    } else if (cmd === "test" && p) {
        lastText = "";
        startLine(p, 0, 4000, "LYR 3D sample line", { force: true });
    } else if (cmd === "floor" && p) {
        lastText = "";
        startLine(p, 0, 6000, "LYR FLOOR TEST", { force: true, floor: true });
    } else if (cmd === "l" && p) {
        const i1 = msg.indexOf("|");
        const i2 = msg.indexOf("|", i1 + 1);
        if (i1 < 0 || i2 < 0) return;
        showLine(p, Number(msg.slice(0, i1)) || 0, Number(msg.slice(i1 + 1, i2)) || 3000, msg.slice(i2 + 1));
    }
});

system.runInterval(() => {
    try { tickLines(); } catch (e) {}
}, 1);

system.run(() => {
    for (const id of ["overworld", "nether", "the_end"]) {
        try { for (const e of world.getDimension(id).getEntities({ type: ENT })) e.remove(); } catch (e) {}
    }
});
