// LYR 1.0.0 - 3D lyrics for Minecraft Bedrock, fed by the LYR app.
// Connect once per session:  /wsserver ws://127.0.0.1:8765
// Messages from the app:  /scriptevent lyr:<cmd> <message>
//   cfg   key=value;key=value;...   (see parseCfg)
//   p     1|0                         (playing / paused)
//   l     <elapsedMs>|<durMs>|<text>  (current lyric line)
//   test | floor | anchor | clear
//
// Three display styles (cfg style=)
//   0 SKY    words hang in the skybox: far away, above the horizon, tilted or on an arc. Like a real skybox they
//            keep their direction when you walk, and they never appear above your head.
//   1 WORLD  words appear one by one in front of you, in time with the singing (wmode=1), or the whole line is
//            scattered around you (wmode=0). They STAY where they appeared while you walk past (track=1 follows).
//   2 CHAT   the line floats above your head like a Roblox chat message and follows you (words appear as they are
//            sung); older lines are pushed up. bubble=1 draws an experimental white bubble with particles.
//
// A particle can't be moved once it is spawned, so moving text (CHAT, SKY, WORLD with track=1) is re-emitted
// every few ticks as very short particles that carry the player's velocity. WORLD text that stays put is emitted
// once with a long life.
import { world, system, MolangVariableMap } from "@minecraft/server";
import { FONTS, CHARMAP } from "./fonts.js";
import { INK } from "./ink.js";

const TEST = globalThis.__LYR_TEST__;      // only set by the offline test harness
const NS = "lyr:";
const ENT = "lyr:word";
const TICK_MS = 50;
const EXIT_TICKS = 8;
const HALF_K = 64 / 44 / 2;          // glyph quad half extent per em
const D2R = Math.PI / 180;

const cfg = {
    on: true, mode: 0, style: 1, skystyle: 2, track: 0, wmode: 1, hold: 10, bubble: 0,
    font: 0, anim: 1, where: 3, col: [1, 1, 1], col2: [0.3, 0.7, 1], cm: 0, shadow: true,
    size: 100, dist: 6, caps: true, follow: true, maxg: 48, spd: 100, sp: 110, gs: 50,
    lock: 0, stick: 1, spread: 60, turn: 40, lead: 30, lay: 1, clip: 1, fo: 0, fs: 1, rs: 1,
    exit: 0, idle: 0, rate: 100,
};

const lines = [];       // active lines (the current one + the ones that are fading out)
let boxes = [];         // occupied areas, used to keep words apart
let target = null;
let greeted = false;
let lineId = 0;
let lineSeq = 0;
let lastText = "", lastTick = -999;

// ------------------------------------------------------------------ helpers
const rnd = (a, b) => a + Math.random() * (b - a);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;
function wrap(a) {
    while (a > Math.PI) a -= 2 * Math.PI;
    while (a < -Math.PI) a += 2 * Math.PI;
    return a;
}
function hsv(h, s, v) {
    const c = v * s, x = c * (1 - Math.abs(((h / 60) % 2) - 1)), m = v - c;
    const i = Math.floor((((h % 360) + 360) % 360) / 60);
    const t = [[c, x, 0], [x, c, 0], [0, c, x], [0, x, c], [x, 0, c], [c, 0, x]][i % 6];
    return [t[0] + m, t[1] + m, t[2] + m];
}
function hexCol(v) {
    return [parseInt(v.slice(0, 2), 16) / 255, parseInt(v.slice(2, 4), 16) / 255, parseInt(v.slice(4, 6), 16) / 255];
}
function shuffle(a) {
    for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
    return a;
}

// ------------------------------------------------------------------ config
function parseCfg(msg) {
    for (const kv of msg.split(";")) {
        const i = kv.indexOf("=");
        if (i < 0) continue;
        const k = kv.slice(0, i), v = kv.slice(i + 1);
        const n = Number(v);
        if (k === "on") cfg.on = n === 1;
        else if (k === "mode") cfg.mode = n | 0;
        else if (k === "style") cfg.style = clamp(n | 0, 0, 2);
        else if (k === "skystyle") cfg.skystyle = clamp(n | 0, 0, 2);
        else if (k === "track") cfg.track = n | 0;
        else if (k === "wmode") cfg.wmode = n | 0;
        else if (k === "hold") cfg.hold = clamp(n, 5, 60);
        else if (k === "bubble") cfg.bubble = n | 0;
        else if (k === "font") cfg.font = clamp(n | 0, 0, FONTS.length - 1);
        else if (k === "anim") cfg.anim = n | 0;
        else if (k === "where") cfg.where = n | 0;
        else if (k === "col" && /^[0-9a-fA-F]{6}$/.test(v)) cfg.col = hexCol(v);
        else if (k === "col2" && /^[0-9a-fA-F]{6}$/.test(v)) cfg.col2 = hexCol(v);
        else if (k === "cm") cfg.cm = n | 0;
        else if (k === "shadow") cfg.shadow = n === 1;
        else if (k === "size" && n > 0) cfg.size = n;
        else if (k === "dist" && n > 0) cfg.dist = n;
        else if (k === "caps") cfg.caps = n === 1;
        else if (k === "follow") cfg.follow = n === 1;
        else if (k === "maxg" && n > 0) cfg.maxg = n | 0;
        else if (k === "spd" && n > 0) cfg.spd = n;
        else if (k === "sp" && n > 0) cfg.sp = n;
        else if (k === "gs" && n > 0) cfg.gs = n;
        else if (k === "lock") cfg.lock = n | 0;
        else if (k === "stick") cfg.stick = n | 0;
        else if (k === "spread") cfg.spread = clamp(n, 0, 100);
        else if (k === "turn") cfg.turn = clamp(n, 0, 100);
        else if (k === "lead") cfg.lead = clamp(n, 0, 100);
        else if (k === "lay") cfg.lay = n | 0;
        else if (k === "clip") cfg.clip = n | 0;
        else if (k === "fo") cfg.fo = n;
        else if (k === "fs") cfg.fs = n < 0 ? -1 : 1;
        else if (k === "rs") cfg.rs = n < 0 ? -1 : 1;
        else if (k === "exit") cfg.exit = n | 0;
        else if (k === "idle") cfg.idle = n | 0;
        else if (k === "rate" && n > 0) cfg.rate = clamp(n, 50, 400);
    }
    if (!cfg.on) dropAll();
}

function pickPlayer(ev) {
    const s = ev.sourceEntity;
    if (s && s.typeId === "minecraft:player") return s;
    const i = ev.initiator;
    if (i && i.typeId === "minecraft:player") return i;
    return world.getAllPlayers()[0];
}

// ------------------------------------------------------------------ player tracking
const S = { init: false, p: null, dim: "", x: 0, y: 0, z: 0, hy: 0, vx: 0, vz: 0, ang: 0, lockAng: null };

function trackPlayer(p) {
    let h, v, vel, dim;
    try {
        if (p.isValid === false) return false;
        h = p.getHeadLocation();
        v = p.getViewDirection();
        vel = p.getVelocity();
        dim = p.dimension.id;
    } catch (e) { return false; }
    const hz = Math.hypot(v.x, v.z);
    const a = hz > 0.05 ? Math.atan2(v.x, v.z) : S.ang;       // fwd = (sin a, cos a)
    const far = S.init && (Math.hypot(h.x - S.x, h.z - S.z) > 20 || Math.abs(h.y - S.hy) > 20 || dim !== S.dim);
    if (!S.init || far || S.p !== p) {
        if (S.init && far) dropAll();                           // teleport / other dimension
        S.init = true; S.p = p; S.dim = dim;
        S.x = h.x; S.z = h.z; S.hy = h.y; S.y = h.y; S.vx = 0; S.vz = 0; S.ang = a;
    } else {
        S.vx += (vel.x - S.vx) * 0.5;
        S.vz += (vel.z - S.vz) * 0.5;
        S.x = h.x; S.z = h.z; S.hy = h.y;
        // height follows slowly, so jumping and stairs do not make the text bounce
        S.y += (h.y - S.y) * (Math.abs(h.y - S.y) > 2.5 ? 0.6 : 0.12);
        if (hz > 0.05) S.ang += wrap(a - S.ang) * 0.18;
    }
    return true;
}

// The frame a line lives in: origin, forward/right axes, raw head position.
function frameOf(L) {
    let a;
    if (L.chat) a = S.ang;                                      // the bubble faces where you face
    else if (L.sky) a = L.ang0;                                 // skybox: fixed direction
    else if (L.static) a = L.ang0;
    else if (cfg.lock === 1) {
        if (S.lockAng === null) S.lockAng = S.ang;
        a = S.lockAng;
    } else {
        a = L.ang0 + wrap(S.ang - L.ang0) * (cfg.turn / 100);
    }
    const lead = L.sky || L.static ? 0 : cfg.lead * 0.1;        // ticks of travel to lead by
    return {
        a, fx: Math.sin(a), fz: Math.cos(a), rx: -Math.cos(a), rz: Math.sin(a),
        ox: S.x + S.vx * lead, oy: L.sky ? S.hy : S.y, oz: S.z + S.vz * lead, hx: S.x, hy: S.hy, hz: S.z,
    };
}

// ------------------------------------------------------------------ world queries
function rayDist(dim, ox, oy, oz, dx, dy, dz, len) {
    const l = Math.hypot(dx, dy, dz);
    if (l < 1e-4) return null;
    const nx = dx / l, ny = dy / l, nz = dz / l;
    try {
        const hit = dim.getBlockFromRay({ x: ox, y: oy, z: oz }, { x: nx, y: ny, z: nz },
            { maxDistance: len, includeLiquidBlocks: false, includePassableBlocks: false });
        if (!hit || !hit.block) return null;
        // exact distance to the face that was hit (ray against the block's cube)
        const b = hit.block.location;
        let t0 = 0;
        const slab = (o, n, lo) => {
            if (Math.abs(n) < 1e-9) return;
            const a = (lo - o) / n, c = (lo + 1 - o) / n;
            t0 = Math.max(t0, Math.min(a, c));
        };
        slab(ox, nx, b.x); slab(oy, ny, b.y); slab(oz, nz, b.z);
        return Math.max(0.2, t0);
    } catch (e) { return null; }
}

function solidAt(dim, x, y, z) {
    try {
        const b = dim.getBlock({ x, y, z });
        if (!b) return false;
        if (typeof b.isSolid === "boolean") return b.isSolid;
        return !b.isAir && !b.isLiquid;
    } catch (e) { return false; }
}

// top face of the block under (x, z), searched downward from just above y
function groundY(dim, x, z, y) {
    try {
        const hit = dim.getBlockFromRay({ x, y: y + 0.6, z }, { x: 0, y: -1, z: 0 },
            { maxDistance: 18, includeLiquidBlocks: false, includePassableBlocks: false });
        if (hit && hit.block) return hit.block.location.y + 1;
    } catch (e) {}
    return null;
}

function ceilingY(dim, x, y, z) {
    try {
        const hit = dim.getBlockFromRay({ x, y, z }, { x: 0, y: 1, z: 0 },
            { maxDistance: 8, includeLiquidBlocks: false, includePassableBlocks: false });
        if (hit && hit.block) return hit.block.location.y;
    } catch (e) {}
    return null;
}

// ------------------------------------------------------------------ text helpers
function cleanText(text) {
    let out = "";
    for (const ch of text) {
        const c = ch.charCodeAt(0);
        if (c >= 32 && c <= 126) out += ch;
        else if (CHARMAP[ch] !== undefined) out += CHARMAP[ch];
    }
    out = out.replace(/\s+/g, " ").trim();
    return cfg.caps ? out.toUpperCase() : out;
}

// Splits a line into words made of glyphs (du = offset from the word centre along its baseline).
function makeWords(text, em, S2, budget) {
    const F = FONTS[cfg.font];
    const track = 0.07 * em * S2;
    const advOf = (ch) => F.adv[ch.charCodeAt(0) - 32] * em + track;
    const gapW = (F.adv[0] + 0.12) * em * S2 + track;
    const words = [];
    for (const tok of text.split(" ").filter(Boolean)) {
        if (budget <= 0) break;
        const t = tok.length > budget ? tok.slice(0, budget) : tok;
        budget -= t.length;
        const w = { text: t, glyphs: [], width: 0, sc: 1, phi: 0, y: 0, d: 1, landing: false, k: 1, off: 0, flat: false, roll: 0, dx: 0, dy: 0 };
        let x = 0;
        for (const ch of t) {
            const a = advOf(ch) - track;
            w.glyphs.push({ idx: ch.charCodeAt(0) - 32, du: x + a / 2, dy: 0, last: -1e9, atTick: 0, ph: 0 });
            x += advOf(ch);
        }
        w.width = x - track;
        for (const g of w.glyphs) g.du -= w.width / 2;
        words.push(w);
    }
    return { words, gapW };
}

// reveal times follow the singing: longer words take longer
function assignAt(words, dur) {
    const weights = words.map((w) => w.text.length + 1);
    const wsum = weights.reduce((a, b) => a + b, 0) || 1;
    let acc = 0;
    words.forEach((w, i) => { w.at = (acc / wsum) * dur * 0.8; acc += weights[i]; });
}

// ------------------------------------------------------------------ layout helpers
function packRows(words, maxW, gapW) {
    const rows = [[]];
    let rowW = 0;
    for (const w of words) {
        const cur = rows[rows.length - 1];
        const add = cur.length ? gapW + w.width * w.sc : w.width * w.sc;
        if (cur.length && rowW + add > maxW) { rows.push([w]); rowW = w.width * w.sc; }
        else { cur.push(w); rowW += add; }
    }
    return rows;
}

function boxOf(blk, em, rowH) {
    let a0 = Infinity, a1 = -Infinity, b0 = Infinity, b1 = -Infinity;
    for (const w of blk.words) {
        const hw = (w.width * w.sc / 2 + em * 0.25) / w.d;
        a0 = Math.min(a0, w.phi - hw); a1 = Math.max(a1, w.phi + hw);
        if (blk.landing) { b0 = Math.min(b0, w.d - rowH * 0.6); b1 = Math.max(b1, w.d + rowH * 0.6); }
        else { b0 = Math.min(b0, w.y - rowH * 0.55 * w.sc); b1 = Math.max(b1, w.y + rowH * 0.55 * w.sc); }
    }
    return { kind: blk.landing ? 1 : 0, a0, a1, b0, b1 };
}

function overlapArea(L, box) {
    const now = system.currentTick;
    let tot = 0;
    for (const B of boxes) {
        if (B.kind !== box.kind || B.expire <= now || B.sky !== box.sky) continue;
        if (box.t1 !== undefined && B.t1 !== undefined && (B.t1 <= box.t0 || B.t0 >= box.t1)) continue;
        const sh = B.L === L ? 0 : wrap(L.ang0 - B.L.ang0);        // convert the other line's frame to ours
        const w = Math.min(box.a1, B.a1 + sh) - Math.max(box.a0, B.a0 + sh);
        const h = Math.min(box.b1, B.b1) - Math.max(box.b0, B.b0);
        if (w > 0 && h > 0) tot += w * h;
    }
    return tot;
}

// moves each block as a unit to a free spot so words never stack or merge
function finishBlocks(L, blocks, rowH, em, lim) {
    const cand = [];
    for (const rr of [0, 1, -1, 2, -2, 3, -3]) for (const cc of [0, 1, -1, 2, -2]) cand.push([rr, cc, Math.abs(rr) + Math.abs(cc) * 1.3]);
    cand.sort((a, b) => a[2] - b[2]);
    for (const blk of blocks) {
        const base = boxOf(blk, em, rowH);
        base.sky = !!L.sky;
        const bh = base.b1 - base.b0 + rowH * 0.15, bw = base.a1 - base.a0 + 0.06;
        let best = [0, 0], bestOv = Infinity;
        for (const [rr, cc] of cand) {
            const da = cc * bw, db = rr * bh;
            const nb = { kind: base.kind, sky: base.sky, t0: blk.t0, t1: blk.t1, a0: base.a0 + da, a1: base.a1 + da, b0: base.b0 + db, b1: base.b1 + db };
            if (Math.abs(nb.a0) > lim.amax || Math.abs(nb.a1) > lim.amax) continue;      // keep it around the player
            if (base.kind === 1 ? nb.b0 < 1.2 : (nb.b1 > lim.ymax || nb.b0 < lim.ymin)) continue;
            const ov = overlapArea(L, nb);
            if (ov === 0) { best = [da, db]; bestOv = 0; break; }
            if (ov < bestOv) { bestOv = ov; best = [da, db]; }
        }
        for (const w of blk.words) {
            w.phi += best[0];
            if (blk.landing) w.d += best[1]; else w.y += best[1];
        }
        const fin = boxOf(blk, em, rowH);
        fin.L = L; fin.expire = Infinity; fin.sky = !!L.sky; fin.t0 = blk.t0; fin.t1 = blk.t1;
        boxes.push(fin);
        L.boxes.push(fin);
    }
    return blocks.flatMap((b) => b.words);
}

// ------------------------------------------------------------------ WORLD layout (scatter / arc / land / wave / ring around the player)
// Words get polar coordinates around the player: phi (to the right of the stage direction), y (above eye level)
// and d (distance). Glyphs sit on the word's tangent, du = offset from the word centre.
function layoutWorld(L, text, dur, whereOverride) {
    const W = whereOverride === undefined ? cfg.where : whereOverride;
    const D = cfg.dist, sz = cfg.size / 100, gk = cfg.gs / 50;
    let Dp = D, emK = 0.06;
    if (W === 1) { Dp = D * 1.6; emK = 0.066; }
    if (W === 2) Dp = D * 1.1;
    const em = emK * Dp * sz * gk;
    const S2 = cfg.sp / 100;
    const { words, gapW } = makeWords(text, em, S2, cfg.maxg);
    const rowH = em * (1.05 + 0.25 * S2);
    L.em = em; L.rowH = rowH; L.hx = em * HALF_K;
    if (!words.length) return [];
    words.forEach((w) => { w.d = Dp; });
    assignAt(words, dur);

    const seq = lineSeq++;
    const side = seq % 2 === 0 ? -1 : 1;
    const spreadK = cfg.spread / 100;
    const mag = spreadK * (52 * D2R) * rnd(0.6, 1);
    const blocks = [];
    const mkBlock = (ws, landing) => blocks.push({ words: ws, landing });
    const lim = { amax: 1.9, ymax: D * 1.3, ymin: -D };

    if (W === 3) {                                   // scatter: every word gets its own spot around the player
        const A = [[-55, 0.30], [0, 0.36], [55, 0.28], [-30, 0.04], [30, 0.00], [-62, -0.22], [0, -0.20], [62, -0.24], [-92, 0.10], [92, 0.06]];
        const B = [[-48, 0.16], [4, 0.22], [50, 0.14], [-26, -0.10], [28, -0.14], [-58, -0.34], [0, -0.32], [58, -0.34], [-88, -0.05], [88, -0.08]];
        const slots = seq % 2 ? B : A;
        const order = shuffle(slots.map((_, i) => i));
        const wide = 0.45 + 1.1 * spreadK;
        words.forEach((w, i) => {
            const s = slots[order[i % slots.length]];
            w.phi = clamp(s[0] * D2R * wide, -1.75, 1.75);
            w.y = s[1] * Dp;
            w.d = Dp * rnd(0.95, 1.2);
            w.sc = Math.min(rnd(0.9, 1.3), (Dp * 0.55) / Math.max(w.width, 0.01));
            w.roll = rnd(-10, 10);
            mkBlock([w], false);
        });
        return finishBlocks(L, blocks, rowH, em, lim);
    }
    if (W === 5) {                                   // ring around the player
        const n = words.length;
        words.forEach((w, i) => {
            w.phi = ((n === 1 ? 0 : -110 + (220 * i) / (n - 1)) * Math.PI) / 180;
            w.y = (seq % 2 ? -0.05 : 0.18) * Dp;
            mkBlock([w], false);
        });
        return finishBlocks(L, blocks, rowH, em, lim);
    }

    // rows (arc / sky / land / wave). Long lines are split over the left and right side.
    const split = spreadK >= 0.35 && words.length >= 6;
    const groups = split
        ? [words.slice(0, Math.ceil(words.length / 2)), words.slice(Math.ceil(words.length / 2))]
        : [words];
    const phis = split ? [-mag * 0.85, mag * 0.85] : [side * mag];
    const maxW = (split ? 0.62 : 1.0) * Dp;
    groups.forEach((gws, gi) => {
        const rows = packRows(gws, maxW, gapW);
        const phiC = phis[gi];
        const yTop = (W === 1 ? 0.62 * D : 0.18 * Dp) + rnd(-0.04, 0.04) * Dp;
        rows.forEach((row, r) => {
            const total = row.reduce((a, w, i) => a + w.width * w.sc + (i ? gapW : 0), 0);
            let x = -total / 2;
            for (const w of row) {
                const u = x + (w.width * w.sc) / 2;
                w.landing = W === 2;
                if (w.landing) {
                    w.d = Dp + (rows.length - 1 - r) * rowH;          // first row sits farthest, like a page lying on the ground
                    w.y = -1.7;
                } else {
                    w.d = Dp;
                    w.y = yTop - r * rowH;
                }
                w.phi = phiC + u / w.d;
                if (W === 4) for (const g of w.glyphs) g.dy = em * 0.55 * Math.sin((u + g.du) / (em * 2.2));
                x += w.width * w.sc + gapW;
            }
        });
        mkBlock(gws, W === 2);
    });
    return finishBlocks(L, blocks, rowH, em, lim);
}

// ------------------------------------------------------------------ WORLD, word by word: each word pops up in front of you as it is sung
function layoutWordByWord(L, text, dur) {
    const D = cfg.dist, sz = cfg.size / 100, gk = cfg.gs / 50;
    const em = 0.06 * D * sz * gk * 1.2;
    const { words } = makeWords(text, em, cfg.sp / 100, cfg.maxg);
    L.em = em; L.rowH = em * 1.3; L.hx = em * HALF_K;
    if (!words.length) return [];
    assignAt(words, dur);
    const spreadK = cfg.spread / 100;
    const hold = Math.max(6, Math.round(cfg.hold * 2));            // ticks a word stays
    L.wordHold = hold;
    lineSeq++;
    const az = 16 + 34 * spreadK;                                   // half width of the cone in front of you (degrees)
    const blocks = [];
    let last = -99;
    for (const w of words) {
        const d = D * rnd(0.85, 1.15);
        let a = rnd(-az, az);
        if (Math.abs(a - last) < az * 0.35) a = clamp(a + (a >= last ? 1 : -1) * az * 0.5, -az, az);   // jump to another spot than the last word
        last = a;
        const el = rnd(-6, 22);
        w.phi = a * D2R; w.d = d; w.y = d * Math.tan(el * D2R);
        w.sc = Math.min(rnd(1.0, 1.45), (D * 0.7) / Math.max(w.width, 0.01));
        w.roll = rnd(-12, 12);
        const t0 = L.born + Math.round(Math.max(0, w.at - L.elapsed) / TICK_MS);
        blocks.push({ words: [w], landing: false, t0, t1: t0 + hold + 8 });
    }
    return finishBlocks(L, blocks, L.rowH, em, { amax: 1.2, ymax: D * 0.9, ymin: -D * 0.35 });
}

// ------------------------------------------------------------------ SKY layout (skybox: far away, above the horizon)
function layoutSky(L, text, dur) {
    const sz = cfg.size / 100, gk = cfg.gs / 50;
    const Ds = 28 + cfg.dist * 2.5;                                   // blocks to the sky "dome"
    const em = Ds * 0.075 * sz * gk;                                  // ~4 degrees of sky per em
    const { words } = makeWords(text, em, cfg.sp / 100, cfg.maxg);
    L.em = em; L.rowH = em * 1.3; L.hx = em * HALF_K; L.skyD = Ds;
    if (!words.length) return [];
    assignAt(words, dur);
    const seq = lineSeq++;
    const kind = cfg.skystyle === 2 ? seq % 2 : cfg.skystyle;         // 0 scattered + tilted, 1 arc
    const spreadK = 0.45 + 0.55 * (cfg.spread / 100);
    const blocks = [];
    const place = (w, az, el) => {                                    // az / el in degrees
        w.phi = az * D2R;
        const e = el * D2R;
        w.d = Ds * Math.cos(e);
        w.y = Ds * Math.sin(e);
    };
    const n = words.length;
    if (kind === 0) {
        const cols = n <= 2 ? n : n <= 6 ? 3 : 4;
        const rows = Math.ceil(n / cols);
        const A = 52 * spreadK;                                       // half width of the sky patch in degrees
        const cells = [];
        for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) cells.push([r, c]);
        shuffle(cells);
        words.forEach((w, i) => {
            const [r, c] = cells[i];
            const az = cols === 1 ? 0 : -A + ((c + 0.5) / cols) * 2 * A + rnd(-0.3, 0.3) * (A / cols);
            const el = 12 + ((r + 0.5) / rows) * 36 + rnd(-0.3, 0.3) * (36 / rows);
            w.sc = rnd(0.8, 1.45);
            w.roll = rnd(-14, 14);
            place(w, az, el);
            blocks.push({ words: [w], landing: false });
        });
    } else {
        const A = 46 * spreadK;
        const arcs = n > 7 ? 2 : 1;
        const per = Math.ceil(n / arcs);
        for (let a = 0; a < arcs; a++) {
            const ws = words.slice(a * per, (a + 1) * per);
            const tot = ws.reduce((s, w) => s + w.width, 0) || 1;
            let acc = 0;
            const pts = ws.map((w) => {
                const t = (acc + w.width / 2) / tot; acc += w.width;
                return { w, t, az: -A + 2 * A * t, el: 14 + 24 * t + 9 * Math.sin(Math.PI * t) - a * 15 };
            });
            pts.forEach((p, i) => {
                const q = pts[Math.min(pts.length - 1, i + 1)], o = pts[Math.max(0, i - 1)];
                const dAz = (q.az - o.az) * Math.cos(p.el * D2R), dEl = q.el - o.el;
                p.w.roll = dAz === 0 ? 0 : clamp(Math.atan2(dEl, dAz) / D2R, -35, 35);
                p.w.sc = rnd(0.9, 1.35);
                place(p.w, p.az, p.el);
                blocks.push({ words: [p.w], landing: false });
            });
        }
    }
    return finishBlocks(L, blocks, em * 1.3, em, { amax: 1.2, ymax: Ds * 0.92, ymin: Ds * 0.1 });
}

// ------------------------------------------------------------------ CHAT layout (Roblox style bubble above the head)
function layoutChat(L, text, dur) {
    const sz = cfg.size / 100, gk = cfg.gs / 50;
    const em = 0.2 * sz * gk;
    const S2 = Math.min(1, cfg.sp / 100);
    const { words, gapW } = makeWords(text, em, S2, cfg.maxg);
    L.em = em; L.hx = em * HALF_K; L.rowH = em * 1.45;
    if (!words.length) return [];
    const rows = packRows(words, em * 17, gapW);
    const rowW = rows.map((row) => row.reduce((a, w, i) => a + w.width + (i ? gapW : 0), 0));
    const textW = Math.max(...rowW), textH = rows.length * L.rowH;
    const c = em * 0.95;                                              // corner size
    const pad = em * 0.6;
    const W = Math.max(textW + 2 * pad, 2 * c + 0.02), H = Math.max(textH + pad, 2 * c + 0.02);
    rows.forEach((row, r) => {
        let x = -rowW[r] / 2;
        const dy = textH / 2 - L.rowH / 2 - r * L.rowH;
        for (const w of row) { w.dx = x + w.width / 2; w.dy = dy; x += w.width + gapW; }
    });
    const e = 0.006;                                                  // overlap so no hairline shows between pieces
    const mid = W - 2 * c + 2 * e, midH = H - 2 * c + 2 * e;
    L.bub = { W, H, c, tail: c * 0.9, parts: [
        { cell: [0, 0], dx: -W / 2 + c / 2, dy: H / 2 - c / 2, w: c, h: c },
        { cell: [2, 0], dx: W / 2 - c / 2, dy: H / 2 - c / 2, w: c, h: c },
        { cell: [0, 2], dx: -W / 2 + c / 2, dy: -H / 2 + c / 2, w: c, h: c },
        { cell: [2, 2], dx: W / 2 - c / 2, dy: -H / 2 + c / 2, w: c, h: c },
        { cell: [1, 0], dx: 0, dy: H / 2 - c / 2, w: mid, h: c },
        { cell: [1, 2], dx: 0, dy: -H / 2 + c / 2, w: mid, h: c },
        { cell: [0, 1], dx: -W / 2 + c / 2, dy: 0, w: c, h: midH },
        { cell: [2, 1], dx: W / 2 - c / 2, dy: 0, w: c, h: midH },
        { cell: [1, 1], dx: 0, dy: 0, w: mid, h: midH },
        { cell: [3, 0], dx: 0, dy: -H / 2 - c * 0.45 + c * 0.1, w: c, h: c * 0.9 },
    ] };
    assignAt(words, dur);                                             // words appear as they are sung
    return words;
}

function layoutChatTag(L, text, dur) {
    const { words } = makeWords(text, 0.2, 1, cfg.maxg);
    if (!words.length) return [];
    assignAt(words, dur);
    const rows = [[]];
    let n = 0;
    for (const w of words) {                                          // wrap at about 24 characters
        if (n > 0 && n + 1 + w.text.length > 24) { rows.push([]); n = 0; }
        rows[rows.length - 1].push(w);
        n += (n ? 1 : 0) + w.text.length;
    }
    L.rows = rows;
    L.ents = [];
    L.hx = 0.1;
    return words;
}

// ------------------------------------------------------------------ placement of a word in the world (every emission)
function skyPlace(L, w, F) {
    const sinp = Math.sin(w.phi), cosp = Math.cos(w.phi);
    return {
        cx: F.ox + (F.fx * cosp + F.rx * sinp) * w.d, cy: F.oy + w.y, cz: F.oz + (F.fz * cosp + F.rz * sinp) * w.d,
        tx: F.rx * cosp - F.fx * sinp, tz: F.rz * cosp - F.fz * sinp, dirx: 0, dirz: 1,
        ratio: 1, flat: false, tilt: 0, roll: w.roll,
    };
}

function chatBase(L, F) {
    const b = L.bub;
    return F.hy + 0.5 + b.tail + b.H / 2 + L.lift;
}

function chatPlace(L, w, F) {
    return {
        cx: F.ox + F.rx * w.dx, cy: chatBase(L, F) + w.dy, cz: F.oz + F.rz * w.dx,
        tx: F.rx, tz: F.rz, dirx: F.fx, dirz: F.fz, ratio: 1, flat: false, tilt: 0, roll: 0,
    };
}

function placeWord(L, w, F, now, upright) {
    if (L.sky) return skyPlace(L, w, F);
    if (L.chat) return chatPlace(L, w, F);
    if (w._t === now && w._u === !!upright) return w._pl;
    const dim = L.dim;
    const sinp = Math.sin(w.phi), cosp = Math.cos(w.phi);
    const dirx = F.fx * cosp + F.rx * sinp, dirz = F.fz * cosp + F.rz * sinp;
    const tx = F.rx * cosp - F.fx * sinp, tz = F.rz * cosp - F.fz * sinp;
    let cx = F.ox + dirx * w.d, cz = F.oz + dirz * w.d, cy = F.oy + w.y;
    const half = L.hx * w.sc;
    const wantLay = !upright && (cfg.lay || L.forceLay);
    let gy = null;
    if (cfg.clip || w.landing || wantLay) gy = groundY(dim, cx, cz, cy);

    if (cfg.clip) {                                   // 1) keep the whole word (centre and both ends) out of walls
        const ty = gy !== null ? Math.max(cy, gy + 0.6) : cy;
        const hw = (w.width * w.sc) / 2;
        let k = 1;
        for (const off of [0, -hw, hw]) {
            const px = cx + tx * off, pz = cz + tz * off;
            const vx = px - F.hx, vy = ty - F.hy, vz = pz - F.hz;
            const len = Math.hypot(vx, vy, vz);
            if (len < 0.6) continue;
            const hd = rayDist(dim, F.hx, F.hy, F.hz, vx, vy, vz, len);
            if (hd !== null) k = Math.min(k, clamp((hd - 0.6 - half) / len, 0.3, 1));
        }
        w.k = k < w.k ? k : w.k + (k - w.k) * 0.2;                      // closer = instantly, farther = eased
        if (w.k < 0.999) {
            cx = F.hx + (cx - F.hx) * w.k; cz = F.hz + (cz - F.hz) * w.k; cy = F.hy + (cy - F.hy) * w.k;
            if (gy !== null) gy = groundY(dim, cx, cz, cy);
        }
    }
    let ratio = Math.max(0.35, w.k);

    // 2) ground: lie flat when the word reaches the floor, otherwise stay above it
    let flat = false;
    if (gy !== null) {
        const hs = half * ratio;
        const lim = w.flat ? 0.7 : 0.35;                                 // hysteresis against flicker on bumpy ground
        if (wantLay && (w.landing || cy - hs < gy + lim)) {
            flat = true; cy = gy + 0.03;
        } else if (cfg.clip || (w.landing && cfg.stick)) {
            const want = Math.max(cy, gy + hs + 0.08);
            const off = want - cy;
            w.off = off > w.off ? off : w.off + (off - w.off) * 0.25;   // up = instantly, down = eased (stairs)
            cy += w.off;
        }
    }
    w.flat = flat;
    // 3) ceiling
    if (cfg.clip && !flat) {
        const c = ceilingY(dim, F.hx, F.hy, F.hz);
        if (c !== null) cy = Math.min(cy, c - half * ratio - 0.05);
    }
    // 4) last safety net: if the word (centre or either end) still sits inside a block, pull it toward the player
    if (cfg.clip && !flat) {
        for (let i = 0; i < 5; i++) {
            const e = (w.width * w.sc * ratio) / 2;
            if (!solidAt(dim, cx, cy, cz) && !solidAt(dim, cx + tx * e, cy, cz + tz * e) && !solidAt(dim, cx - tx * e, cy, cz - tz * e)) break;
            cx = F.hx + (cx - F.hx) * 0.85; cz = F.hz + (cz - F.hz) * 0.85; cy = F.hy + (cy - F.hy) * 0.85;
            w.k = Math.max(0.3, w.k * 0.85);
            ratio = Math.max(0.35, w.k);
        }
    }
    let tilt = 0;
    if (flat) {
        const yawOut = Math.atan2(-dirx, dirz) * 180 / Math.PI;
        tilt = cfg.fs * (yawOut - 180) + cfg.fo;
    }
    const pl = { cx, cy, cz, tx, tz, dirx, dirz, ratio, flat, tilt, roll: flat ? 0 : w.roll };
    w._t = now; w._u = !!upright; w._pl = pl;
    return pl;
}

// ------------------------------------------------------------------ animation parameters
function animParams(a, q, F) {
    const k = 100 / Math.max(25, cfg.spd);
    const P = { dur: 0.45, s0: 1, ox: 0, oy: 0, oz: 0, rot0: 0 };
    switch (a) {
        case 0: P.dur = 0.45; break;                                           // fade
        case 1: P.dur = 0.35; P.s0 = 0; break;                                 // pop
        case 2: P.dur = 0.5; P.oy = -q * 1.3; break;                           // rise
        case 3: P.dur = 0.5; P.oy = q * 1.3; break;                            // drop
        case 4: P.dur = 0.5; P.ox = -F.rx * q * 3; P.oz = -F.rz * q * 3; break; // slide
        case 5: P.dur = 0.55; P.s0 = 0.2; P.rot0 = 270; break;                 // spin
        case 6: P.dur = 0.5; P.s0 = 2.6; break;                                // zoom
        case 7: P.dur = 0.12; break;                                           // typewriter
        case 8: P.dur = 0.4; P.s0 = 0; break;                                  // wave (letters pop in one by one)
        default: break;
    }
    P.dur = Math.max(0.05, P.dur * k);
    return P;
}

function idleParams(q, F) {
    const I = { ix: 0, iy: 0, iz: 0, ib: 0, isp: 0, pa: 0 };
    switch (cfg.idle) {
        case 1: I.iy = q * 0.18; I.isp = 200; break;                            // wave
        case 2: I.iy = q * 0.22; I.ib = 1; I.isp = 280; break;                  // bounce
        case 3: I.iy = q * 0.14; I.isp = 110; break;                            // float
        case 4: I.ix = F.rx * q * 0.3; I.iz = F.rz * q * 0.3; I.isp = 140; break; // sway
        case 5: I.pa = 0.08; I.isp = 240; break;                                // pulse
        default: break;
    }
    return I;
}

function colorFor(L, g, now) {
    if (L.chat) return [0.1, 0.12, 0.18];                                       // dark text on the white bubble
    switch (cfg.cm) {
        case 1: return hsv((L.id * 53) % 360, 0.55, 1);
        case 2: return hsv((now * 3.2 + g.lt * 180 + L.id * 20) % 360, 0.6, 1);
        case 3: return [lerp(cfg.col[0], cfg.col2[0], g.lt), lerp(cfg.col[1], cfg.col2[1], g.lt), lerp(cfg.col[2], cfg.col2[2], g.lt)];
        default: return cfg.col;
    }
}

// ------------------------------------------------------------------ emitting
function glyphMap(v) {
    const m = new MolangVariableMap();
    for (const k in v) m.setFloat(k, v[k]);
    return m;
}

// mode: "move" (short refreshed particle), "exit" (final fade), "stay" (one long particle that keeps its place)
function emitGlyph(L, w, g, pl, F, now, life, mode) {
    const ink = INK[cfg.font];
    const ix0 = ink[g.idx * 2], ix1 = ink[g.idx * 2 + 1];
    if (ix1 <= ix0) { g.last = now; return; }                  // nothing to draw (space)
    const uw = ix1 - ix0 + 2;                                  // crop the quad to the glyph's ink
    const du = g.du + (((ix0 + ix1) / 2 - 32) / 32) * L.hx;     // the ink is not always centred in its cell
    const sc = pl.ratio * w.sc;
    const q = L.hx * sc;
    const roll = (pl.roll || 0) * D2R, cr = Math.cos(roll), sr = Math.sin(roll);
    const x = pl.cx + pl.tx * du * sc * cr;
    const z = pl.cz + pl.tz * du * sc * cr;
    const y = pl.flat ? pl.cy : pl.cy + g.dy * sc + du * sc * sr;
    const ao = Math.max(0, ((now - g.atTick) * TICK_MS) / 1000);
    const AP = g.ap;
    const done = ao >= AP.dur + 0.05;
    const I = idleParams(q, F);
    const col = colorFor(L, g, now);
    const dyK = cfg.exit === 1 ? 1.2 : cfg.exit === 2 ? -1.2 : 0;
    const ending = mode !== "move";
    const base = {
        u: (g.idx % 16) * 64 + ix0 - 1, uw, v: Math.floor(g.idx / 16) * 64, qx: (q * uw) / 64, qy: q, life, ao,
        dur: done ? 0.05 : AP.dur, s0: done ? 1 : AP.s0,
        ox: done ? 0 : AP.ox, oy: done ? 0 : AP.oy, oz: done ? 0 : AP.oz, rot0: done ? 0 : AP.rot0,
        tilt: pl.flat ? pl.tilt : (pl.roll || 0) * cfg.rs,
        vx: mode === "stay" ? 0 : S.vx * 20, vz: mode === "stay" ? 0 : S.vz * 20,
        ix: I.ix, iy: I.iy, iz: I.iz, ib: I.ib, isp: I.isp, pa: I.pa, phase: g.ph,
        dy: ending ? dyK * q : 0, e1: ending && cfg.exit === 3 ? 0.2 : 1,
        fo: mode === "exit" ? life : mode === "stay" ? 0.4 : 0.12,
        xd: mode === "exit" ? life : mode === "stay" ? 0.4 : 1,
    };
    const id = (pl.flat ? "lyr:flat_" : "lyr:glyph_") + cfg.font;
    if (TEST) TEST.emits.push({ line: L.id, word: L.words.indexOf(w), gi: w.glyphs.indexOf(g), x, y, z, q, now, exit: mode === "exit", mode, flat: pl.flat, tilt: pl.tilt, roll: pl.roll || 0, hx: F.hx, hy: F.hy, hz: F.hz, ao, life, qx: (q * uw) / 64, uw });
    try {
        if (cfg.shadow && !L.chat) {
            let sx = x, sy = y, sz = z;
            if (pl.flat) {
                sx += pl.tx * q * 0.06 - pl.dirx * q * 0.07; sz += pl.tz * q * 0.06 - pl.dirz * q * 0.07; sy -= 0.012;
            } else {
                const dx = x - F.hx, dy = y - F.hy, dz = z - F.hz, l = Math.hypot(dx, dy, dz) || 1;
                sx += (dx / l) * q * 0.12 + pl.tx * q * 0.05; sz += (dz / l) * q * 0.12 + pl.tz * q * 0.05; sy += (dy / l) * q * 0.12 - q * 0.07;
            }
            L.dim.spawnParticle(id, { x: sx, y: sy, z: sz }, glyphMap({ ...base, r: 0, g: 0, b: 0, a0: 0.45 }));
        }
        L.dim.spawnParticle(id, { x, y, z }, glyphMap({ ...base, r: col[0], g: col[1], b: col[2], a0: 1 }));
    } catch (e) {}
}

// the bubble of a CHAT line: nine stretched pieces plus the tail
function emitBubble(L, F, now, life, mode) {
    const b = L.bub;
    const base = chatBase(L, F);
    const ao = Math.max(0, ((now - L.born) * TICK_MS) / 1000);
    const AP = L.bubAp;
    const done = ao >= AP.dur + 0.05;
    const dyK = cfg.exit === 1 ? 1.2 : cfg.exit === 2 ? -1.2 : 0;
    const ending = mode !== "move";
    // pieces sit slightly behind the text (away from a camera that looks along the player's facing)
    const bx = F.fx * 0.03, bz = F.fz * 0.03;
    for (const p of b.parts) {
        const vars = {
            u: p.cell[0] * 64, uw: 64, v: p.cell[1] * 64, qx: p.w / 2, qy: p.h / 2, life, ao,
            dur: done ? 0.05 : AP.dur, s0: 1, ox: 0, oy: done ? 0 : AP.oy, oz: 0, rot0: 0, tilt: 0,
            vx: S.vx * 20, vz: S.vz * 20, ix: 0, iy: 0, iz: 0, ib: 0, isp: 0, pa: 0, phase: 0,
            dy: ending ? dyK * b.c : 0, e1: 1, fo: mode === "exit" ? life : 0.12, xd: mode === "exit" ? life : 1,
            r: 1, g: 1, b: 1, a0: 0.96,
        };
        const x = F.ox + F.rx * p.dx + bx, y = base + p.dy, z = F.oz + F.rz * p.dx + bz;
        if (TEST) TEST.bubbles.push({ line: L.id, now, x, y, z, cell: p.cell, w: p.w, h: p.h, hx: F.hx, hy: F.hy, hz: F.hz });
        try { L.dim.spawnParticle("lyr:bubble", { x, y, z }, glyphMap(vars)); } catch (e) {}
    }
}

function beginExit(L) {
    if (L.exiting) return;
    L.exiting = true;
    L.exitDone = false;
    if (L.nt) removeNametags(L);
}

function removeNametags(L) {
    for (const w of L.words) { if (w.ent) { try { w.ent.remove(); } catch (e) {} w.ent = null; } }
    if (L.ents) { for (const e of L.ents) { try { if (e) e.remove(); } catch (er) {} } L.ents = []; }
}

function releaseBoxes(L, when) {
    for (const b of L.boxes) b.expire = when;
}

function doExit(L, now) {
    L.exitDone = true;
    L.die = now + EXIT_TICKS + 3;
    releaseBoxes(L, L.die);
    if (L.nt || L.static || L.ntChat) { if (L.nt || L.ntChat) L.die = now; return; }          // text that stays fades out by itself
    const F = frameOf(L);
    const life = (EXIT_TICKS * TICK_MS) / 1000;
    if (L.chat) emitBubble(L, F, now, life, "exit");
    for (const w of L.words) {
        let pl = null;
        if (L.wordHold && now > w.atTick + L.wordHold) continue;
        for (const g of w.glyphs) {
            if (g.last < 0) continue;
            if (!pl) pl = placeWord(L, w, F, now, false);
            emitGlyph(L, w, g, pl, F, now, life, "exit");
        }
    }
}

function dropAll() {
    for (const L of lines) { if (L.nt) removeNametags(L); }
    lines.length = 0;
    boxes = [];
}

// ------------------------------------------------------------------ lines
function startLine(p, elapsed, dur, text, opts) {
    if (!cfg.on && !(opts && opts.force)) return;
    const t = cleanText(text);
    if (!t) return;
    if (!trackPlayer(p)) return;
    const now = system.currentTick;
    const style = opts && opts.style !== undefined ? opts.style : cfg.style;
    const L = {
        id: ++lineId, born: now, ang0: S.ang, dim: p.dimension, exiting: false, exitDone: false, die: 0,
        boxes: [], words: [], sky: style === 0, chat: style === 2, lift: 0, liftT: 0,
        forceLay: !!(opts && opts.floor),
        endTick: now + Math.max(6, Math.round((dur - elapsed) / TICK_MS)),
    };
    L.elapsed = elapsed;
    L.ntChat = style === 2 && !cfg.bubble;
    L.chat = style === 2 && !L.ntChat;
    L.nt = (cfg.mode === 1 && style === 1) || L.ntChat;
    L.static = style === 1 && !cfg.track && !(opts && opts.follow);
    const perWord = style === 1 && cfg.wmode === 1 && !(opts && opts.floor);
    // previous lines leave; in CHAT they stay and get pushed up by the new bubble instead
    const keep = style === 2;
    L.words = style === 0 ? layoutSky(L, t, dur)
        : L.ntChat ? layoutChatTag(L, t, dur)
            : style === 2 ? layoutChat(L, t, dur)
                : perWord ? layoutWordByWord(L, t, dur)
                    : layoutWorld(L, t, dur, opts && opts.floor ? 2 : undefined);
    if (!L.words.length) return;
    for (const o of lines) {
        if (keep && (o.chat || o.ntChat) && !o.exiting) {
            o.liftT += L.ntChat ? L.rows.length * 0.3 + 0.12 : L.bub.H + L.bub.tail + 0.14;
            o.endTick = Math.min(o.endTick, now + 30);
        } else beginExit(o);
    }
    const F = frameOf(L);
    L.F0 = F;
    const total = L.words.reduce((a, w) => a + w.glyphs.length, 0);
    const spdK = 100 / Math.max(25, cfg.spd);
    let n = 0;
    L.words.forEach((w, wi) => {
        w.atTick = now + Math.round(Math.max(0, w.at - elapsed) / TICK_MS);
        if (L.ntChat) return;
        const an = cfg.anim === 9 ? [1, 2, 3, 4, 5, 6][(wi * 5 + ((Math.random() * 6) | 0)) % 6] : cfg.anim;
        w.glyphs.forEach((g, gi) => {
            let delay = 0;
            if (an === 7) delay = Math.round((gi * 45 * spdK) / TICK_MS);
            if (an === 8) delay = gi * 2;
            g.atTick = w.atTick + delay;
            g.ap = L.chat ? { dur: 0.3, s0: 1, ox: 0, oy: -0.18, oz: 0, rot0: 0 } : animParams(an, L.hx * w.sc, F);
            g.ph = (gi * 40 + wi * 90) % 360;
            g.lt = total > 1 ? n / (total - 1) : 0;
            n++;
        });
    });
    if (L.chat) L.bubAp = { dur: 0.3, oy: -0.18 };
    if (L.static && !L.ntChat) {                     // fix every word in the world right now
        const lead = 0;
        L.words.forEach((w) => { w.pl = placeWord(L, w, F, now, !!L.nt); });
        void lead;
    }
    lines.push(L);
}

function tickStatic(L, now) {
    if (L.nt) { tickNametags(L, L.F0, now); return; }
    for (const w of L.words) {
        if (now < w.atTick) continue;
        for (const g of w.glyphs) {
            if (now < g.atTick || g.last > -1e8) continue;
            // one particle that lives until the line ends, then fades
            const endT = L.wordHold ? Math.min(L.endTick, w.atTick + L.wordHold) : L.endTick;
            const remain = Math.max(0.1, ((endT - now) * TICK_MS) / 1000);
            emitGlyph(L, w, g, w.pl, L.F0, now, remain + 0.4, "stay");
            g.last = now;
        }
    }
}

function tickLines() {
    if (!lines.length && !boxes.length) return;
    const now = system.currentTick;
    if (!target || !trackPlayer(target)) return;
    const moving = Math.hypot(S.vx, S.vz) > 0.02;
    const R = Math.max(2, Math.round((moving ? 4 : 6) * cfg.rate / 100));
    const life = ((R + 2) * TICK_MS) / 1000;
    boxes = boxes.filter((b) => b.expire > now);
    for (let i = lines.length - 1; i >= 0; i--) {
        const L = lines[i];
        if (!cfg.on) { if (L.nt) removeNametags(L); lines.splice(i, 1); continue; }
        if (!L.exiting && now >= L.endTick - EXIT_TICKS) beginExit(L);
        if (L.exiting) {
            if (!L.exitDone) doExit(L, now);
            if (now >= L.die) { releaseBoxes(L, 0); lines.splice(i, 1); }
            continue;
        }
        if (L.ntChat) { L.lift += (L.liftT - L.lift) * 0.3; tickChatTag(L, frameOf(L), now); continue; }
        if (L.static) { tickStatic(L, now); continue; }
        L.lift += (L.liftT - L.lift) * 0.3;
        const F = frameOf(L);
        if (L.nt) { tickNametags(L, F, now); continue; }
        if (L.chat && now - (L.lastBub === undefined ? -999 : L.lastBub) >= R) {
            L.lastBub = now;
            emitBubble(L, F, now, life, "move");
        }
        for (const w of L.words) {
            if (now < w.atTick) continue;
            if (L.wordHold && now > w.atTick + L.wordHold) continue;
            let pl = null;
            for (const g of w.glyphs) {
                if (now < g.atTick || now - g.last < R) continue;
                if (!pl) pl = placeWord(L, w, F, now, false);
                emitGlyph(L, w, g, pl, F, now, life, "move");
                g.last = now;
            }
        }
    }
}

// ------------------------------------------------------------------ nametag renderer (classic, Minecraft font + dark box), World style only
function tickNametags(L, F, now) {
    for (const w of L.words) {
        if (now < w.atTick) continue;
        if (L.wordHold && now > w.atTick + L.wordHold) {
            if (w.ent) { try { w.ent.remove(); } catch (e) {} w.ent = null; }
            continue;
        }
        if (w.ent && (L.static || now % 2 !== 0)) continue;
        const pl = L.static ? w.pl : placeWord(L, w, F, now, true);
        try {
            if (!w.ent) {
                w.ent = L.dim.spawnEntity(ENT, { x: pl.cx, y: pl.cy, z: pl.cz });
                w.ent.nameTag = w.text;
            } else {
                w.ent.teleport({ x: pl.cx, y: pl.cy, z: pl.cz });
            }
        } catch (e) {}
    }
}

// ------------------------------------------------------------------ CHAT as nametags: the line floats above the head, words appear as they are sung
function tickChatTag(L, F, now) {
    const shown = L.words.filter((w) => now >= w.atTick);
    if (!shown.length) return;
    const rows = L.rows;
    for (let r = 0; r < rows.length; r++) {
        const txt = rows[r].filter((w) => now >= w.atTick).map((w) => w.text).join(" ");
        if (!txt) continue;
        const y = F.hy + 0.55 + (rows.length - 1 - r) * 0.3 + L.lift;
        const pos = { x: F.ox, y, z: F.oz };
        try {
            let e = L.ents[r];
            if (!e) {
                e = L.dim.spawnEntity(ENT, pos);
                L.ents[r] = e;
                e.nameTag = txt;
                L.tags = L.tags || [];
                L.tags[r] = txt;
            } else {
                if (L.tags[r] !== txt) { e.nameTag = txt; L.tags[r] = txt; }
                if (now % 2 === 0) e.teleport(pos);
            }
            if (TEST) TEST.tags.push({ line: L.id, row: r, text: txt, x: pos.x, y: pos.y, z: pos.z, now, hx: F.hx, hy: F.hy, hz: F.hz });
        } catch (er) {}
    }
}

// ------------------------------------------------------------------ dispatch
function showLine(p, elapsed, dur, text) {
    if (!cfg.on) return;
    if (text === lastText && system.currentTick - lastTick < 20) return;      // same line twice would stack
    lastText = text; lastTick = system.currentTick;
    target = p;
    startLine(p, elapsed, dur, text);
}

system.afterEvents.scriptEventReceive.subscribe((ev) => {
    if (!ev.id.startsWith(NS)) return;
    const cmd = ev.id.slice(NS.length);
    const msg = ev.message || "";
    const p = pickPlayer(ev);
    if (p) target = p;

    if (cmd === "cfg") {
        parseCfg(msg);
        if (p && !greeted) { greeted = true; p.sendMessage("\u00a7a[LYR] connected to the app"); }
    } else if (cmd === "p") {
        if (msg.trim() !== "1") for (const L of lines) beginExit(L);
    } else if (cmd === "anchor" && p) {
        trackPlayer(p);
        S.lockAng = S.ang;
        p.sendMessage("\u00a7a[LYR] direction locked here");
    } else if (cmd === "clear") {
        for (const L of lines) beginExit(L);
    } else if (cmd === "test" && p) {
        lastText = "";
        startLine(p, 0, 5000, "LYR 3D sample line for you", { force: true });
    } else if (cmd === "floor" && p) {
        lastText = "";
        startLine(p, 0, 6000, "LYR FLOOR TEST", { force: true, floor: true, style: 1 });
    } else if (cmd === "l" && p) {
        const i1 = msg.indexOf("|");
        const i2 = msg.indexOf("|", i1 + 1);
        if (i1 < 0 || i2 < 0) return;
        showLine(p, Number(msg.slice(0, i1)) || 0, Number(msg.slice(i1 + 1, i2)) || 3000, msg.slice(i2 + 1));
    }
});

system.runInterval(() => {
    try { tickLines(); } catch (e) {}
}, 1);

system.run(() => {
    for (const id of ["overworld", "nether", "the_end"]) {
        try { for (const e of world.getDimension(id).getEntities({ type: ENT })) e.remove(); } catch (e) {}
    }
});
