# Lyrics Plus Bridge — Music Player + Synced Lyrics for Minecraft Bedrock (LeviLauncher, Android)

Panel now-playing ala Lyrics Plus (cover, judul/artis/album, progress, Play/Pause/Next/Prev,
lirik tersinkron dengan highlight baris aktif) yang tampil **di atas Minecraft** saat dijalankan lewat LeviLauncher.

## STATUS JUJUR
| Bagian | Status |
|---|---|
| Baca MediaSession (Spotify, YT Music, YouTube, dll.) | Ditulis, **belum dikompilasi/diuji di perangkat** |
| Kontrol Play/Pause/Next/Prev/Seek | Ditulis, belum diuji |
| Lirik (LRCLIB) + sinkronisasi + animasi | Ditulis, belum diuji |
| Panel overlay + semua pengaturan | Ditulis, belum diuji |
| Mod native `.so` di dalam proses game | **Belum dibuat** (lihat bawah) |

Kode ditulis tanpa Android SDK, jadi **build pertama bisa menampilkan error kompilasi kecil**. Kirim lognya, nanti diperbaiki.

### Kenapa bukan mod `.so`?
Pack Bedrock tidak bisa membaca MediaSession. LeviLauncher memang memuat modul native, tapi
API menggambar UI-nya (header Preloader) belum bisa saya lihat, dan hook render bergantung versi Minecraft.
Menulis C++ tebakan hanya akan menghasilkan kode yang tidak jalan. Maka panel digambar oleh APK sebagai overlay;
hasilnya tampil di atas game, dengan kontrol sentuh nyata. Server lokal `127.0.0.1:38417` (lihat `docs/PROTOCOL.md`)
sudah disiapkan agar mod native bisa disambungkan nanti.

Font: panel memakai font sistem Android (sans-serif). Font Minecraft milik Mojang tidak disertakan.

## Build (tanpa PC)
1. Buat repo GitHub, upload seluruh isi folder ini.
2. Tab **Actions** → *Build APK* → tunggu selesai → unduh artifact `LyricsPlusBridge-apk` (berisi `app-debug.apk`).
Atau di PC: Android Studio → Open → Run. (JDK 17, Gradle 8.7)

## Instalasi
1. Install APK, buka **Lyrics Plus Bridge**.
2. Tombol 1: aktifkan **Notification Access** untuk Lyrics Plus Bridge (wajib, ini cara Android memberi akses MediaSession).
3. Tombol 2: izinkan **Display over other apps**.
4. Tombol 3: **Start panel**. Izinkan notifikasi jika diminta.
5. Putar lagu di Spotify / YouTube Music.
6. Buka Minecraft lewat **LeviLauncher** seperti biasa; panel muncul di atas game.
   Seret panel untuk memindahkannya; ketuk tombol/progress bar untuk mengontrol.

Tips: matikan penghemat baterai untuk Lyrics Plus Bridge, Spotify dan LeviLauncher agar tidak dihentikan Android.

## Lirik melayang + pill karaoke (v1.1)
Terinspirasi video referensi: kata-kata lirik muncul satu per satu, melengkung di layar, dan pill di atas
menampilkan baris aktif dengan kata yang disorot, cover kecil, dan equalizer.
Pengaturan: Floating lyrics, Top karaoke pill, ALL CAPS, warna huruf = warna album, Lyric Size, Font, Shadow.

Batasan jujur:
- Lirik digambar di **layar (2D)**, tidak menempel di dunia 3D Minecraft dan tidak mengikuti kamera seperti di video.
  Itu butuh mod native yang masuk ke renderer game.
- Waktu per kata **diperkirakan** (LRCLIB hanya punya waktu per baris), jadi sorotan kata bisa sedikit meleset.
- Overlay layar penuh (tembus sentuh) menambah sedikit beban; matikan "Floating lyrics" bila game terasa berat.
- Pill di tengah atas bisa menutupi tombol Minecraft; matikan "Top karaoke pill" bila mengganggu.

## Tampilan aplikasi (v1.3, gaya kaca)
Menu aplikasi memakai gaya "liquid glass": latar bergerak berwarna mengikuti cover lagu, kartu kaca,
nav bar mengambang dengan lensa yang meregang saat digeser, mini player kaca (prev/play/next sungguhan),
dan animasi halaman/ toggle/ tombol. Efek kaca ini **ditiru** (transparan + gradien + border),
bukan blur asli dari konten di belakangnya.

## Lirik 3D v1.1 (font sendiri, tanpa kotak hitam)
Add-on kini menggambar huruf dengan **partikel** memakai atlas font buatan sendiri, jadi tidak ada kotak hitam
nametag dan fontnya bisa dipilih (8 font OFL: Outfit, Bricolage, Erica One, Gloock, Lora Italic, Handwritten,
Big Shoulders, Pixelify). Di tab 3D aplikasi ada preview langsung + pilihan Font, Tempat muncul
(Arc, Sky, Land, Scatter, Wave, Ring), Animasi (Fade, Pop, Rise, Drop, Slide, Spin, Zoom, Typewriter, Wave, Mix),
Warna, Bayangan, ukuran, jarak, dan batas huruf. Tombol "Tes di Minecraft" menampilkan baris contoh.
Bila huruf tidak tampil di game, pilih Renderer "Nametag (classic)" (memakai kotak hitam bawaan game).
Batasan: hanya huruf Latin/ASCII; "Land" = teks tegak dekat tanah (bukan teks rata di lantai); partikel yang
sudah muncul tidak bisa dihapus paksa (hilang sendiri); preview aplikasi meniru, bukan identik dengan di game.

## LYR 1.0.0
- Aplikasi dan add-on bernama **LYR**, semua versi 1.0.0 (add-on di folder `addon/`, APK id `com.lyr.app`).
- **Tiga gaya lirik 3D** (tab 3D > Gaya tampilan):
  - **Sky**: kata-kata di skybox (jauh, di atas cakrawala, miring atau melengkung), bukan di atas kepala.
  - **World**: kata tersebar di sekitar pemain dan diam di tempat munculnya saat pemain berjalan (opsi: ikut pemain).
  - **Chat**: gelembung ala chat Roblox di atas kepala, mengikuti pemain, baris lama terdorong ke atas.
- Teks tidak menembus blok/tanah, berbaring kalau sampai di tanah, tersebar kiri-kanan, dan kata tidak bertumpuk.
- Tes add-on tanpa Minecraft: `node addon/test/sim.mjs`.
- UI gaya iOS (terang/gelap), splash dengan kredit developer, popup dukung admin, pesan developer.
- Build APK dan add-on: lihat PUBLISH.md.

## Arah lirik 3D
"Arah lirik: Tetap di satu arah" mengunci posisi dan arah lirik (tidak ikut arah jalan/pandanganmu). Tombol
"Kunci arah di sini" (tab 3D) mengunci ulang ke arah yang sedang kamu hadap; jika kamu menjauh > 24 blok,
panggung lirik ikut berpindah tetapi arahnya tetap. "Tempel ke tanah" membuat tempat Land menempel di permukaan blok.

## Pengaturan
Enable Music UI, Enable Lyrics, UI Scale, Panel Position (+ seret bebas), Animation Speed,
Background Opacity, Show Album Cover, Show Progress Bar.

## Batasan
- Lirik butuh internet dan hanya muncul bila ada di LRCLIB.
- Aplikasi yang tidak mengirim cover/durasi ke MediaSession akan tampil tanpa cover/progress.
- Overlay menutupi sebagian layar: letakkan di area yang aman lewat Panel Position.
